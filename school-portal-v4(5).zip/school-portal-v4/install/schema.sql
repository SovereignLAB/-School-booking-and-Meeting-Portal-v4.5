-- ================================================================
-- SCHOOL MEETING PORTAL — Database Schema
-- Database: btrfpimq_reg
-- User:     btrfpimq_reg
-- Host:     localhost (cPanel)
-- ================================================================
-- Run this once in phpMyAdmin or via cPanel's MySQL tool.
-- After running, the portal automatically uses MySQL when
-- DB_NAME, DB_USER, DB_PASS are set in .env
-- ================================================================

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------------------------------------------
-- meetings
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `meetings` (
  `id`          VARCHAR(32)   NOT NULL PRIMARY KEY,
  `title`       VARCHAR(255)  NOT NULL,
  `description` TEXT,
  `date`        DATE          NOT NULL,
  `class`       VARCHAR(100)  DEFAULT '',
  `location`    VARCHAR(255)  DEFAULT '',
  `meetingLink` VARCHAR(512)  DEFAULT '',
  `icon`        VARCHAR(20)   DEFAULT '📅',
  `timeSlots`   JSON,
  `createdBy`   VARCHAR(32)   DEFAULT '',
  `createdAt`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt`   DATETIME      ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_date`  (`date`),
  INDEX `idx_class` (`class`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- bookings
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `bookings` (
  `id`          VARCHAR(32)   NOT NULL PRIMARY KEY,
  `meetingId`   VARCHAR(32)   NOT NULL,
  `userId`      VARCHAR(32)   NOT NULL,
  `userName`    VARCHAR(255)  NOT NULL,
  `userEmail`   VARCHAR(255)  NOT NULL,
  `userPhone`   VARCHAR(50)   DEFAULT '',
  `studentName` VARCHAR(255)  DEFAULT '',
  `class`       VARCHAR(100)  DEFAULT '',
  `slot`        VARCHAR(20)   DEFAULT '',
  `status`      ENUM('confirmed','cancelled') DEFAULT 'confirmed',
  `createdAt`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `updatedAt`   DATETIME      ON UPDATE CURRENT_TIMESTAMP,
  INDEX `idx_meetingId` (`meetingId`),
  INDEX `idx_userId`    (`userId`),
  INDEX `idx_email`     (`userEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- apologies
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `apologies` (
  `id`          VARCHAR(32)   NOT NULL PRIMARY KEY,
  `bookingId`   VARCHAR(32)   NOT NULL,
  `meetingId`   VARCHAR(32)   NOT NULL,
  `userId`      VARCHAR(32)   NOT NULL,
  `userName`    VARCHAR(255)  NOT NULL,
  `userEmail`   VARCHAR(255)  DEFAULT '',
  `reason`      TEXT,
  `createdAt`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_meetingId` (`meetingId`),
  INDEX `idx_userId`    (`userId`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- messages  (sent emails log)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `messages` (
  `id`          VARCHAR(32)   NOT NULL PRIMARY KEY,
  `fromEmail`   VARCHAR(255)  NOT NULL,
  `fromName`    VARCHAR(255)  NOT NULL,
  `fromRole`    VARCHAR(30)   DEFAULT '',
  `toEmail`     VARCHAR(255)  NOT NULL,
  `toName`      VARCHAR(255)  DEFAULT '',
  `toPhone`     VARCHAR(50)   DEFAULT '',
  `subject`     VARCHAR(500)  NOT NULL,
  `message`     TEXT          NOT NULL,
  `emailSent`   TINYINT(1)    DEFAULT 0,
  `emailError`  VARCHAR(500)  DEFAULT '',
  `sentAt`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_from`  (`fromEmail`),
  INDEX `idx_to`    (`toEmail`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- settings (key-value store, single row)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `settings` (
  `id`          INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `data`        JSON          NOT NULL,
  `updatedAt`   DATETIME      ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default settings if table is empty
INSERT IGNORE INTO `settings` (`id`, `data`) VALUES (1, '{
  "schoolName": "SPRINGFIELD ACADEMY",
  "schoolMotto": "Excellence Through Education",
  "logo": "🎓",
  "address": "Nairobi, Kenya",
  "phone": "+254 712 345 678",
  "email": "noreply@sovereignai.co.ke",
  "website": "create.sovereignai.co.ke"
}');

-- ----------------------------------------------------------------
-- audit_log
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `audit_log` (
  `id`          VARCHAR(32)   NOT NULL PRIMARY KEY,
  `action`      VARCHAR(100)  NOT NULL,
  `details`     VARCHAR(500)  DEFAULT '',
  `userId`      VARCHAR(32)   DEFAULT '',
  `userName`    VARCHAR(255)  DEFAULT '',
  `userRole`    VARCHAR(30)   DEFAULT '',
  `ip`          VARCHAR(45)   DEFAULT '',
  `userAgent`   VARCHAR(300)  DEFAULT '',
  `meta`        JSON,
  `createdAt`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_action`    (`action`),
  INDEX `idx_userId`    (`userId`),
  INDEX `idx_createdAt` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- rate_limits  (replaces file-based rate limiting)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `rate_limits` (
  `id`          INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `key_hash`    VARCHAR(64)   NOT NULL,
  `hit_at`      DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  INDEX `idx_key_hash` (`key_hash`),
  INDEX `idx_hit_at`   (`hit_at`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ----------------------------------------------------------------
-- email_queue  (for reliable async sending)
-- ----------------------------------------------------------------
CREATE TABLE IF NOT EXISTS `email_queue` (
  `id`          INT           NOT NULL AUTO_INCREMENT PRIMARY KEY,
  `toEmail`     VARCHAR(255)  NOT NULL,
  `toName`      VARCHAR(255)  DEFAULT '',
  `subject`     VARCHAR(500)  NOT NULL,
  `htmlBody`    MEDIUMTEXT    NOT NULL,
  `textBody`    TEXT,
  `replyTo`     VARCHAR(255)  DEFAULT '',
  `attempts`    INT           DEFAULT 0,
  `lastError`   VARCHAR(500)  DEFAULT '',
  `status`      ENUM('pending','sent','failed') DEFAULT 'pending',
  `createdAt`   DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `sentAt`      DATETIME,
  INDEX `idx_status`    (`status`),
  INDEX `idx_createdAt` (`createdAt`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

SET FOREIGN_KEY_CHECKS = 1;

-- ================================================================
-- Verification queries (run to check setup)
-- ================================================================
-- SHOW TABLES;
-- SELECT COUNT(*) AS meetings_count  FROM meetings;
-- SELECT COUNT(*) AS bookings_count  FROM bookings;
-- SELECT data    AS settings         FROM settings WHERE id=1;
