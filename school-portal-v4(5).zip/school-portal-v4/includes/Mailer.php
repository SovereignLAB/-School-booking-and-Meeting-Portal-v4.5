<?php
// ================================================================
// includes/Mailer.php — SMTP Email Sender
// ================================================================
// Pure PHP SMTP mailer — no PHPMailer or Composer needed.
// Connects directly to cPanel's mail server via socket with
// STARTTLS encryption and SMTP AUTH LOGIN.
//
// Usage:
//   $result = Mailer::send([
//     'to'      => 'parent@example.com',
//     'toName'  => 'James Omondi',
//     'subject' => 'Your Meeting Booking Confirmed',
//     'html'    => '<h1>Hello</h1>',
//     'text'    => 'Hello',         // optional plain-text fallback
//     'replyTo' => 'teacher@school.ac.ke',  // optional
//   ]);
//   // Returns: ['ok' => true] or ['ok' => false, 'error' => '...']
// ================================================================

class Mailer
{
    // ----------------------------------------------------------------
    // Public API
    // ----------------------------------------------------------------

    public static function send(array $opts): array
    {
        $to      = trim($opts['to']      ?? '');
        $toName  = trim($opts['toName']  ?? '');
        $subject = trim($opts['subject'] ?? '(No Subject)');
        $html    = $opts['html']    ?? '';
        $text    = $opts['text']    ?? strip_tags($html);
        $replyTo = $opts['replyTo'] ?? '';

        if (empty($to) || !filter_var($to, FILTER_VALIDATE_EMAIL)) {
            return ['ok' => false, 'error' => 'Invalid recipient email: ' . $to];
        }

        // SMTP config from env
        $host       = env('SMTP_HOST', 'mail.sovereignai.co.ke');
        $port       = (int) env('SMTP_PORT', 587);
        $user       = env('SMTP_USER', 'noreply@sovereignai.co.ke');
        $pass       = env('SMTP_PASS', '');
        $fromName   = env('SMTP_FROM_NAME', 'School Meeting Portal');
        $encryption = strtolower(env('SMTP_ENCRYPTION', 'tls'));

        $boundary = '----=_Part_' . md5(uniqid());
        $msgBody  = self::buildMessage($html, $text, $boundary);

        // RFC 2822 headers (shared by both methods)
        $toHeader   = $toName ? self::encodeHeader($toName) . " <{$to}>" : $to;
        $fromHeader = self::encodeHeader($fromName) . " <{$user}>";
        $messageId  = '<' . uniqid('', true) . '@sovereignai.co.ke>';
        $date       = date('r');

        $headers  = "Date: {$date}\r\n";
        $headers .= "From: {$fromHeader}\r\n";
        $headers .= "To: {$toHeader}\r\n";
        if ($replyTo) $headers .= "Reply-To: {$replyTo}\r\n";
        $headers .= "Message-ID: {$messageId}\r\n";
        $headers .= "MIME-Version: 1.0\r\n";
        $headers .= "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n";
        $headers .= "X-Mailer: SovereignAI-School-Portal/2.0\r\n";

        // ── 1. Try SMTP socket ────────────────────────────────────
        $smtpError = '';
        if (!empty($pass)) {
            try {
                $smtp = new SmtpSocket($host, $port, $encryption);
                $smtp->connect();
                $smtp->ehlo();
                if ($encryption === 'tls') {
                    $smtp->starttls();
                    $smtp->ehlo();
                }
                $smtp->auth($user, $pass);
                $smtp->mail($user);
                $smtp->rcpt($to);
                $smtp->data($headers . "\r\n" . $msgBody);
                $smtp->quit();
                appLog('info', 'Email sent via SMTP', ['to' => $to, 'subject' => $subject]);
                return ['ok' => true];
            } catch (Throwable $e) {
                $smtpError = $e->getMessage();
                appLog('warn', 'SMTP failed, trying mail() fallback: ' . $smtpError, ['to' => $to]);
            }
        } else {
            $smtpError = 'SMTP_PASS not configured';
        }

        // ── 2. Fallback: PHP mail() via server sendmail ───────────
        $fallbackError = '';
        try {
            $mailHeaders  = "From: {$fromHeader}\r\n";
            if ($replyTo) $mailHeaders .= "Reply-To: {$replyTo}\r\n";
            $mailHeaders .= "Message-ID: {$messageId}\r\n";
            $mailHeaders .= "MIME-Version: 1.0\r\n";
            $mailHeaders .= "Content-Type: multipart/alternative; boundary=\"{$boundary}\"\r\n";
            $mailHeaders .= "X-Mailer: SovereignAI-School-Portal/2.0\r\n";
            $sent = @mail($to, $subject, $msgBody, $mailHeaders, "-f{$user}");
            if ($sent) {
                appLog('info', 'Email sent via mail() fallback', ['to' => $to, 'subject' => $subject]);
                return ['ok' => true];
            }
            $fallbackError = 'mail() returned false — check server sendmail config';
        } catch (Throwable $e2) {
            $fallbackError = $e2->getMessage();
        }

        $finalError = "SMTP: {$smtpError} | Sendmail: {$fallbackError}";
        appLog('error', 'All email methods failed: ' . $finalError, ['to' => $to]);
        return ['ok' => false, 'error' => $finalError];
    }

    // ----------------------------------------------------------------
    // Convenience senders
    // ----------------------------------------------------------------

    /** Send a booking confirmation to a parent */
    public static function sendBookingConfirmation(array $booking, array $meeting, array $settings): array
    {
        $schoolName = $settings['schoolName'] ?? 'School';
        $date       = (new DateTime($meeting['date']))->format('l, d F Y');
        $slot       = $booking['slot'] ?? 'TBD';
        $location   = $meeting['location'] ?? 'School Campus';
        $link       = $meeting['meetingLink'] ?? '';

        $html = self::emailTemplate($settings, 'Booking Confirmed ✅', "
            <p>Dear <strong>" . htmlspecialchars($booking['userName']) . "</strong>,</p>
            <p>Your booking for the following meeting has been <strong style='color:#0A7C5A'>confirmed</strong>:</p>
            " . self::meetingBox($meeting['title'], $date, $slot, $location, $link) . "
            <p>Please arrive 5 minutes before your scheduled slot. If you need to cancel, please do so through the portal at least 24 hours in advance.</p>
            <p>Best regards,<br/><strong>{$schoolName}</strong></p>
        ");

        return self::send([
            'to'      => $booking['userEmail'],
            'toName'  => $booking['userName'],
            'subject' => "Meeting Booking Confirmed — {$meeting['title']}",
            'html'    => $html,
        ]);
    }

    /** Send a cancellation/apology receipt */
    public static function sendCancellationReceipt(array $booking, array $meeting, string $reason, array $settings): array
    {
        $schoolName = $settings['schoolName'] ?? 'School';
        $date       = (new DateTime($meeting['date']))->format('l, d F Y');

        $html = self::emailTemplate($settings, 'Booking Cancellation Received', "
            <p>Dear <strong>" . htmlspecialchars($booking['userName']) . "</strong>,</p>
            <p>We have received your cancellation and apology for the following booking:</p>
            " . self::meetingBox($meeting['title'], $date, $booking['slot'] ?? '', $meeting['location'] ?? '') . "
            <p><strong>Reason given:</strong> " . htmlspecialchars($reason) . "</p>
            <p>Your apology has been logged. We hope to see you at a future meeting.</p>
            <p>Best regards,<br/><strong>{$schoolName}</strong></p>
        ");

        return self::send([
            'to'      => $booking['userEmail'],
            'toName'  => $booking['userName'],
            'subject' => "Cancellation Received — {$meeting['title']}",
            'html'    => $html,
        ]);
    }

    /** Send a meeting notification/announcement */
    public static function sendMeetingNotification(string $toEmail, string $toName, array $meeting, string $customMessage, array $sender, array $settings): array
    {
        $schoolName = $settings['schoolName'] ?? 'School';
        $date       = (new DateTime($meeting['date']))->format('l, d F Y');
        $slots      = count($meeting['timeSlots'] ?? []);
        $portalUrl  = env('APP_URL', 'https://create.sovereignai.co.ke');

        $html = self::emailTemplate($settings, $meeting['title'], "
            <p>Dear <strong>" . htmlspecialchars($toName ?: 'Parent/Guardian') . "</strong>,</p>
            " . ($customMessage ? "<p>" . nl2br(htmlspecialchars($customMessage)) . "</p>" : "") . "
            " . self::meetingBox($meeting['title'], $date, "{$slots} slots available", $meeting['location'] ?? '', $meeting['meetingLink'] ?? '') . "
            <p style='text-align:center;margin:28px 0'>
              <a href='{$portalUrl}' style='display:inline-block;padding:14px 32px;background:linear-gradient(135deg,#C8963E,#D9A94E);color:#0B1D35;font-weight:700;font-size:15px;border-radius:8px;text-decoration:none'>
                Book Your Slot →
              </a>
            </p>
            <p style='color:#888;font-size:13px'>This message was sent by {$sender['name']} via the {$schoolName} Meeting Portal.</p>
        ");

        return self::send([
            'to'      => $toEmail,
            'toName'  => $toName,
            'subject' => "Meeting Notice: {$meeting['title']} — {$date}",
            'html'    => $html,
            'replyTo' => $sender['email'] ?? '',
        ]);
    }

    /** Send a direct message from teacher/admin to parent */
    public static function sendDirectMessage(string $toEmail, string $toName, string $subject, string $messageBody, array $sender, array $settings): array
    {
        $schoolName = $settings['schoolName'] ?? 'School';
        $portalUrl  = env('APP_URL', 'https://create.sovereignai.co.ke');

        $html = self::emailTemplate($settings, $subject, "
            <p>Dear <strong>" . htmlspecialchars($toName ?: 'Parent/Guardian') . "</strong>,</p>
            <div style='background:#f7f9fc;border-left:4px solid #C8963E;padding:18px 22px;border-radius:0 8px 8px 0;margin:18px 0'>
              " . nl2br(htmlspecialchars($messageBody)) . "
            </div>
            <p style='margin-top:24px'>Sent by <strong>" . htmlspecialchars($sender['name']) . "</strong>
              " . ($sender['dept'] ? "({$sender['dept']})" : "") . "
              — <a href='mailto:{$sender['email']}'>{$sender['email']}</a>
            </p>
            <p style='color:#888;font-size:13px'>
              You can reply to this email or log in to the <a href='{$portalUrl}'>school portal</a> to send a message.
            </p>
        ");

        return self::send([
            'to'      => $toEmail,
            'toName'  => $toName,
            'subject' => $subject,
            'html'    => $html,
            'replyTo' => $sender['email'] ?? '',
        ]);
    }

    /** Send a message FROM a parent to a teacher/admin */
    public static function sendParentMessage(string $toEmail, string $toName, string $subject, string $messageBody, array $sender, array $settings): array
    {
        $schoolName = $settings['schoolName'] ?? 'School';

        $html = self::emailTemplate($settings, "Message from Parent: {$subject}", "
            <p>Dear <strong>" . htmlspecialchars($toName) . "</strong>,</p>
            <p>You have received a message from a parent/guardian via the school portal:</p>
            <div style='background:#f0f4ff;border-left:4px solid #1A56DB;padding:18px 22px;border-radius:0 8px 8px 0;margin:18px 0'>
              <p style='margin:0 0 8px 0;font-size:12px;text-transform:uppercase;letter-spacing:1px;color:#666'>From: {$sender['name']} ({$sender['email']})</p>
              " . nl2br(htmlspecialchars($messageBody)) . "
            </div>
            <p style='color:#888;font-size:13px'>You can reply directly to <a href='mailto:{$sender['email']}'>{$sender['email']}</a>.</p>
        ");

        return self::send([
            'to'      => $toEmail,
            'toName'  => $toName,
            'subject' => "Portal Message: {$subject}",
            'html'    => $html,
            'replyTo' => $sender['email'] ?? '',
        ]);
    }

    // ----------------------------------------------------------------
    // Email HTML template
    // ----------------------------------------------------------------
    private static function emailTemplate(array $settings, string $title, string $body): string
    {
        $schoolName = htmlspecialchars($settings['schoolName'] ?? 'School');
        $motto      = htmlspecialchars($settings['schoolMotto'] ?? '');
        $year       = date('Y');
        $logo       = $settings['logo'] ?? '🎓';
        $email      = htmlspecialchars($settings['email'] ?? '');
        $phone      = htmlspecialchars($settings['phone'] ?? '');

        return '<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1"/>
<title>' . htmlspecialchars($title) . '</title>
</head>
<body style="margin:0;padding:0;background:#f0f2f5;font-family:\'Segoe UI\',Arial,sans-serif">
<table width="100%" cellpadding="0" cellspacing="0" border="0" style="background:#f0f2f5;padding:32px 16px">
  <tr><td align="center">
    <table width="600" cellpadding="0" cellspacing="0" border="0" style="max-width:600px;width:100%">

      <!-- Header -->
      <tr><td style="background:linear-gradient(135deg,#060F1F 0%,#1E3868 100%);padding:32px 36px;border-radius:16px 16px 0 0;text-align:center">
        <div style="font-size:40px;margin-bottom:10px">' . $logo . '</div>
        <div style="font-family:Georgia,serif;font-size:22px;font-weight:700;color:#fff;margin-bottom:4px">' . $schoolName . '</div>
        <div style="font-size:11px;color:rgba(255,255,255,.45);letter-spacing:2px;text-transform:uppercase">' . $motto . '</div>
      </td></tr>

      <!-- Title bar -->
      <tr><td style="background:#C8963E;padding:12px 36px">
        <div style="font-size:14px;font-weight:700;color:#0B1D35;letter-spacing:.5px">' . htmlspecialchars($title) . '</div>
      </td></tr>

      <!-- Body -->
      <tr><td style="background:#ffffff;padding:36px;font-size:15px;line-height:1.7;color:#1E2D45;border-radius:0 0 16px 16px">
        ' . $body . '
      </td></tr>

      <!-- Footer -->
      <tr><td style="padding:24px 36px;text-align:center">
        <p style="font-size:12px;color:#999;margin:0">' . $schoolName . ' · ' . $email . ' · ' . $phone . '</p>
        <p style="font-size:11px;color:#bbb;margin:6px 0 0">© ' . $year . ' All rights reserved · Sent via School Meeting Portal</p>
      </td></tr>

    </table>
  </td></tr>
</table>
</body>
</html>';
    }

    /** Reusable meeting details box */
    private static function meetingBox(string $title, string $date, string $slot, string $location, string $link = ''): string
    {
        $linkRow = $link ? "<tr><td style='padding:6px 0;font-size:14px;color:#555'><strong style='color:#0B1D35;min-width:80px;display:inline-block'>🎥 Online:</strong> <a href='" . htmlspecialchars($link) . "' style='color:#1A56DB'>Join Meeting</a></td></tr>" : '';
        return "
        <table width='100%' cellpadding='0' cellspacing='0' border='0' style='background:#f7f9fc;border:1.5px solid #e0e9f5;border-radius:10px;padding:0;margin:18px 0'>
          <tr><td style='padding:18px 22px'>
            <div style='font-size:13px;font-weight:700;color:#C8963E;text-transform:uppercase;letter-spacing:1px;margin-bottom:10px'>Meeting Details</div>
            <table>
              <tr><td style='padding:6px 0;font-size:14px;color:#555'><strong style='color:#0B1D35;min-width:80px;display:inline-block'>📅 Meeting:</strong> " . htmlspecialchars($title) . "</td></tr>
              <tr><td style='padding:6px 0;font-size:14px;color:#555'><strong style='color:#0B1D35;min-width:80px;display:inline-block'>🗓 Date:</strong> " . htmlspecialchars($date) . "</td></tr>
              <tr><td style='padding:6px 0;font-size:14px;color:#555'><strong style='color:#0B1D35;min-width:80px;display:inline-block'>🕐 Slot:</strong> " . htmlspecialchars($slot) . "</td></tr>
              <tr><td style='padding:6px 0;font-size:14px;color:#555'><strong style='color:#0B1D35;min-width:80px;display:inline-block'>📍 Location:</strong> " . htmlspecialchars($location ?: 'School Campus') . "</td></tr>
              {$linkRow}
            </table>
          </td></tr>
        </table>";
    }

    /** RFC 2047 encode a header value */
    private static function encodeHeader(string $value): string
    {
        if (preg_match('/[^\x20-\x7E]/', $value) || mb_strlen($value) > 75) {
            return '=?UTF-8?B?' . base64_encode($value) . '?=';
        }
        // Wrap in quotes if contains special chars
        if (preg_match('/[(),.:;<>@\[\]\\"]/', $value)) {
            return '"' . addslashes($value) . '"';
        }
        return $value;
    }

    /** Build MIME multipart/alternative body */
    private static function buildMessage(string $html, string $text, string $boundary): string
    {
        $body  = "--{$boundary}\r\n";
        $body .= "Content-Type: text/plain; charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: quoted-printable\r\n\r\n";
        $body .= quoted_printable_encode($text) . "\r\n\r\n";
        $body .= "--{$boundary}\r\n";
        $body .= "Content-Type: text/html; charset=UTF-8\r\n";
        $body .= "Content-Transfer-Encoding: quoted-printable\r\n\r\n";
        $body .= quoted_printable_encode($html) . "\r\n\r\n";
        $body .= "--{$boundary}--\r\n";
        return $body;
    }
}

// ================================================================
// SmtpSocket — Low-level SMTP client using PHP stream sockets
// ================================================================
class SmtpSocket
{
    private $socket;
    private string $host;
    private int    $port;
    private string $encryption;

    public function __construct(string $host, int $port, string $encryption)
    {
        $this->host       = $host;
        $this->port       = $port;
        $this->encryption = $encryption;
    }

    public function connect(): void
    {
        $timeout  = 15;
        $errno    = 0;
        $errstr   = '';

        if ($this->encryption === 'ssl') {
            $address = "ssl://{$this->host}:{$this->port}";
        } else {
            $address = "tcp://{$this->host}:{$this->port}";
        }

        $this->socket = @stream_socket_client($address, $errno, $errstr, $timeout);

        if (!$this->socket) {
            throw new RuntimeException("SMTP connect failed to {$address}: [{$errno}] {$errstr}");
        }

        stream_set_timeout($this->socket, $timeout);
        $this->expect(220, 'connect');
    }

    public function ehlo(): void
    {
        $hostname = gethostname() ?: 'sovereignai.co.ke';
        $this->send("EHLO {$hostname}");
        $this->expect(250, 'EHLO');
    }

    public function starttls(): void
    {
        $this->send('STARTTLS');
        $this->expect(220, 'STARTTLS');

        if (!stream_socket_enable_crypto($this->socket, true, STREAM_CRYPTO_METHOD_TLS_CLIENT)) {
            throw new RuntimeException('STARTTLS crypto upgrade failed');
        }
    }

    public function auth(string $user, string $pass): void
    {
        $this->send('AUTH LOGIN');
        $this->expect(334, 'AUTH LOGIN');
        $this->send(base64_encode($user));
        $this->expect(334, 'AUTH username');
        $this->send(base64_encode($pass));
        $this->expect(235, 'AUTH password');
    }

    public function mail(string $from): void
    {
        $this->send("MAIL FROM:<{$from}>");
        $this->expect(250, 'MAIL FROM');
    }

    public function rcpt(string $to): void
    {
        $this->send("RCPT TO:<{$to}>");
        $this->expect(250, 'RCPT TO');
    }

    public function data(string $message): void
    {
        $this->send('DATA');
        $this->expect(354, 'DATA');

        // Dot-stuffing: escape lines starting with '.'
        $message = preg_replace('/^\./', '..', $message);
        $this->send($message . "\r\n.");
        $this->expect(250, 'DATA body');
    }

    public function quit(): void
    {
        $this->send('QUIT');
        fclose($this->socket);
    }

    private function send(string $cmd): void
    {
        fwrite($this->socket, $cmd . "\r\n");
    }

    private function expect(int $code, string $context): string
    {
        $response = '';
        while ($line = fgets($this->socket, 512)) {
            $response .= $line;
            // Multi-line responses use '-' after the code; last line uses ' '
            if (substr($line, 3, 1) === ' ') break;
        }

        $actual = (int) substr($response, 0, 3);
        if ($actual !== $code) {
            throw new RuntimeException("SMTP {$context}: expected {$code}, got {$actual}. Response: " . trim($response));
        }

        return $response;
    }
}
