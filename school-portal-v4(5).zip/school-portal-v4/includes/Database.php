<?php
// ================================================================
// includes/Database.php — JSON Flat-File Database
// ================================================================
// Simple key-value / document store backed by JSON files.
// Acts as the "database layer" for the portal.
//
// Usage:
//   $db = Database::getInstance();
//   $meetings = $db->all('meetings');
//   $db->insert('meetings', ['title' => 'Term Day', ...]);
//   $db->update('meetings', 'id', $id, ['title' => 'Updated']);
//   $db->delete('meetings', 'id', $id);
// ================================================================

class Database
{
    private static ?Database $instance = null;
    private array $cache = [];

    // ----------------------------------------------------------------
    // Table → file path mapping
    // ----------------------------------------------------------------
    private array $tables = [
        'meetings'  => DB_MEETINGS,
        'bookings'  => DB_BOOKINGS,
        'apologies' => DB_APOLOGIES,
        'messages'  => DB_MESSAGES,
        'settings'  => DB_SETTINGS,
        'users'     => DB_USERS,
        'audit'     => DB_AUDIT,
        'sessions'  => DB_SESSIONS,
        'chats'     => DB_CHATS,
    ];

    private function __construct()
    {
        $this->ensureDirectories();
        $this->ensureFiles();
    }

    public static function getInstance(): self
    {
        if (self::$instance === null) {
            self::$instance = new self();
        }
        return self::$instance;
    }

    // ----------------------------------------------------------------
    // Read all records from a table
    // ----------------------------------------------------------------
    public function all(string $table): array
    {
        if (isset($this->cache[$table])) {
            return $this->cache[$table];
        }

        $path = $this->getPath($table);
        if (!file_exists($path)) {
            return [];
        }

        $raw  = file_get_contents($path);
        $data = json_decode($raw, true);

        $result = is_array($data) ? $data : [];
        $this->cache[$table] = $result;
        return $result;
    }

    // ----------------------------------------------------------------
    // Find a single record by field value
    // ----------------------------------------------------------------
    public function find(string $table, string $field, mixed $value): ?array
    {
        foreach ($this->all($table) as $record) {
            if (isset($record[$field]) && $record[$field] === $value) {
                return $record;
            }
        }
        return null;
    }

    // ----------------------------------------------------------------
    // Filter records by callable or field=value
    // ----------------------------------------------------------------
    public function where(string $table, callable|string $fieldOrCallback, mixed $value = null): array
    {
        $records = $this->all($table);

        if (is_callable($fieldOrCallback)) {
            return array_values(array_filter($records, $fieldOrCallback));
        }

        return array_values(array_filter($records, function ($r) use ($fieldOrCallback, $value) {
            return isset($r[$fieldOrCallback]) && $r[$fieldOrCallback] === $value;
        }));
    }

    // ----------------------------------------------------------------
    // Insert a new record
    // ----------------------------------------------------------------
    public function insert(string $table, array $record): array
    {
        if (!isset($record['id'])) {
            $record['id'] = $table[0] . '_' . bin2hex(random_bytes(6));
        }
        if (!isset($record['createdAt'])) {
            $record['createdAt'] = date('c');
        }

        $records   = $this->all($table);
        $records[] = $record;
        $this->write($table, $records);
        return $record;
    }

    // ----------------------------------------------------------------
    // Update a record by field=value
    // ----------------------------------------------------------------
    public function update(string $table, string $field, mixed $value, array $changes): bool
    {
        $records = $this->all($table);
        $found   = false;

        foreach ($records as &$record) {
            if (isset($record[$field]) && $record[$field] === $value) {
                $record = array_merge($record, $changes);
                $record['updatedAt'] = date('c');
                $found = true;
                break;
            }
        }
        unset($record);

        if ($found) {
            $this->write($table, $records);
        }
        return $found;
    }

    // ----------------------------------------------------------------
    // Delete a record by field=value
    // ----------------------------------------------------------------
    public function delete(string $table, string $field, mixed $value): bool
    {
        $records = $this->all($table);
        $before  = count($records);
        $records = array_values(array_filter($records, function ($r) use ($field, $value) {
            return !isset($r[$field]) || $r[$field] !== $value;
        }));

        if (count($records) < $before) {
            $this->write($table, $records);
            return true;
        }
        return false;
    }

    // ----------------------------------------------------------------
    // Delete multiple records by callable filter
    // ----------------------------------------------------------------
    public function deleteWhere(string $table, callable $filter): int
    {
        $records = $this->all($table);
        $before  = count($records);
        $records = array_values(array_filter($records, fn($r) => !$filter($r)));

        $deleted = $before - count($records);
        if ($deleted > 0) {
            $this->write($table, $records);
        }
        return $deleted;
    }

    // ----------------------------------------------------------------
    // Count records
    // ----------------------------------------------------------------
    public function count(string $table, ?callable $filter = null): int
    {
        $records = $this->all($table);
        if ($filter) {
            return count(array_filter($records, $filter));
        }
        return count($records);
    }

    // ----------------------------------------------------------------
    // Get/Set settings (key-value store on settings.json)
    // ----------------------------------------------------------------
    public function getSettings(): array
    {
        $path = $this->getPath('settings');
        if (!file_exists($path)) {
            return unserialize(DEFAULT_SCHOOL_SETTINGS);
        }
        $data = json_decode(file_get_contents($path), true);
        return is_array($data)
            ? array_merge(unserialize(DEFAULT_SCHOOL_SETTINGS), $data)
            : unserialize(DEFAULT_SCHOOL_SETTINGS);
    }

    public function saveSettings(array $settings): void
    {
        $path = $this->getPath('settings');
        file_put_contents($path, json_encode($settings, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        unset($this->cache['settings']);
    }

    // ----------------------------------------------------------------
    // Write JSON to disk with atomic write + file locking
    // ----------------------------------------------------------------
    private function write(string $table, array $data): void
    {
        $path    = $this->getPath($table);
        $json    = json_encode($data, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE);
        $tmpPath = $path . '.tmp.' . getmypid();

        file_put_contents($tmpPath, $json, LOCK_EX);
        rename($tmpPath, $path); // Atomic replace

        // Invalidate cache
        unset($this->cache[$table]);
    }

    // ----------------------------------------------------------------
    // Get absolute file path for a table
    // ----------------------------------------------------------------
    private function getPath(string $table): string
    {
        if (!isset($this->tables[$table])) {
            throw new RuntimeException("Unknown table: $table");
        }
        return $this->tables[$table];
    }

    // ----------------------------------------------------------------
    // Ensure data directories exist
    // ----------------------------------------------------------------
    private function ensureDirectories(): void
    {
        foreach ([DATA_DIR, LOGS_DIR, CACHE_DIR] as $dir) {
            if (!is_dir($dir)) {
                mkdir($dir, 0755, true);
            }
        }
    }

    // ----------------------------------------------------------------
    // Ensure JSON files exist with empty arrays
    // ----------------------------------------------------------------
    private function ensureFiles(): void
    {
        foreach ($this->tables as $table => $path) {
            if ($table === 'settings') {
                continue; // Settings file is handled separately
            }
            if (!file_exists($path)) {
                file_put_contents($path, '[]', LOCK_EX);
                chmod($path, 0644);
            }
        }
    }

    // ----------------------------------------------------------------
    // Backup all data to a single JSON snapshot
    // ----------------------------------------------------------------
    public function backup(): string
    {
        $snapshot = [];
        foreach ($this->tables as $table => $path) {
            $snapshot[$table] = file_exists($path)
                ? json_decode(file_get_contents($path), true)
                : [];
        }
        $filename = CACHE_DIR . 'backup_' . date('Y-m-d_His') . '.json';
        file_put_contents($filename, json_encode($snapshot, JSON_PRETTY_PRINT | JSON_UNESCAPED_UNICODE), LOCK_EX);
        return $filename;
    }

    // ----------------------------------------------------------------
    // Prevent cloning & unserialization
    // ----------------------------------------------------------------
    private function __clone() {}
    public function __wakeup(): void
    {
        throw new RuntimeException('Cannot unserialize singleton.');
    }
}
