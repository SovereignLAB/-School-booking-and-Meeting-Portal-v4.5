<?php
// ================================================================
// includes/Audit.php — Audit Trail Logger
// ================================================================
// Logs key user actions to data/audit_log.json.
// Each entry records who did what and when.
// ================================================================

class Audit
{
    private static Database $db;

    private static function db(): Database
    {
        if (!isset(self::$db)) {
            self::$db = Database::getInstance();
        }
        return self::$db;
    }

    /**
     * Log an action.
     *
     * @param string $action   Short action code, e.g. 'meeting.created'
     * @param string $details  Human-readable description
     * @param array  $meta     Extra data (IDs, field values, etc.)
     */
    public static function log(string $action, string $details, array $meta = []): void
    {
        if (!FEATURE_AUDIT_LOG) {
            return;
        }

        $user = currentUser();

        $entry = [
            'id'        => uid('aud'),
            'action'    => $action,
            'details'   => $details,
            'userId'    => $user['id']   ?? 'anonymous',
            'userName'  => $user['name'] ?? 'Anonymous',
            'userRole'  => $user['role'] ?? 'guest',
            'ip'        => self::getIp(),
            'userAgent' => $_SERVER['HTTP_USER_AGENT'] ?? '',
            'meta'      => $meta,
            'createdAt' => ts(),
        ];

        try {
            self::db()->insert('audit', $entry);
        } catch (Throwable $e) {
            // Never let audit logging crash the app
            appLog('error', 'Audit log failed: ' . $e->getMessage());
        }
    }

    /** Get the real client IP (cPanel / proxy aware) */
    private static function getIp(): string
    {
        foreach (['HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR'] as $key) {
            if (!empty($_SERVER[$key])) {
                $ip = explode(',', $_SERVER[$key])[0];
                return trim(filter_var($ip, FILTER_VALIDATE_IP) ?: 'unknown');
            }
        }
        return 'unknown';
    }

    /** Get recent audit entries (for admin dashboard) */
    public static function recent(int $limit = 50): array
    {
        $entries = self::db()->all('audit');
        $entries = array_reverse($entries); // newest first
        return array_slice($entries, 0, $limit);
    }

    /** Clear old audit entries (keep last 90 days) */
    public static function prune(int $days = 90): int
    {
        $cutoff = (new DateTime())->modify("-{$days} days")->format('c');
        return self::db()->deleteWhere('audit', fn($e) => ($e['createdAt'] ?? '') < $cutoff);
    }
}
