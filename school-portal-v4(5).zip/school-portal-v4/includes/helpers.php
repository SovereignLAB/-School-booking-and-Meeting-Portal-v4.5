<?php
// ================================================================
// includes/helpers.php — Global Utility Functions
// ================================================================

// ----------------------------------------------------------------
// Sanitisation & escaping
// ----------------------------------------------------------------

/** HTML-safe output */
function e(?string $s): string
{
    return htmlspecialchars($s ?? '', ENT_QUOTES | ENT_HTML5, 'UTF-8');
}

/** JSON-encode safely for inline script tags */
function jd(mixed $d): string
{
    return json_encode($d, JSON_HEX_QUOT | JSON_HEX_TAG | JSON_HEX_AMP | JSON_UNESCAPED_UNICODE);
}

// ----------------------------------------------------------------
// HTTP & Responses
// ----------------------------------------------------------------

/** Send a JSON response and halt */
function jo(mixed $data, int $code = 200): never
{
    http_response_code($code);
    if (!headers_sent()) {
        header('Content-Type: application/json; charset=UTF-8');
        header('X-Content-Type-Options: nosniff');
        header('Cache-Control: no-store, no-cache, must-revalidate');
    }
    echo json_encode($data, JSON_UNESCAPED_UNICODE);
    exit;
}

/** Redirect and halt */
function redirect(string $url): never
{
    header('Location: ' . $url, true, 302);
    exit;
}

// ----------------------------------------------------------------
// Date & Time
// ----------------------------------------------------------------

/** ISO 8601 timestamp */
function ts(): string
{
    return date('c');
}

/** Human-friendly date */
function humanDate(string $datetime): string
{
    return (new DateTime($datetime))->format('D, d M Y');
}

/** Days from now (negative = past) */
function daysFromNow(string $date): int
{
    $now  = new DateTime();
    $then = new DateTime($date);
    $diff = (int) $now->diff($then)->days;
    return $then >= $now ? $diff : -$diff;
}

// ----------------------------------------------------------------
// ID Generation
// ----------------------------------------------------------------

/** Generate a prefixed unique ID */
function uid(string $prefix = 'id'): string
{
    return $prefix . '_' . bin2hex(random_bytes(6));
}

// ----------------------------------------------------------------
// CSRF
// ----------------------------------------------------------------

/** Get current CSRF token */
function csrfToken(): string
{
    return $_SESSION[CSRF_TOKEN_NAME] ?? '';
}

/** Verify CSRF token from POST */
function verifyCsrf(): bool
{
    $token = $_POST[CSRF_TOKEN_NAME]
          ?? $_SERVER['HTTP_X_CSRF_TOKEN']
          ?? '';
    return hash_equals(csrfToken(), $token);
}

// ----------------------------------------------------------------
// Rate limiting (file-based)
// ----------------------------------------------------------------

function checkRateLimit(string $key, int $maxRequests = RATE_LIMIT_REQUESTS, int $window = RATE_LIMIT_WINDOW): bool
{
    if (!RATE_LIMIT_ENABLED) {
        return true;
    }

    $file = CACHE_DIR . 'rl_' . md5($key) . '.json';
    $now  = time();

    $data = [];
    if (file_exists($file)) {
        $raw  = file_get_contents($file);
        $data = json_decode($raw, true) ?? [];
    }

    // Filter out old timestamps
    $requests = array_values(array_filter($data['requests'] ?? [], fn($t) => $t > ($now - $window)));

    if (count($requests) >= $maxRequests) {
        return false; // Rate limited
    }

    $requests[] = $now;
    file_put_contents($file, json_encode(['requests' => $requests]), LOCK_EX);
    return true;
}

// ----------------------------------------------------------------
// Input handling
// ----------------------------------------------------------------

/** Get and trim a value from POST/GET */
function input(string $key, string $default = ''): string
{
    $val = $_POST[$key] ?? $_GET[$key] ?? $default;
    return trim((string) $val);
}

/** Get JSON body from php://input */
function jsonBody(): array
{
    $raw = file_get_contents('php://input');
    $decoded = json_decode($raw, true);
    return is_array($decoded) ? $decoded : $_POST;
}

// ----------------------------------------------------------------
// Auth helpers
// ----------------------------------------------------------------

/** Get current user from session */
function currentUser(): ?array
{
    return $_SESSION['user'] ?? null;
}

/** Check if user is logged in */
function isLoggedIn(): bool
{
    return !empty($_SESSION['user']);
}

/** Check role(s) */
function hasRole(string ...$roles): bool
{
    $user = currentUser();
    return $user && in_array($user['role'], $roles, true);
}

/** Require login or return 401 JSON */
function requireAuth(): array
{
    $user = currentUser();
    if (!$user) {
        jo(['error' => 'Not authenticated'], 401);
    }
    return $user;
}

/** Require specific role(s) */
function requireRole(string ...$roles): array
{
    $user = requireAuth();
    if (!in_array($user['role'], $roles, true)) {
        jo(['error' => 'Insufficient permissions'], 403);
    }
    return $user;
}

// ----------------------------------------------------------------
// String utilities
// ----------------------------------------------------------------

/** Generate initials from a full name */
function initials(string $name): string
{
    $parts = preg_split('/\s+/', trim($name));
    return implode('', array_slice(array_map(fn($w) => strtoupper($w[0] ?? ''), $parts), 0, 2));
}

/** Pluralise a word based on count */
function plural(int $count, string $word, string $plural = ''): string
{
    if ($count === 1) return $word;
    return $plural ?: $word . 's';
}

// ----------------------------------------------------------------
// Logging
// ----------------------------------------------------------------

/** Write to the application log */
function appLog(string $level, string $message, array $context = []): void
{
    $entry = sprintf(
        "[%s] [%s] %s %s\n",
        date('Y-m-d H:i:s'),
        strtoupper($level),
        $message,
        $context ? json_encode($context) : ''
    );
    $logFile = LOGS_DIR . 'app_' . date('Y-m') . '.log';
    @file_put_contents($logFile, $entry, FILE_APPEND | LOCK_EX);
}
