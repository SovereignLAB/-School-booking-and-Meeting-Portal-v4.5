<?php
// ================================================================
// includes/bootstrap.php — Application Bootstrap
// ================================================================
// This file is included at the very top of index.php.
// It loads config, env, helpers, starts the session, and
// initialises the database singleton.
// ================================================================

// ----------------------------------------------------------------
// 1. Base path resolution (always relative to project root)
// ----------------------------------------------------------------
if (!defined('ROOT_DIR')) {
    define('ROOT_DIR', dirname(__DIR__));
}

// ----------------------------------------------------------------
// 2. Load app config (defines constants)
// ----------------------------------------------------------------
require_once ROOT_DIR . '/config/app.php';

// ----------------------------------------------------------------
// 3. Load .env file (overrides defaults with real credentials)
// ----------------------------------------------------------------
require_once ROOT_DIR . '/config/env.php';

// ----------------------------------------------------------------
// 4. Load helper functions
// ----------------------------------------------------------------
require_once INC_DIR . 'helpers.php';

// ----------------------------------------------------------------
// 5. Load the Database class
// ----------------------------------------------------------------
require_once INC_DIR . 'Database.php';

// ----------------------------------------------------------------
// 6. Load the Audit logger
// ----------------------------------------------------------------
require_once INC_DIR . 'Audit.php';

// ----------------------------------------------------------------
// 7. Load the Mailer
// ----------------------------------------------------------------
require_once INC_DIR . 'Mailer.php';

// ----------------------------------------------------------------
// 7. Maintenance mode check
// ----------------------------------------------------------------
if (FEATURE_MAINTENANCE_MODE) {
    $requestedAction = $_GET['action'] ?? $_POST['action'] ?? '';
    $isMaintAdmin    = ($_POST['role'] ?? '') === 'admin';
    if (!$isMaintAdmin && !in_array($requestedAction, ['login', 'logout'], true)) {
        http_response_code(503);
        echo '<!DOCTYPE html><html><head><title>Maintenance</title><meta name="viewport" content="width=device-width,initial-scale=1"/></head><body style="font-family:sans-serif;display:flex;align-items:center;justify-content:center;min-height:100vh;margin:0;background:#060F1F;color:#fff;text-align:center;padding:24px">';
        echo '<div><div style="font-size:48px;margin-bottom:16px">🔧</div>';
        echo '<h1 style="font-family:serif;font-size:28px;margin-bottom:12px">Under Maintenance</h1>';
        echo '<p style="color:rgba(255,255,255,.5);max-width:400px;line-height:1.7">' . htmlspecialchars(MAINTENANCE_MESSAGE) . '</p></div></body></html>';
        exit;
    }
}

// ----------------------------------------------------------------
// 8. Session configuration
// ----------------------------------------------------------------
ini_set('session.name',            SESSION_NAME);
ini_set('session.gc_maxlifetime',  SESSION_LIFETIME);
ini_set('session.cookie_lifetime', 0); // Browser session cookie
ini_set('session.cookie_httponly', SESSION_HTTPONLY ? '1' : '0');
ini_set('session.cookie_samesite', 'Strict');
ini_set('session.use_strict_mode', '1');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

// Regenerate session ID periodically to prevent fixation
if (!isset($_SESSION['_last_regen'])) {
    $_SESSION['_last_regen'] = time();
} elseif (time() - $_SESSION['_last_regen'] > 1800) {
    session_regenerate_id(true);
    $_SESSION['_last_regen'] = time();
}

// ----------------------------------------------------------------
// 9. CSRF token initialisation
// ----------------------------------------------------------------
if (empty($_SESSION[CSRF_TOKEN_NAME])) {
    $_SESSION[CSRF_TOKEN_NAME] = bin2hex(random_bytes(32));
}

// ----------------------------------------------------------------
// 10. Initialise Database singleton (creates dirs/files if needed)
// ----------------------------------------------------------------
$db = Database::getInstance();

// ----------------------------------------------------------------
// 11. Set security headers
// (these complement what .htaccess sets — belt-and-suspenders)
// ----------------------------------------------------------------
if (!headers_sent()) {
    header_remove('X-Powered-By');
    header('X-Content-Type-Options: nosniff');
    header('X-Frame-Options: SAMEORIGIN');
}
