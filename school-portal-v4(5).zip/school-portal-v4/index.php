<?php
// ============================================================
// SCHOOL MEETING MANAGEMENT SYSTEM — v3.0
// create.sovereignai.co.ke  |  cPanel Edition
// ============================================================
if (!defined('ROOT_DIR')) define('ROOT_DIR', __DIR__);
require_once __DIR__ . '/includes/bootstrap.php';
function loadSettings(){ return Database::getInstance()->getSettings(); }
function defS(){ return unserialize(DEFAULT_SCHOOL_SETTINGS); }

// ── DB shims ─────────────────────────────────────────────────
function ld($n){ return Database::getInstance()->all($n); }
function sd($n,$d){ file_put_contents(DATA_DIR.$n.'.json',json_encode($d,JSON_PRETTY_PRINT|JSON_UNESCAPED_UNICODE),LOCK_EX); }

// ── CBC Kenya grade streams helper ──────────────────────────
function cbcGrades(){
  $grades=[];
  for($g=1;$g<=10;$g++) $grades[]="Grade $g";
  return $grades;
}
function buildClassList(array $settings): array {
  // Combine base CBC grades with any custom streams the school has defined
  $custom = $settings['customStreams'] ?? [];
  $base   = cbcGrades();
  $all    = array_unique(array_merge($base, $custom));
  sort($all, SORT_NATURAL);
  return $all;
}

// ── Seed default admin on first run ────────────────────────
function seedDefaultAdmin(){
  $users = ld('users');
  if(!empty($users)) return;   // already seeded
  $admin = [
    'id'          => 'admin_seed',
    'role'        => 'admin',
    'name'        => 'School Admin',
    'email'       => 'admin@sovereignai.co.ke',
    'phone'       => '',
    'password'    => password_hash('Admin@1234', PASSWORD_DEFAULT),
    'color'       => '#C8963E',
    'badge'       => 'Admin',
    'avatar'      => '',
    'bio'         => 'Default admin account. Please update your details after first login.',
    'dept'        => 'Administration',
    'streams'     => [],
    'class'       => '',
    'studentName' => '',
    'createdAt'   => date('c'),
    'updatedAt'   => date('c'),
  ];
  sd('users', [$admin]);
}
seedDefaultAdmin();

// ── Role colours ─────────────────────────────────────────────
function roleColor(string $role): string {
  return ['parent'=>'#2563EB','teacher'=>'#059669','principal'=>'#7C3AED','admin'=>'#C8963E'][$role] ?? '#475569';
}

$action = $_GET['action'] ?? $_POST['action'] ?? '';

// ════════════════════════════════════════════════════════════
// AUTH: REGISTER
// ════════════════════════════════════════════════════════════
if($action==='register'){
  $b = json_decode(file_get_contents('php://input'),true)?:$_POST;
  $role   = trim($b['role']??'');
  $name   = trim($b['name']??'');
  $email  = strtolower(trim($b['email']??''));
  $phone  = trim($b['phone']??'');
  $pwd    = $b['password']??'';
  $pwd2   = $b['password2']??'';

  if(!in_array($role,['parent','teacher','principal','admin'])) jo(['error'=>'Invalid role'],400);
  if(!$name||strlen($name)<2) jo(['error'=>'Full name is required (min 2 characters)'],400);
  if(!filter_var($email,FILTER_VALIDATE_EMAIL)) jo(['error'=>'Valid email address is required'],400);
  if(strlen($pwd)<6) jo(['error'=>'Password must be at least 6 characters'],400);
  if($pwd!==$pwd2) jo(['error'=>'Passwords do not match'],400);

  $users = ld('users');
  foreach($users as $u){ if(strtolower($u['email'])===$email) jo(['error'=>'An account with this email already exists'],409); }

  $id = uid('u');
  $newUser = [
    'id'          => $id,
    'role'        => $role,
    'name'        => $name,
    'email'       => $email,
    'phone'       => $phone,
    'password'    => password_hash($pwd, PASSWORD_DEFAULT),
    'color'       => roleColor($role),
    'badge'       => ucfirst($role),
    'avatar'      => '',         // base64 data-URI or empty
    'bio'         => '',
    'createdAt'   => ts(),
    'updatedAt'   => ts(),
  ];

  // Role-specific fields
  if($role==='parent'){
    $newUser['studentName'] = trim($b['studentName']??'');
    $newUser['studentClass']= trim($b['studentClass']??'');   // e.g. "Grade 4 B"
    $newUser['class']       = $newUser['studentClass'];
    $newUser['dept']        = '';
  } elseif($role==='teacher'){
    $newUser['studentName'] = '';
    $newUser['dept']        = trim($b['dept']??'');
    $streams = $b['streams']??[];  // array of class streams teacher handles
    if(!is_array($streams)) $streams = array_filter(array_map('trim',explode(',',$streams)));
    $newUser['streams']     = array_values(array_unique($streams));
    $newUser['class']       = count($streams)>0 ? $streams[0] : '';
  } else {
    $newUser['studentName'] = '';
    $newUser['dept']        = trim($b['dept']??'');
    $newUser['streams']     = [];
    $newUser['class']       = '';
  }

  $users[] = $newUser;
  sd('users',$users);
  Audit::log('user.registered','New user registered',['id'=>$id,'role'=>$role,'email'=>$email]);
  jo(['ok'=>true,'message'=>'Account created successfully! You can now sign in.']);
}

// ════════════════════════════════════════════════════════════
// AUTH: LOGIN
// ════════════════════════════════════════════════════════════
if($action==='login'){
  $b     = json_decode(file_get_contents('php://input'),true)?:$_POST;
  $email = strtolower(trim($b['email']??''));
  $pwd   = $b['password']??'';
  $role  = trim($b['role']??'');

  if(!$email||!$pwd) jo(['error'=>'Email and password are required'],400);

  $users = ld('users');
  $found = null;
  foreach($users as $u){
    if(strtolower($u['email'])===$email){$found=$u;break;}
  }
  if(!$found) jo(['error'=>'No account found with that email address'],401);
  if($role && $found['role']!==$role) jo(['error'=>'This email is registered as '.ucfirst($found['role']).', not '.ucfirst($role)],401);
  if(!password_verify($pwd,$found['password']??'')) jo(['error'=>'Incorrect password'],401);

  // Strip password from session
  unset($found['password']);
  $_SESSION['user'] = $found;
  Audit::log('user.login','User signed in',['id'=>$found['id'],'role'=>$found['role']]);
  jo(['ok'=>true,'role'=>$found['role']]);
}

if($action==='logout'){ session_destroy(); jo(['ok'=>true]); }

// ════════════════════════════════════════════════════════════
// PROFILE: Update details & password
// ════════════════════════════════════════════════════════════
if($action==='api_profile'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b   = json_decode(file_get_contents('php://input'),true)?:$_POST;
  $uid = $_SESSION['user']['id'];
  $users = ld('users');
  $idx   = null;
  foreach($users as $i=>$u){ if($u['id']===$uid){$idx=$i;break;} }
  if($idx===null) jo(['error'=>'User not found'],404);

  $u = $users[$idx];

  // Name / phone / bio
  if(!empty($b['name']))  $u['name']  = trim($b['name']);
  if(isset($b['phone']))  $u['phone'] = trim($b['phone']);
  if(isset($b['bio']))    $u['bio']   = trim($b['bio']);

  // Avatar (base64 data-URI, max ~500KB)
  if(!empty($b['avatar'])){
    if(strlen($b['avatar'])>700000) jo(['error'=>'Image too large. Please use an image under 500KB.'],400);
    $u['avatar'] = $b['avatar'];
  }

  // Class/stream updates
  if($u['role']==='parent'){
    if(isset($b['studentName']))  $u['studentName']  = trim($b['studentName']);
    if(isset($b['studentClass'])){ $u['studentClass']=$u['class']=trim($b['studentClass']); }
  } elseif($u['role']==='teacher'){
    if(isset($b['dept'])) $u['dept'] = trim($b['dept']);
    if(isset($b['streams'])&&is_array($b['streams'])){
      $u['streams'] = array_values(array_unique(array_map('trim',$b['streams'])));
      if(count($u['streams'])>0) $u['class']=$u['streams'][0];
    }
  }

  // Password change
  if(!empty($b['newPassword'])){
    if(empty($b['currentPassword'])) jo(['error'=>'Current password is required to set a new one'],400);
    $fullUser = $users[$idx];
    if(!password_verify($b['currentPassword'],$fullUser['password']??'')) jo(['error'=>'Current password is incorrect'],401);
    if(strlen($b['newPassword'])<6) jo(['error'=>'New password must be at least 6 characters'],400);
    if($b['newPassword']!==($b['confirmPassword']??'')) jo(['error'=>'New passwords do not match'],400);
    $u['password'] = password_hash($b['newPassword'],PASSWORD_DEFAULT);
  }

  $u['updatedAt'] = ts();
  $users[$idx] = $u;
  sd('users',$users);

  // Update session (without password)
  $sessionUser = $u; unset($sessionUser['password']);
  $_SESSION['user'] = $sessionUser;

  Audit::log('user.profile_updated','User updated profile',['id'=>$uid]);
  jo(['ok'=>true,'user'=>$sessionUser]);
}
if($action==='api_create'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST;
  $meetingType = trim($b['meetingType']??'physical');
  if(!in_array($meetingType,['physical','online','hybrid'])) $meetingType='physical';
  $m=['id'=>uid('m'),'title'=>trim($b['title']??''),'description'=>trim($b['description']??''),
    'date'=>$b['date']??'','class'=>trim($b['class']??''),'location'=>trim($b['location']??''),
    'meetingLink'=>trim($b['meetingLink']??''),'icon'=>$b['icon']??'📅',
    'meetingType'=>$meetingType,
    'targetParentId'=>trim($b['targetParentId']??''),
    'timeSlots'=>$b['timeSlots']??[],'createdAt'=>ts(),'createdBy'=>$_SESSION['user']['id']];
  if(!$m['title']||!$m['date']) jo(['error'=>'Title and date required'],400);
  $ms=ld('meetings'); $ms[]=$m; sd('meetings',$ms); jo(['ok'=>true,'meeting'=>$m]);
}
if($action==='api_edit'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST; $ms=ld('meetings');
  foreach($ms as &$m){ if($m['id']===$b['id']){ $m['title']=trim($b['title']??$m['title']); $m['description']=trim($b['description']??$m['description']); $m['date']=$b['date']??$m['date']; $m['class']=trim($b['class']??$m['class']); $m['location']=trim($b['location']??$m['location']); $m['meetingLink']=trim($b['meetingLink']??$m['meetingLink']); $m['icon']=$b['icon']??$m['icon']; $m['timeSlots']=$b['timeSlots']??$m['timeSlots']; if(isset($b['meetingType'])&&in_array($b['meetingType'],['physical','online','hybrid'])) $m['meetingType']=$b['meetingType']; if(isset($b['targetParentId'])) $m['targetParentId']=trim($b['targetParentId']); break; }}
  sd('meetings',$ms); jo(['ok'=>true]);
}
if($action==='api_delete'){
  if(empty($_SESSION['user'])) jo(['error'=>'Unauthorized'],403);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST;
  $ms=array_values(array_filter(ld('meetings'),fn($m)=>$m['id']!==$b['id'])); sd('meetings',$ms); jo(['ok'=>true]);
}
if($action==='api_book'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST; $bks=ld('bookings'); $u=$_SESSION['user'];
  foreach($bks as $x){ if($x['meetingId']===$b['meetingId']&&$x['userId']===$u['id']) jo(['error'=>'Already booked this meeting'],400); }
  $nb=['id'=>uid('b'),'meetingId'=>$b['meetingId']??'','userId'=>$u['id'],'userName'=>$u['name'],'userEmail'=>$u['email'],'userPhone'=>$u['phone'],'studentName'=>$u['studentName']??'','class'=>$u['class']??'','slot'=>$b['slot']??'','status'=>'confirmed','bookedAt'=>ts()];
  $bks[]=$nb; sd('bookings',$bks);
  // Send booking confirmation email
  $mt=null; foreach(ld('meetings') as $mm) if($mm['id']===$nb['meetingId']){$mt=$mm;break;}
  if($mt) Mailer::sendBookingConfirmation($nb,$mt,loadSettings());
  Audit::log('booking.created','Parent booked a slot',['bookingId'=>$nb['id'],'meetingId'=>$nb['meetingId'],'slot'=>$nb['slot']]);
  jo(['ok'=>true,'booking'=>$nb]);
}
if($action==='api_cancel'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST; $bks=ld('bookings'); $u=$_SESSION['user']; $found=null; $newBks=[];
  foreach($bks as $x){ if($x['id']===$b['bookingId']) $found=$x; else $newBks[]=$x; }
  if(!$found) jo(['error'=>'Booking not found'],404);
  sd('bookings',$newBks);
  $reason=$b['reason']??'';
  if(empty(trim($reason))) jo(['error'=>'A reason for cancellation is required'],400);
  $apl=['id'=>uid('a'),'bookingId'=>$found['id'],'meetingId'=>$found['meetingId'],'userId'=>$u['id'],'userName'=>$u['name'],'userEmail'=>$u['email']??'','reason'=>$reason,'createdAt'=>ts()];
  $apls=ld('apologies'); $apls[]=$apl; sd('apologies',$apls);
  $settings=loadSettings();
  // Send cancellation receipt email to the PARENT
  $mt=null; foreach(ld('meetings') as $mm) if($mm['id']===$found['meetingId']){$mt=$mm;break;}
  $emailResult=['ok'=>false,'error'=>'Meeting not found'];
  if($mt) $emailResult=Mailer::sendCancellationReceipt($found,$mt,$reason,$settings);
  // Also notify the school admin about the cancellation
  if($mt){
    $schoolEmail=$settings['email']??env('SMTP_USER','');
    if($schoolEmail&&filter_var($schoolEmail,FILTER_VALIDATE_EMAIL)){
      $adminHtml='<p>A parent has cancelled their booking:</p>'
        .'<ul><li><strong>Parent:</strong> '.htmlspecialchars($u['name']).' ('.htmlspecialchars($u['email']??'').')</li>'
        .'<li><strong>Meeting:</strong> '.htmlspecialchars($mt['title']).'</li>'
        .'<li><strong>Slot:</strong> '.htmlspecialchars($found['slot']??'—').'</li>'
        .'<li><strong>Reason:</strong> '.htmlspecialchars($reason).'</li></ul>';
      Mailer::send(['to'=>$schoolEmail,'toName'=>'School Administration','subject'=>'Booking Cancelled — '.$u['name'].' / '.$mt['title'],'html'=>$adminHtml]);
    }
  }
  Audit::log('booking.cancelled','Booking cancelled with apology',['bookingId'=>$found['id'],'reason'=>$reason,'emailSent'=>$emailResult['ok']]);
  jo(['ok'=>true,'emailSent'=>$emailResult['ok']]);
}
if($action==='api_msg'){
  // Universal message sender — works for all roles, sends real email
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST; $u=$_SESSION['user'];
  $to=$b['to']??''; $toName=$b['toName']??''; $subj=$b['subject']??''; $msgBody=$b['message']??'';
  if(!$to||!$subj||!$msgBody) jo(['error'=>'Recipient, subject and message are required'],400);
  if(!filter_var($to,FILTER_VALIDATE_EMAIL)) jo(['error'=>'Invalid recipient email address'],400);
  // Save to messages log
  $msg=['id'=>uid('c'),'from'=>$u['email'],'fromName'=>$u['name'],'fromRole'=>$u['role'],'to'=>$to,'toName'=>$toName,'toPhone'=>$b['toPhone']??'','subject'=>$subj,'message'=>$msgBody,'sentAt'=>ts(),'emailSent'=>false,'emailError'=>''];
  // Send actual email
  $settings=loadSettings();
  if($u['role']==='parent'){
    // Parent sending to teacher/admin — notify the school
    $schoolEmail=$settings['email']??env('SMTP_USER','');
    $result=Mailer::sendParentMessage($schoolEmail,'School Administration',$subj,$msgBody,$u,$settings);
  } else {
    // Teacher/principal/admin sending to parent
    $mt=null; foreach(ld('meetings') as $mm) if(!empty($b['meetingId'])&&$mm['id']===$b['meetingId']){$mt=$mm;break;}
    if($mt) $result=Mailer::sendMeetingNotification($to,$toName,$mt,$msgBody,$u,$settings);
    else    $result=Mailer::sendDirectMessage($to,$toName,$subj,$msgBody,$u,$settings);
  }
  $msg['emailSent']=$result['ok']; $msg['emailError']=$result['error']??'';
  $msgs=ld('messages'); $msgs[]=$msg; sd('messages',$msgs);
  // Auto-reply confirmation to parent
  if($u['role']==='parent'&&$result['ok']){
    Mailer::send(['to'=>$u['email'],'toName'=>$u['name'],'subject'=>'Your message has been received — '.$settings['schoolName'],'html'=>'<p>Dear <strong>'.htmlspecialchars($u['name']).'</strong>,</p><p>Your message has been received by the school and will be responded to shortly.</p><blockquote style="border-left:3px solid #C8963E;padding:12px 16px;background:#f9f6f0;margin:16px 0"><strong>Subject:</strong> '.htmlspecialchars($subj).'<br/>'.nl2br(htmlspecialchars($msgBody)).'</blockquote><p style="color:#888;font-size:13px">Please do not reply to this email. Log in to the portal to send another message.</p>']);
  }
  Audit::log('message.sent','Message sent via portal',['from'=>$u['email'],'to'=>$to,'subject'=>$subj,'emailSent'=>$result['ok']]);
  jo(['ok'=>true,'emailSent'=>$result['ok'],'emailError'=>$result['error']??'']);
}
if($action==='api_notify_meeting'){
  // Notify all booked parents about a meeting
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['teacher','principal','admin'])) jo(['error'=>'Unauthorized'],403);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST; $u=$_SESSION['user'];
  $mid=$b['meetingId']??''; $customMsg=$b['message']??'';
  $mt=null; foreach(ld('meetings') as $mm) if($mm['id']===$mid){$mt=$mm;break;}
  if(!$mt) jo(['error'=>'Meeting not found'],404);
  $settings=loadSettings(); $sent=0; $failed=0;
  $bks=array_filter(ld('bookings'),fn($bk)=>$bk['meetingId']===$mid);
  if(empty($bks)){ jo(['ok'=>true,'sent'=>0,'failed'=>0,'message'=>'No bookings found for this meeting']); }
  foreach($bks as $bk){
    $r=Mailer::sendMeetingNotification($bk['userEmail'],$bk['userName'],$mt,$customMsg,$u,$settings);
    $r['ok']?$sent++:$failed++;
  }
  Audit::log('meeting.notified','Notified parents for meeting',['meetingId'=>$mid,'sent'=>$sent,'failed'=>$failed]);
  jo(['ok'=>true,'sent'=>$sent,'failed'=>$failed]);
}
if($action==='api_mark_apology_reviewed'){
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['teacher','principal','admin'])) jo(['error'=>'Unauthorized'],403);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST;
  $id=$b['id']??'';
  if(!$id) jo(['error'=>'Missing apology ID'],400);
  $apls=ld('apologies');
  $found=false;
  foreach($apls as &$a){ if($a['id']===$id){ $a['status']='reviewed'; $a['reviewedAt']=ts(); $a['reviewedBy']=$_SESSION['user']['name']; $found=true; break; } }
  unset($a);
  if(!$found) jo(['error'=>'Apology not found'],404);
  sd('apologies',$apls);
  Audit::log('apology.reviewed','Apology marked as reviewed',['apologyId'=>$id]);
  jo(['ok'=>true]);
}
if($action==='api_get_parents'){
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['teacher','principal','admin'])) jo(['error'=>'Unauthorized'],403);
  $parents = array_values(array_filter(ld('users'),fn($u)=>$u['role']==='parent'));
  $out = array_map(fn($u)=>['id'=>$u['id'],'name'=>$u['name'],'email'=>$u['email'],'class'=>$u['class']??'','studentName'=>$u['studentName']??''],$parents);
  jo(['ok'=>true,'parents'=>$out]);
}
if($action==='api_settings'){
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['admin','principal'])) jo(['error'=>'Unauthorized'],403);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST;
  $existing = loadSettings();
  $allowed  = ['schoolName','schoolMotto','logo','address','phone','email','website'];
  $s = $existing;
  foreach($allowed as $k){ if(isset($b[$k])) $s[$k]=trim($b[$k]); }
  // Custom streams — store as clean array
  if(isset($b['customStreams'])&&is_array($b['customStreams'])){
    $s['customStreams']=array_values(array_unique(array_filter(array_map('trim',$b['customStreams']))));
  }
  sd('settings',$s);
  Audit::log('settings.updated','School settings updated',[]);
  jo(['ok'=>true]);
}
if($action==='api_test_ai'){
  // Quick Groq connectivity test — returns model response
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['admin','principal'])) jo(['error'=>'Unauthorized'],403);
  // We don't call Groq from PHP directly — the test is done via JS → api-proxy.php
  // This PHP endpoint just confirms the config is set
  $key = env('GROQ_API_KEY','');
  if(empty($key)) jo(['ok'=>false,'message'=>'GROQ_API_KEY not set in .env']);
  jo(['ok'=>true,'message'=>'Groq key is configured. Use the Test AI button to send a live request.','model'=>'llama-3.3-70b-versatile']);
}
if($action==='api_test_email'){
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['admin','principal'])) jo(['error'=>'Unauthorized'],403);
  $u=$_SESSION['user']; $settings=loadSettings();
  $result=Mailer::send(['to'=>$u['email'],'toName'=>$u['name'],'subject'=>'Email Test — School Portal','html'=>'<p>This is a test email from the <strong>'.$settings['schoolName'].'</strong> Meeting Portal. SMTP is working correctly!</p>']);
  jo(['ok'=>$result['ok'],'message'=>$result['ok']?'Test email sent to '.$u['email']:$result['error']]);
}
if($action==='api_smtp_debug'){
  if(empty($_SESSION['user'])||!in_array($_SESSION['user']['role'],['admin','principal'])) jo(['error'=>'Unauthorized'],403);
  $smtpHost = env('SMTP_HOST','');
  $smtpPort = (int)env('SMTP_PORT',587);
  $smtpUser = env('SMTP_USER','');
  $smtpPass = env('SMTP_PASS','');
  $smtpEnc  = strtolower(env('SMTP_ENCRYPTION','tls'));
  $dbgTrace = [];
  $dbgOk    = false;
  $dbgErr   = '';
  $dbgTrace[] = "1. Config: host={$smtpHost} port={$smtpPort} user={$smtpUser} enc={$smtpEnc}";
  $dbgTrace[] = "2. SMTP_PASS: ".(!empty($smtpPass) ? 'SET (length='.strlen($smtpPass).')' : 'MISSING — set SMTP_PASS in .env');
  $dbgAddr = ($smtpEnc==='ssl' ? 'ssl://' : 'tcp://').$smtpHost.':'.$smtpPort;
  $dbgTrace[] = "3. Connecting to {$dbgAddr} ...";
  $dbgErrno=0; $dbgErrStr='';
  $dbgSock = @stream_socket_client($dbgAddr,$dbgErrno,$dbgErrStr,10);
  if(!$dbgSock){
    $dbgTrace[] = "   FAILED: [{$dbgErrno}] {$dbgErrStr}";
    $dbgErr = "Cannot connect to SMTP server: {$dbgErrStr}";
    jo(['ok'=>false,'trace'=>$dbgTrace,'error'=>$dbgErr]);
  }
  stream_set_timeout($dbgSock,10);
  $dbgBanner = fgets($dbgSock,512);
  $dbgTrace[] = "4. Banner: ".trim($dbgBanner);
  $dbgBcode  = (int)substr($dbgBanner,0,3);
  if($dbgBcode!==220){
    fclose($dbgSock);
    $dbgTrace[] = "   ERROR: Expected 220, got {$dbgBcode}";
    jo(['ok'=>false,'trace'=>$dbgTrace,'error'=>'Bad banner']);
  }
  fwrite($dbgSock,"EHLO sovereignai.co.ke\r\n");
  $dbgEhlo='';
  while($dbgL=fgets($dbgSock,512)){ $dbgEhlo.=$dbgL; if(substr($dbgL,3,1)===' ') break; }
  $dbgTrace[] = "5. EHLO: ".trim(substr($dbgEhlo,0,120));
  if($smtpEnc==='tls'){
    fwrite($dbgSock,"STARTTLS\r\n");
    $dbgStls = fgets($dbgSock,512);
    $dbgTrace[] = "6. STARTTLS: ".trim($dbgStls);
    if((int)substr($dbgStls,0,3)===220){
      $dbgUpg = stream_socket_enable_crypto($dbgSock,true,STREAM_CRYPTO_METHOD_TLS_CLIENT);
      $dbgTrace[] = "7. TLS upgrade: ".($dbgUpg?'SUCCESS':'FAILED');
      if($dbgUpg){
        fwrite($dbgSock,"EHLO sovereignai.co.ke\r\n");
        $dbgEhlo2='';
        while($dbgL2=fgets($dbgSock,512)){ $dbgEhlo2.=$dbgL2; if(substr($dbgL2,3,1)===' ') break; }
        $dbgTrace[] = "8. EHLO post-TLS: OK";
      }
    }
  }
  if(!empty($smtpPass)){
    fwrite($dbgSock,"AUTH LOGIN\r\n");
    $dbgR1=fgets($dbgSock,512); $dbgTrace[]="9. AUTH LOGIN: ".trim($dbgR1);
    if((int)substr($dbgR1,0,3)===334){
      fwrite($dbgSock,base64_encode($smtpUser)."\r\n");
      $dbgR2=fgets($dbgSock,512); $dbgTrace[]="10. Username: ".trim($dbgR2);
      if((int)substr($dbgR2,0,3)===334){
        fwrite($dbgSock,base64_encode($smtpPass)."\r\n");
        $dbgR3=fgets($dbgSock,512); $dbgTrace[]="11. Password: ".trim($dbgR3);
        $dbgOk=((int)substr($dbgR3,0,3)===235);
        $dbgTrace[] = $dbgOk ? "✅ AUTH SUCCESS — SMTP is working!" : "❌ AUTH FAILED — check SMTP_PASS in .env";
      }
    }
  } else {
    $dbgTrace[] = "9. Skipped auth — SMTP_PASS not set";
  }
  fwrite($dbgSock,"QUIT\r\n");
  fclose($dbgSock);
  jo(['ok'=>$dbgOk,'trace'=>$dbgTrace,'error'=>$dbgErr]);
}
// ── Chat / Direct Messages ────────────────────────────────────
if($action==='api_chat_send'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $b=json_decode(file_get_contents('php://input'),true)?:$_POST; $u=$_SESSION['user'];
  $toId=trim($b['toId']??''); $msg=trim($b['message']??'');
  if(!$toId||!$msg) jo(['error'=>'Recipient and message required'],400);
  // Find recipient
  $users=ld('users'); $recipient=null;
  foreach($users as $ru) if($ru['id']===$toId){$recipient=$ru;break;}
  if(!$recipient) jo(['error'=>'Recipient not found'],404);
  $chat=['id'=>uid('ch'),'fromId'=>$u['id'],'fromName'=>$u['name'],'fromRole'=>$u['role'],'fromColor'=>$u['color']??roleColor($u['role']),'toId'=>$toId,'toName'=>$recipient['name'],'message'=>$msg,'sentAt'=>ts(),'readAt'=>null];
  $chats=ld('chats'); $chats[]=$chat; sd('chats',$chats);
  jo(['ok'=>true,'chat'=>$chat]);
}
if($action==='api_chat_load'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $u=$_SESSION['user'];
  $withId=$_GET['withId']??($_POST['withId']??'');
  $chats=ld('chats');
  if($withId){
    $thread=array_values(array_filter($chats,fn($c)=>($c['fromId']===$u['id']&&$c['toId']===$withId)||($c['fromId']===$withId&&$c['toId']===$u['id'])));
    // Mark as read
    $changed=false;
    foreach($chats as &$c){ if($c['toId']===$u['id']&&$c['fromId']===$withId&&empty($c['readAt'])){ $c['readAt']=ts(); $changed=true; } }
    unset($c); if($changed) sd('chats',$chats);
    jo(['ok'=>true,'chats'=>$thread]);
  } else {
    // Return inbox: latest message per conversation + unread counts
    $inbox=[]; $seen=[];
    foreach(array_reverse($chats) as $c){
      $peer=$c['fromId']===$u['id']?$c['toId']:$c['fromId'];
      if(!isset($seen[$peer])){ $seen[$peer]=true; $inbox[$peer]=$c; }
    }
    // Unread counts
    $unread=[];
    foreach($chats as $c){ if($c['toId']===$u['id']&&empty($c['readAt'])) $unread[$c['fromId']]=($unread[$c['fromId']]??0)+1; }
    // Get all users we've chatted with
    $users=ld('users');
    $contacts=[];
    foreach($inbox as $peerId=>$lastMsg){
      $peer=null; foreach($users as $ru) if($ru['id']===$peerId){$peer=$ru;break;}
      if($peer) $contacts[]=['user'=>['id'=>$peer['id'],'name'=>$peer['name'],'role'=>$peer['role'],'color'=>$peer['color']??roleColor($peer['role'])],'lastMsg'=>$lastMsg,'unread'=>$unread[$peerId]??0];
    }
    jo(['ok'=>true,'contacts'=>$contacts,'totalUnread'=>array_sum($unread)]);
  }
}
if($action==='api_chat_users'){
  if(empty($_SESSION['user'])) jo(['error'=>'Not logged in'],401);
  $u=$_SESSION['user'];
  $users=ld('users');
  $out=array_values(array_filter(array_map(fn($ru)=>$ru['id']===$u['id']?null:['id'=>$ru['id'],'name'=>$ru['name'],'role'=>$ru['role'],'color'=>$ru['color']??roleColor($ru['role'])],$users)));
  jo(['ok'=>true,'users'=>$out]);
}

// ── Page data ────────────────────────────────────────────────
$user     = $_SESSION['user'] ?? null;
$settings = loadSettings();
$meetings = ld('meetings');
$bookings = ld('bookings');
$apologies= ld('apologies');
$messages = ld('messages');
$chats    = ld('chats');
$now      = new DateTime();
$allClassList = buildClassList($settings);  // full CBC + custom streams

usort($meetings, fn($a,$b)=>strcmp($a['date'],$b['date']));
$activeMeetings   = array_values(array_filter($meetings, fn($m)=>new DateTime($m['date'])>=$now));
$inactiveMeetings = array_reverse(array_values(array_filter($meetings, fn($m)=>new DateTime($m['date'])<$now)));
$myBookings       = $user ? array_values(array_filter($bookings,fn($b)=>$b['userId']===$user['id'])) : [];

$page    = $_GET['page']  ?? ($user ? 'dashboard' : 'home');
if(!$user && $page==='dashboard') $page='home';
$tab     = $_GET['tab']   ?? 'meetings';
$search  = trim($_GET['q'] ?? '');
$clsF    = $_GET['class'] ?? 'all';
$preRole = $_GET['role']  ?? 'parent';

// Teacher sees meetings for ALL their streams
$viewMeetings = $meetings;
if($user && $user['role']==='teacher'){
  $tStreams = $user['streams'] ?? (($user['class']??'')?[$user['class']]:[]);
  if(!empty($tStreams)) $viewMeetings=array_values(array_filter($meetings,fn($m)=>in_array($m['class']??'',$tStreams)));
}
// Parent sees meetings for their child's class
if($user && $user['role']==='parent' && !empty($user['class'])){
  $viewMeetings=array_values(array_filter($meetings,fn($m)=>
    // Class-wide meeting for parent's class (not individually targeted to someone else)
    ((($m['class']??'')===$user['class']||($m['class']??'')==='') && empty($m['targetParentId']))
    // OR individually targeted to this specific parent
    || (($m['targetParentId']??'')===$user['id'])
  ));
}
if($search) $viewMeetings=array_values(array_filter($viewMeetings,fn($m)=>stripos($m['title'],$search)!==false||stripos($m['description']??'',$search)!==false));
if($clsF!=='all') $viewMeetings=array_values(array_filter($viewMeetings,fn($m)=>($m['class']??'')===$clsF));

$viewActive   = array_values(array_filter($viewMeetings,fn($m)=>new DateTime($m['date'])>=$now));
$viewInactive = array_reverse(array_values(array_filter($viewMeetings,fn($m)=>new DateTime($m['date'])<$now)));
$allClasses   = array_unique(array_filter(array_column($meetings,'class')));

$tStreams   = $user&&$user['role']==='teacher' ? ($user['streams']??[]) : [];
$totalMtg  = $user&&$user['role']==='teacher'&&!empty($tStreams)
             ? count(array_filter($meetings,fn($m)=>in_array($m['class']??'',$tStreams)))
             : count($meetings);
$activeCnt = $user&&$user['role']==='teacher'&&!empty($tStreams)
             ? count(array_filter($activeMeetings,fn($m)=>in_array($m['class']??'',$tStreams)))
             : count($activeMeetings);

if($user){
  if($user['role']==='parent') $dispBk=$myBookings;
  elseif($user['role']==='teacher'){
    $tMids=array_column(array_filter($meetings,fn($m)=>in_array($m['class']??'',$tStreams)),'id');
    $dispBk=array_values(array_filter($bookings,fn($b)=>in_array($b['meetingId'],$tMids)));
  }
  else $dispBk=$bookings;
  $dispMsg=$user['role']==='parent'
    ? array_values(array_filter($messages,fn($m)=>($m['to']??'')===$user['email']||($m['from']??'')===$user['email']))
    : array_reverse($messages);
} else { $dispBk=[]; $dispMsg=[]; }

$initials=$user?implode('',array_slice(array_map(fn($w)=>strtoupper($w[0]),preg_split('/\s+/',trim($user['name']))),0,2)):'';
?>
<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8"/>
<meta name="viewport" content="width=device-width,initial-scale=1.0"/>
<title><?=e($settings['schoolName'])?> · Meeting Portal</title>
<link rel="icon" href="data:image/svg+xml,<svg xmlns='http://www.w3.org/2000/svg' viewBox='0 0 100 100'><text y='.9em' font-size='90'>🎓</text></svg>"/>
<link rel="preconnect" href="https://fonts.googleapis.com"/>
<link rel="preconnect" href="https://fonts.gstatic.com" crossorigin/>
<link href="https://fonts.googleapis.com/css2?family=Playfair+Display:ital,wght@0,600;0,700;0,800;1,600&family=Inter:wght@300;400;500;600;700&display=swap" rel="stylesheet"/>
<style>
:root{
  --n0:#060F1F;--n1:#0B1D35;--n2:#102340;--n3:#172C50;--n4:#1E3868;
  --g:#C8963E;--g2:#D9A94E;--g3:#EAC06E;--g4:#FBF0DB;
  --w:#fff;--s0:#F7FAFD;--s1:#EEF3FA;--s2:#E0E9F5;--s3:#C5D4EC;--s4:#8B9FC0;--s5:#4A5D7E;--s6:#1E2D45;
  --ok:#0A7C5A;--okbg:#E4F5EE;--er:#B91C1C;--erbg:#FEF0EE;--am:#B45309;--ambg:#FEF3C7;
  --bl:#1A56DB;--blbg:#EBF2FF;--vi:#6D28D9;--vibg:#EDE9FE;
  --sh1:0 1px 3px rgba(6,15,31,.07);--sh2:0 4px 14px rgba(6,15,31,.10);
  --sh3:0 10px 32px rgba(6,15,31,.14);--sh4:0 24px 64px rgba(6,15,31,.22);
  --r1:6px;--r2:10px;--r3:16px;--r4:22px;
}
*,*::before,*::after{box-sizing:border-box;margin:0;padding:0}
html,body{height:100%}
body{font-family:'Inter',sans-serif;font-size:14px;color:var(--s6);background:var(--s0);-webkit-font-smoothing:antialiased}
a{text-decoration:none;color:inherit}button{cursor:pointer;font-family:inherit;border:none;background:none}
input,select,textarea{font-family:inherit}
::-webkit-scrollbar{width:5px}::-webkit-scrollbar-track{background:transparent}::-webkit-scrollbar-thumb{background:var(--s2);border-radius:99px}

/* NAV */
.nav{position:fixed;top:0;left:0;right:0;height:70px;z-index:300;display:flex;align-items:center;justify-content:space-between;padding:0 56px;background:rgba(11,29,53,.97);backdrop-filter:blur(14px);border-bottom:1px solid rgba(200,150,62,.16)}
.nav-brand{display:flex;align-items:center;gap:14px}
.nav-emb{width:44px;height:44px;border-radius:12px;background:linear-gradient(135deg,var(--g),var(--g3));display:flex;align-items:center;justify-content:center;font-size:22px;box-shadow:0 0 26px rgba(200,150,62,.38)}
.nav-sn{font-family:'Playfair Display',serif;font-size:17px;color:#fff;font-weight:700}
.nav-sm{font-size:10px;color:var(--g3);letter-spacing:2px;text-transform:uppercase;margin-top:1px}
.nav-links{display:flex;align-items:center;gap:8px}
.nav-link{padding:9px 18px;border:1px solid rgba(255,255,255,.16);border-radius:var(--r1);color:rgba(255,255,255,.72);font-size:13px;font-weight:500;transition:.2s}
.nav-link:hover{background:rgba(255,255,255,.07);color:#fff}
.nav-cta{padding:9px 22px;background:linear-gradient(135deg,var(--g),var(--g2));border-radius:var(--r1);color:var(--n1);font-size:13px;font-weight:700;transition:.2s;box-shadow:0 2px 10px rgba(200,150,62,.4)}
.nav-cta:hover{transform:translateY(-1px);box-shadow:0 5px 20px rgba(200,150,62,.55)}

/* HERO */
.hero{min-height:100vh;position:relative;overflow:hidden;padding:100px 56px 60px;background:linear-gradient(148deg,var(--n0) 0%,var(--n3) 55%,#1a3d70 100%);display:flex;align-items:center}
.hero-orb1{position:absolute;top:-140px;right:-100px;width:640px;height:640px;border-radius:50%;background:radial-gradient(circle,rgba(200,150,62,.13) 0%,transparent 65%);pointer-events:none}
.hero-orb2{position:absolute;bottom:-180px;left:-140px;width:560px;height:560px;border-radius:50%;background:radial-gradient(circle,rgba(26,86,219,.11) 0%,transparent 65%);pointer-events:none}
.hero-grid{display:grid;grid-template-columns:1fr 460px;gap:72px;align-items:center;max-width:1240px;margin:0 auto;width:100%;position:relative;z-index:1}
.hero-pill{display:inline-flex;align-items:center;gap:8px;padding:6px 16px;background:rgba(200,150,62,.11);border:1px solid rgba(200,150,62,.26);border-radius:99px;color:var(--g3);font-size:11px;font-weight:600;letter-spacing:2px;text-transform:uppercase;margin-bottom:28px}
.hero-dot{width:6px;height:6px;background:var(--g);border-radius:50%;animation:blink 2s infinite}
@keyframes blink{0%,100%{opacity:1}50%{opacity:.28}}
.hero-h1{font-family:'Playfair Display',serif;font-size:60px;font-weight:800;color:#fff;line-height:1.07;letter-spacing:-.6px;margin-bottom:22px}
.hero-h1 em{color:var(--g3);font-style:italic}
.hero-p{font-size:17px;color:rgba(255,255,255,.58);line-height:1.78;max-width:530px;font-weight:300;margin-bottom:38px}
.hero-btns{display:flex;gap:14px;flex-wrap:wrap}
.hbtn-p{display:inline-flex;align-items:center;gap:10px;padding:15px 34px;background:linear-gradient(135deg,var(--g),var(--g2));border-radius:var(--r2);color:var(--n1);font-size:15px;font-weight:700;transition:.25s;box-shadow:0 4px 22px rgba(200,150,62,.42)}
.hbtn-p:hover{transform:translateY(-2px);box-shadow:0 8px 32px rgba(200,150,62,.58)}
.hbtn-g{display:inline-flex;align-items:center;gap:10px;padding:15px 34px;border:1.5px solid rgba(255,255,255,.2);border-radius:var(--r2);color:#fff;font-size:15px;font-weight:500;transition:.25s}
.hbtn-g:hover{background:rgba(255,255,255,.07);border-color:rgba(255,255,255,.38)}
.hero-stats{display:flex;gap:44px;margin-top:52px;padding-top:40px;border-top:1px solid rgba(255,255,255,.08)}
.hs-n{font-family:'Playfair Display',serif;font-size:30px;font-weight:700;color:var(--g3);display:block;line-height:1}
.hs-l{font-size:11px;color:rgba(255,255,255,.38);text-transform:uppercase;letter-spacing:1.5px;font-weight:500;margin-top:5px;display:block}

/* Hero login card */
.hcard{background:rgba(255,255,255,.045);backdrop-filter:blur(26px);border:1px solid rgba(255,255,255,.09);border-radius:var(--r4);padding:36px;box-shadow:0 28px 64px rgba(0,0,0,.38)}
.hcard-eye{font-size:10px;letter-spacing:2.5px;text-transform:uppercase;color:var(--g3);font-weight:600;margin-bottom:6px}
.hcard-title{font-family:'Playfair Display',serif;font-size:20px;color:#fff;font-weight:700;margin-bottom:22px}
.role-row{display:flex;align-items:center;gap:14px;width:100%;padding:15px 17px;border-radius:var(--r2);background:rgba(255,255,255,.04);border:1px solid rgba(255,255,255,.07);margin-bottom:10px;cursor:pointer;transition:.22s;text-align:left}
.role-row:last-child{margin-bottom:0}
.role-row:hover{background:rgba(200,150,62,.09);border-color:rgba(200,150,62,.28);transform:translateX(5px)}
.role-row:hover .role-arrow{color:var(--g3);transform:translateX(4px)}
.role-ico{width:42px;height:42px;border-radius:10px;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.role-name{font-size:14px;font-weight:600;color:#fff}
.role-sub{font-size:11px;color:rgba(255,255,255,.4);margin-top:2px}
.role-arrow{margin-left:auto;font-size:17px;color:rgba(255,255,255,.22);transition:.22s}

/* Sections */
.features{background:var(--w);padding:100px 56px}
.roles-sec{background:var(--s0);padding:100px 56px}
.sec-eye{text-align:center;font-size:11px;letter-spacing:3px;text-transform:uppercase;color:var(--g);font-weight:600;margin-bottom:12px}
.sec-h2{font-family:'Playfair Display',serif;font-size:42px;font-weight:700;text-align:center;color:var(--n1);margin-bottom:14px;letter-spacing:-.3px}
.sec-sub{text-align:center;color:var(--s4);font-size:16px;max-width:520px;margin:0 auto 64px;line-height:1.78;font-weight:300}
.feat-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:26px;max-width:1100px;margin:0 auto}
.fcard{padding:38px 34px;border-radius:var(--r3);border:1.5px solid var(--s2);background:var(--s0);transition:.3s;position:relative;overflow:hidden}
.fcard::after{content:'';position:absolute;bottom:0;left:0;right:0;height:3px;background:linear-gradient(90deg,var(--g),var(--g3));transform:scaleX(0);transform-origin:left;transition:.3s}
.fcard:hover{transform:translateY(-6px);box-shadow:var(--sh4);border-color:rgba(200,150,62,.3)}.fcard:hover::after{transform:scaleX(1)}
.fcard-ico{width:56px;height:56px;border-radius:14px;background:var(--n1);display:flex;align-items:center;justify-content:center;margin-bottom:22px;font-size:24px}
.fcard-t{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--n1);margin-bottom:10px}
.fcard-d{font-size:14px;color:var(--s4);line-height:1.75;font-weight:300}
.roles-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:22px;max-width:1100px;margin:0 auto}
.rcard{background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);padding:38px 24px;text-align:center;transition:.3s;cursor:pointer;position:relative;overflow:hidden;display:block}
.rcard::before{content:'';position:absolute;top:0;left:0;right:0;height:4px;background:linear-gradient(90deg,var(--g),var(--g3));transform:scaleX(0);transform-origin:center;transition:.3s}
.rcard:hover{transform:translateY(-5px);box-shadow:var(--sh4)}.rcard:hover::before{transform:scaleX(1)}
.rcard-ico{width:64px;height:64px;border-radius:50%;display:flex;align-items:center;justify-content:center;margin:0 auto 16px;font-size:28px}
.rcard-n{font-family:'Playfair Display',serif;font-size:19px;font-weight:700;color:var(--n1);margin-bottom:10px}
.rcard-d{font-size:13px;color:var(--s4);line-height:1.65;font-weight:300;margin-bottom:22px}
.rcard-btn{display:inline-flex;align-items:center;gap:7px;padding:10px 20px;border-radius:var(--r1);font-size:13px;font-weight:600;border:2px solid}

/* CTA */
.cta-band{background:linear-gradient(135deg,var(--n0) 0%,var(--n4) 100%);padding:90px 56px;text-align:center;position:relative;overflow:hidden}
.cta-band::before{content:'';position:absolute;top:-100px;right:-80px;width:420px;height:420px;border-radius:50%;background:radial-gradient(circle,rgba(200,150,62,.14) 0%,transparent 65%);pointer-events:none}
.cta-h2{font-family:'Playfair Display',serif;font-size:44px;font-weight:700;color:#fff;margin-bottom:16px;letter-spacing:-.3px;position:relative;z-index:1}
.cta-h2 em{color:var(--g3);font-style:italic}
.cta-sub{font-size:17px;color:rgba(255,255,255,.52);font-weight:300;max-width:500px;margin:0 auto 36px;line-height:1.7;position:relative;z-index:1}
.cta-btns{display:flex;gap:14px;justify-content:center;flex-wrap:wrap;position:relative;z-index:1}
footer.site{background:var(--n1);border-top:1px solid rgba(255,255,255,.05);padding:34px 56px;display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:14px}
.foot-copy{font-size:12px;color:rgba(255,255,255,.28)}
.foot-links{display:flex;gap:22px}.foot-links a{font-size:12px;color:rgba(255,255,255,.25);transition:.2s}.foot-links a:hover{color:var(--g3)}

/* AUTH */
.auth{min-height:100vh;display:grid;grid-template-columns:1fr 500px}
.auth-l{background:linear-gradient(155deg,var(--n0) 0%,var(--n4) 100%);display:flex;flex-direction:column;justify-content:space-between;padding:60px 70px;position:relative;overflow:hidden}
.auth-lorb{position:absolute;top:-80px;right:-100px;width:450px;height:450px;border-radius:50%;background:radial-gradient(circle,rgba(200,150,62,.14) 0%,transparent 65%);pointer-events:none}
.al-brand{display:flex;align-items:center;gap:16px;position:relative;z-index:1}
.al-emb{width:52px;height:52px;border-radius:14px;background:linear-gradient(135deg,var(--g),var(--g3));display:flex;align-items:center;justify-content:center;font-size:26px;box-shadow:0 0 28px rgba(200,150,62,.48)}
.al-sn{font-family:'Playfair Display',serif;font-size:19px;color:#fff;font-weight:700}
.al-sm{font-size:10px;color:var(--g3);letter-spacing:2px;text-transform:uppercase;margin-top:2px}
.al-body{position:relative;z-index:1}
.al-h1{font-family:'Playfair Display',serif;font-size:46px;font-weight:800;color:#fff;line-height:1.11;margin-bottom:20px}
.al-h1 em{color:var(--g3);font-style:italic}
.al-p{font-size:15px;color:rgba(255,255,255,.5);line-height:1.8;font-weight:300;max-width:380px;margin-bottom:34px}
.al-checks{list-style:none;display:flex;flex-direction:column;gap:13px}
.al-checks li{display:flex;align-items:center;gap:12px;font-size:14px;color:rgba(255,255,255,.62);font-weight:300}
.al-ck{width:22px;height:22px;border-radius:50%;background:rgba(200,150,62,.18);border:1px solid rgba(200,150,62,.38);display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:11px;color:var(--g3)}
.al-foot{font-size:12px;color:rgba(255,255,255,.22);position:relative;z-index:1}
.auth-r{background:var(--w);display:flex;flex-direction:column;justify-content:center;padding:60px 56px;overflow-y:auto}
.ar-back{display:inline-flex;align-items:center;gap:8px;font-size:13px;color:var(--s4);margin-bottom:36px;transition:.2s}
.ar-back:hover{color:var(--n1)}
.ar-title{font-family:'Playfair Display',serif;font-size:34px;font-weight:700;color:var(--n1);margin-bottom:8px;letter-spacing:-.3px}
.ar-sub{font-size:14px;color:var(--s4);margin-bottom:30px;font-weight:300;line-height:1.65}
.ar-rlbl{font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:var(--s4);font-weight:600;margin-bottom:12px}
.ar-rgrid{display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:28px}
.ar-rbtn{display:flex;align-items:center;gap:10px;padding:13px 15px;border-radius:var(--r2);border:1.5px solid var(--s2);background:var(--s0);font-size:13px;font-weight:500;color:var(--s5);transition:.2s}
.ar-rbtn:hover{border-color:var(--g);background:var(--g4);color:var(--n1)}
.ar-rbtn.on{border-color:var(--n1);background:var(--n1);color:#fff}
.ar-rico{width:30px;height:30px;border-radius:7px;display:flex;align-items:center;justify-content:center;font-size:15px;flex-shrink:0}
.fg{margin-bottom:20px}
.fl{display:block;font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:var(--s4);font-weight:600;margin-bottom:8px}
.fi{width:100%;padding:12px 15px;border:1.5px solid var(--s2);border-radius:var(--r2);font-size:13px;color:var(--s6);background:var(--s0);outline:none;transition:.2s}
.fi:focus{border-color:var(--n1);background:#fff;box-shadow:0 0 0 3px rgba(11,29,53,.06)}
.fi-wrap{position:relative}.fi-ico{position:absolute;left:14px;top:50%;transform:translateY(-50%);font-size:15px;color:var(--s4);pointer-events:none}.fi-wrap .fi{padding-left:42px}
.btn-login{width:100%;padding:15px;background:linear-gradient(135deg,var(--n1),var(--n4));border-radius:var(--r2);color:#fff;font-size:15px;font-weight:600;transition:.2s;margin-bottom:20px;display:flex;align-items:center;justify-content:center;gap:10px}
.btn-login:hover{transform:translateY(-1px);box-shadow:0 6px 22px rgba(11,29,53,.32)}
.demo-box{background:var(--g4);border:1px solid rgba(200,150,62,.28);border-radius:var(--r2);padding:15px 18px;font-size:13px;color:var(--s5);line-height:1.65}
.demo-box strong{color:var(--n1);display:block;margin-bottom:4px}

/* DASHBOARD */
.app{display:flex;min-height:100vh}
.sb{width:272px;background:var(--n1);display:flex;flex-direction:column;flex-shrink:0;position:fixed;top:0;left:0;bottom:0;z-index:100;overflow-y:auto}
.sb-brand{padding:24px 22px 20px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;gap:13px}
.sb-logo{width:40px;height:40px;border-radius:10px;background:linear-gradient(135deg,var(--g),var(--g3));display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.sb-sn{font-family:'Playfair Display',serif;font-size:14px;color:#fff;font-weight:700}
.sb-sp{font-size:10px;color:rgba(255,255,255,.32);letter-spacing:1.5px;text-transform:uppercase;margin-top:2px}
.sb-user{padding:16px 22px;border-bottom:1px solid rgba(255,255,255,.06);display:flex;align-items:center;gap:12px}
.sb-av{width:40px;height:40px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;flex-shrink:0;letter-spacing:-.5px}
.sb-un{font-size:13px;font-weight:600;color:#fff;line-height:1.3}
.sb-ur{font-size:11px;color:rgba(255,255,255,.35);text-transform:capitalize;margin-top:1px}
.sb-nav{flex:1;padding:14px 12px}
.sb-grp{font-size:10px;letter-spacing:1.5px;text-transform:uppercase;color:rgba(255,255,255,.25);font-weight:600;padding:0 10px;margin:16px 0 8px}
.sb-grp:first-child{margin-top:0}
.sb-link{width:100%;display:flex;align-items:center;gap:11px;padding:11px 12px;border-radius:var(--r2);font-size:13px;font-weight:500;color:rgba(255,255,255,.52);transition:.2s;position:relative;text-align:left}
.sb-link:hover{background:rgba(255,255,255,.06);color:rgba(255,255,255,.88)}
.sb-link.on{background:rgba(200,150,62,.13);color:var(--g3)}
.sb-link.on::before{content:'';position:absolute;left:0;top:8px;bottom:8px;width:3px;background:var(--g);border-radius:0 3px 3px 0}
.sb-badge{margin-left:auto;background:var(--g);color:var(--n1);font-size:10px;font-weight:700;padding:2px 8px;border-radius:99px;line-height:1.5}
.sb-ico{font-size:16px;width:20px;text-align:center;flex-shrink:0}
.sb-bot{padding:12px;border-top:1px solid rgba(255,255,255,.06)}
.sb-out{width:100%;display:flex;align-items:center;gap:11px;padding:10px 12px;border-radius:var(--r2);font-size:13px;font-weight:500;color:rgba(255,255,255,.35);transition:.2s}
.sb-out:hover{background:rgba(185,28,28,.12);color:#FCA5A5}
.main{flex:1;margin-left:272px;display:flex;flex-direction:column;min-height:100vh}
.tbar{background:var(--w);border-bottom:1.5px solid var(--s1);padding:0 34px;height:68px;display:flex;align-items:center;justify-content:space-between;position:sticky;top:0;z-index:50;box-shadow:var(--sh1)}
.tb-title{font-family:'Playfair Display',serif;font-size:21px;font-weight:700;color:var(--n1);line-height:1.2}
.tb-sub{font-size:12px;color:var(--s4);margin-top:2px;font-weight:300}
.tb-r{display:flex;align-items:center;gap:10px}
.tb-btn{width:38px;height:38px;border-radius:var(--r2);border:1.5px solid var(--s2);display:flex;align-items:center;justify-content:center;color:var(--s4);font-size:16px;transition:.2s}
.tb-btn:hover{border-color:var(--n1);color:var(--n1)}
.uchip{display:flex;align-items:center;gap:9px;padding:5px 14px 5px 5px;border:1.5px solid var(--s2);border-radius:99px;background:var(--w);transition:.2s}
.uchip:hover{border-color:var(--n1)}
.uchip-av{width:28px;height:28px;border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff}
.uchip-n{font-size:13px;font-weight:600;color:var(--n1)}
.content{padding:30px 34px;flex:1}

/* Stats */
.stats{display:grid;grid-template-columns:repeat(4,1fr);gap:16px;margin-bottom:26px}
.stat{background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);padding:20px 22px;display:flex;align-items:center;gap:16px;transition:.2s}
.stat:hover{box-shadow:var(--sh2);border-color:var(--s3)}
.stat-ico{width:50px;height:50px;border-radius:13px;display:flex;align-items:center;justify-content:center;font-size:22px;flex-shrink:0}
.stat-v{font-family:'Playfair Display',serif;font-size:30px;font-weight:700;color:var(--n1);line-height:1}
.stat-l{font-size:11px;color:var(--s4);text-transform:uppercase;letter-spacing:1px;font-weight:500;margin-top:5px}

/* Section header */
.sec-row{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;flex-wrap:wrap;gap:12px}
.sec-left{display:flex;align-items:center;gap:10px}
.sec-badge{display:inline-flex;align-items:center;gap:6px;padding:5px 13px;border-radius:99px;font-size:12px;font-weight:600}
.badge-live{background:var(--okbg);color:var(--ok)}
.badge-past{background:var(--s1);color:var(--s4)}
.sec-title{font-family:'Playfair Display',serif;font-size:20px;font-weight:700;color:var(--n1)}
.sec-cnt{font-size:13px;color:var(--s4)}
.divider{border:none;border-top:2px dashed var(--s2);margin:36px 0}

/* Toolbar */
.toolrow{display:flex;align-items:center;gap:12px;margin-bottom:22px;flex-wrap:wrap}
.sbox{position:relative;flex:1;min-width:200px}
.sbox-ico{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:15px;color:var(--s4);pointer-events:none}
.sinp{width:100%;padding:10px 14px 10px 40px;border:1.5px solid var(--s2);border-radius:var(--r2);font-size:13px;outline:none;background:var(--w);transition:.2s}
.sinp:focus{border-color:var(--n1);box-shadow:0 0 0 3px rgba(11,29,53,.05)}
.fsel{padding:10px 14px;border:1.5px solid var(--s2);border-radius:var(--r2);font-size:13px;outline:none;background:var(--w);color:var(--s6)}

/* Meeting cards */
.mgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(360px,1fr));gap:22px}
.mc{background:var(--w);border-radius:var(--r3);border:1.5px solid var(--s2);overflow:hidden;transition:.3s;display:flex;flex-direction:column;box-shadow:0 2px 8px rgba(11,29,53,.04)}
.mc:hover{box-shadow:0 8px 32px rgba(11,29,53,.12);border-color:rgba(200,150,62,.35);transform:translateY(-4px)}
.mc-stripe{height:6px}
.mc-body{padding:22px 24px 18px;flex:1}
.mc-tags{display:flex;gap:5px;flex-wrap:wrap;margin-bottom:14px}
.tag{display:inline-flex;align-items:center;gap:4px;padding:3px 9px;border-radius:99px;font-size:10px;font-weight:600;letter-spacing:.4px;text-transform:uppercase;white-space:nowrap}
.tg0{background:rgba(11,29,53,.08);color:var(--n1)}.tg1{background:var(--okbg);color:var(--ok)}.tg2{background:var(--erbg);color:var(--er)}.tg3{background:var(--blbg);color:var(--bl)}.tg4{background:var(--ambg);color:var(--am)}.tg5{background:var(--vibg);color:var(--vi)}
.mc-ico{float:right;font-size:32px;margin:-2px 0 4px 10px;opacity:.6;line-height:1;filter:drop-shadow(0 2px 4px rgba(0,0,0,.08))}
.mc-title{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--n1);margin-bottom:8px;line-height:1.35;clear:both}
.mc-desc{font-size:13px;color:var(--s4);line-height:1.7;font-weight:300;margin-bottom:16px;display:-webkit-box;-webkit-line-clamp:2;-webkit-box-orient:vertical;overflow:hidden}
.mc-meta{display:flex;flex-direction:column;gap:6px;background:var(--s0);border-radius:var(--r2);padding:11px 14px;margin-top:2px}
.mr{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--s4);font-weight:400}
.mr-ic{font-size:13px;width:16px;text-align:center;flex-shrink:0}
.mc-foot{padding:14px 24px;border-top:1.5px solid var(--s1);display:flex;align-items:center;justify-content:space-between;gap:8px;background:linear-gradient(to bottom,var(--s0),var(--w));flex-wrap:wrap}
.mc-bc{display:flex;align-items:center;gap:6px;font-size:12px;color:var(--s4);font-weight:500}
/* Apology filter active state */
.apl-filter.on{background:var(--n1);color:#fff;border-color:var(--n1)}

/* Buttons */
.btn-g{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;background:linear-gradient(135deg,var(--g),var(--g2));border-radius:var(--r2);color:var(--n1);font-size:13px;font-weight:700;transition:.2s}
.btn-g:hover{transform:translateY(-1px);box-shadow:0 4px 14px rgba(200,150,62,.45)}
.btn-n{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;background:var(--n1);border-radius:var(--r2);color:#fff;font-size:13px;font-weight:600;transition:.2s}
.btn-n:hover{opacity:.88}
.btn-o{display:inline-flex;align-items:center;gap:6px;padding:10px 20px;border:1.5px solid var(--s2);border-radius:var(--r2);color:var(--s5);font-size:13px;font-weight:600;transition:.2s;background:var(--w)}
.btn-o:hover{border-color:var(--n1);color:var(--n1)}
.btn-s{padding:7px 14px;font-size:12px}
.bico{width:33px;height:33px;border-radius:var(--r2);border:1.5px solid var(--s2);display:flex;align-items:center;justify-content:center;font-size:14px;color:var(--s5);transition:.2s;background:var(--w)}
.bico:hover{border-color:var(--n1);color:var(--n1)}.bico.d:hover{border-color:var(--er);color:var(--er);background:var(--erbg)}.bico.ok:hover{border-color:var(--ok);color:var(--ok);background:var(--okbg)}
button:disabled{opacity:.45;cursor:not-allowed}

/* Card */
.card{background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);overflow:hidden}
.ch{padding:20px 26px;border-bottom:1.5px solid var(--s1);display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap}
.cht{font-family:'Playfair Display',serif;font-size:18px;font-weight:700;color:var(--n1)}
.chs{font-size:12px;color:var(--s4);margin-top:3px;font-weight:300}
.cb{padding:26px}

/* Booking rows */
.bkrow{display:flex;align-items:center;justify-content:space-between;gap:12px;padding:16px 0;border-bottom:1.5px solid var(--s1);flex-wrap:wrap}
.bkrow:last-child{border-bottom:none}
.bkleft{display:flex;align-items:center;gap:14px;flex:1;min-width:0}
.bkico{width:44px;height:44px;border-radius:12px;background:var(--n1);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0}
.bkt{font-size:14px;font-weight:600;color:var(--n1);margin-bottom:3px;font-family:'Playfair Display',serif}
.bkm{font-size:12px;color:var(--s4);font-weight:300}
.bkact{display:flex;align-items:center;gap:7px;flex-shrink:0}

/* Message rows */
.mrow{display:flex;gap:14px;padding:16px 0;border-bottom:1.5px solid var(--s1)}
.mrow:last-child{border-bottom:none}
.mav{width:40px;height:40px;border-radius:11px;background:var(--n1);display:flex;align-items:center;justify-content:center;font-size:13px;font-weight:700;color:#fff;flex-shrink:0}
.mfrom{font-size:13px;font-weight:600;color:var(--n1)}.mtime{font-size:11px;color:var(--s4);font-weight:300}
.msubj{font-size:12px;font-weight:600;color:var(--s5);margin:3px 0}
.mprev{font-size:12px;color:var(--s4);font-weight:300;white-space:nowrap;overflow:hidden;text-overflow:ellipsis;max-width:500px}

/* Empty */
.empty{text-align:center;padding:64px 24px}
.ei{width:68px;height:68px;border-radius:18px;background:var(--s1);border:1.5px solid var(--s2);display:flex;align-items:center;justify-content:center;margin:0 auto 18px;font-size:30px}
.et{font-family:'Playfair Display',serif;font-size:18px;color:var(--n1);margin-bottom:8px;font-weight:700}
.es{font-size:13px;color:var(--s4);font-weight:300;max-width:320px;margin:0 auto 22px;line-height:1.65}

/* Settings */
.set-grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
.set-t{font-family:'Playfair Display',serif;font-size:16px;font-weight:700;color:var(--n1);margin-bottom:16px;padding-bottom:12px;border-bottom:1.5px solid var(--s1)}
.fta{width:100%;padding:11px 14px;border:1.5px solid var(--s2);border-radius:var(--r2);font-size:13px;color:var(--s6);background:var(--s0);outline:none;transition:.2s;resize:vertical;min-height:90px;font-family:'Inter',sans-serif}
.fta:focus{border-color:var(--n1);background:#fff;box-shadow:0 0 0 3px rgba(11,29,53,.06)}
.form2{display:grid;grid-template-columns:1fr 1fr;gap:16px}

/* Modal */
.mov{position:fixed;inset:0;background:rgba(6,15,31,.68);backdrop-filter:blur(6px);display:flex;align-items:center;justify-content:center;z-index:1000;padding:20px}
.mod{background:var(--w);border-radius:var(--r4);box-shadow:var(--sh4);width:100%;max-width:580px;max-height:92vh;display:flex;flex-direction:column;overflow:hidden}
.mod.wide{max-width:760px}
.mh{padding:24px 30px;border-bottom:1.5px solid var(--s1);display:flex;align-items:center;justify-content:space-between;background:linear-gradient(135deg,var(--n1),var(--n4))}
.mht{font-family:'Playfair Display',serif;font-size:19px;font-weight:700;color:#fff}
.mhs{font-size:12px;color:rgba(255,255,255,.44);margin-top:2px}
.mx{width:36px;height:36px;border-radius:9px;background:rgba(255,255,255,.08);display:flex;align-items:center;justify-content:center;font-size:20px;color:rgba(255,255,255,.62);transition:.15s;line-height:1}
.mx:hover{background:rgba(255,255,255,.16);color:#fff}
.mb{padding:30px;overflow-y:auto;flex:1}.mf{padding:16px 30px;border-top:1.5px solid var(--s1);display:flex;gap:10px;justify-content:flex-end;background:var(--s0)}

/* AI panel */
.aip{background:linear-gradient(135deg,var(--n1),var(--n4));border-radius:var(--r2);padding:18px 20px;margin-bottom:22px;border:1px solid rgba(200,150,62,.16)}
.aiph{display:flex;align-items:center;gap:8px;margin-bottom:12px}
.aipl{font-size:10px;letter-spacing:2px;text-transform:uppercase;color:var(--g3);font-weight:600}
.aiprow{display:flex;gap:10px}
.aiinp{flex:1;padding:10px 14px;border:1px solid rgba(255,255,255,.14);border-radius:var(--r2);background:rgba(255,255,255,.07);font-size:13px;color:#fff;outline:none;transition:.2s;font-family:'Inter',sans-serif}
.aiinp::placeholder{color:rgba(255,255,255,.28)}.aiinp:focus{border-color:rgba(200,150,62,.42);background:rgba(255,255,255,.11)}
.aibtn{padding:10px 18px;background:linear-gradient(135deg,var(--g),var(--g2));border-radius:var(--r2);color:var(--n1);font-size:12px;font-weight:700;white-space:nowrap;transition:.2s}
.aibtn:not(:disabled):hover{transform:translateY(-1px)}.aierr{font-size:12px;color:#FCA5A5;margin-top:8px}

/* Slots */
.slotgrid{display:grid;grid-template-columns:repeat(auto-fill,minmax(128px,1fr));gap:10px}
.slotbtn{padding:13px 10px;border:1.5px solid var(--s2);border-radius:var(--r2);background:var(--s0);display:flex;flex-direction:column;align-items:center;gap:5px;cursor:pointer;transition:.18s;font-size:13px;font-weight:500;color:var(--n1)}
.slotbtn:hover:not(:disabled){border-color:var(--g);background:var(--g4)}.slotbtn:disabled{opacity:.42;cursor:not-allowed}
.slot-tk{font-size:10px;color:var(--er);font-weight:600;letter-spacing:.8px}

/* Notification */
.notif{position:fixed;top:22px;right:22px;background:var(--w);border-radius:var(--r2);box-shadow:var(--sh4);padding:14px 20px;display:flex;align-items:center;gap:12px;z-index:9999;min-width:280px;max-width:420px;border-left:4px solid var(--ok);animation:nIn .3s cubic-bezier(.16,1,.3,1)}
.notif.err{border-left-color:var(--er)}.notif.warn{border-left-color:var(--am)}
.nf-ico{font-size:18px;flex-shrink:0}.nf-msg{font-size:13px;font-weight:500;color:var(--n1);flex:1}
@keyframes nIn{from{opacity:0;transform:translateX(40px)}to{opacity:1;transform:translateX(0)}}

/* Stream grid (registration & profile) */
.stream-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;max-height:200px;overflow-y:auto;border:1.5px solid var(--s2);border-radius:var(--r2);padding:12px;background:var(--s0)}
.stream-chk{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--s6);cursor:pointer;padding:5px 8px;border-radius:6px;transition:.15s}
.stream-chk:hover{background:var(--s1)}
.stream-chk input{accent-color:var(--n1);width:14px;height:14px;cursor:pointer;flex-shrink:0}

/* Responsive */
@media(max-width:1100px){.hero-grid{grid-template-columns:1fr}.hcard{display:none}.feat-grid{grid-template-columns:1fr 1fr}.roles-grid{grid-template-columns:1fr 1fr}.stats{grid-template-columns:1fr 1fr}}
@media(max-width:900px){.nav{padding:0 22px}.features,.roles-sec,.cta-band{padding:60px 22px}.hero{padding:100px 22px 60px}.hero-h1{font-size:40px}.auth{grid-template-columns:1fr}.auth-l{display:none}.auth-r{padding:46px 32px}.sb{display:none}.main{margin-left:0}.content{padding:20px}}
@media(max-width:640px){.feat-grid{grid-template-columns:1fr}.roles-grid{grid-template-columns:1fr}.mgrid{grid-template-columns:1fr}.form2{grid-template-columns:1fr}.set-grid{grid-template-columns:1fr}}
</style>
</head>
<body>
<?php if($page==='home'): ?>
<!-- ══════════════════════ LANDING PAGE ══════════════════════ -->
<nav class="nav">
  <div class="nav-brand">
    <div class="nav-emb"><?=e($settings['logo'])?></div>
    <div><div class="nav-sn"><?=e($settings['schoolName'])?></div><div class="nav-sm">Meeting Portal</div></div>
  </div>
  <div class="nav-links">
    <a href="#features" class="nav-link">Features</a>
    <a href="#roles" class="nav-link">Roles</a>
    <a href="?page=login" class="nav-cta">Sign In →</a>
  </div>
</nav>

<section class="hero">
  <div class="hero-orb1"></div><div class="hero-orb2"></div>
  <div class="hero-grid">
    <div>
      <div class="hero-pill"><span class="hero-dot"></span>Parent–Teacher Engagement Platform</div>
      <h1 class="hero-h1">Where Education<br/>Meets <em>Community</em></h1>
      <p class="hero-p">A unified digital platform for <?=e($settings['schoolName'])?> — seamlessly connecting parents, teachers, and school leadership through smart meeting scheduling and real-time communication.</p>
      <div class="hero-btns">
        <a href="?page=login" class="hbtn-p">Access the Portal →</a>
        <a href="#features" class="hbtn-g">Explore Features</a>
      </div>
      <div class="hero-stats">
        <div><span class="hs-n">4</span><span class="hs-l">User Roles</span></div>
        <div><span class="hs-n">AI</span><span class="hs-l">Powered</span></div>
        <div><span class="hs-n">24/7</span><span class="hs-l">Booking</span></div>
        <div><span class="hs-n">100%</span><span class="hs-l">Paperless</span></div>
      </div>
    </div>
    <div class="hcard">
      <div class="hcard-eye">Choose your portal</div>
      <div class="hcard-title">Sign in as</div>
      <?php foreach([['parent','🏠','#DBEAFE','Parent','Book &amp; manage appointments'],['teacher','📚','#D1FAE5','Teacher','Create meetings &amp; message parents'],['principal','🏆','#EDE9FE','Principal','School-wide oversight'],['admin','⚙️','#FDE68A','Admin','System configuration']] as [$r,$ico,$bg,$nm,$desc]):?>
      <a href="?page=login&role=<?=$r?>" class="role-row">
        <div class="role-ico" style="background:<?=$bg?>"><?=$ico?></div>
        <div><div class="role-name"><?=$nm?></div><div class="role-sub"><?=$desc?></div></div>
        <div class="role-arrow">→</div>
      </a>
      <?php endforeach;?>
    </div>
  </div>
</section>

<section class="features" id="features">
  <p class="sec-eye">Platform Features</p>
  <h2 class="sec-h2">Everything your school needs</h2>
  <p class="sec-sub">A complete, professional solution for parent-teacher engagement — purpose-built for modern schools.</p>
  <div class="feat-grid">
    <?php foreach([['📅','Smart Scheduling','Create parent-teacher meetings with flexible time slots, conflict-free booking, and instant calendar downloads.'],['✨','AI Communication','An integrated AI assistant drafts professional communications, apologies, and announcements in seconds.'],['🛡️','Role-Based Access','Separate, secure dashboards for parents, teachers, the principal, and administration with appropriate permissions.'],['🔔','Real-Time Updates','Meetings, bookings, and cancellations update instantly — keeping every stakeholder informed.'],['📄','Apology Management','A structured process for parents to formally cancel a booking and submit an apology to the school.'],['⬇️','Calendar Export','One-click .ICS downloads add meetings directly to Google Calendar, Outlook, or Apple Calendar.']] as [$ico,$t,$d]):?>
    <div class="fcard"><div class="fcard-ico"><?=$ico?></div><div class="fcard-t"><?=$t?></div><p class="fcard-d"><?=$d?></p></div>
    <?php endforeach;?>
  </div>
</section>

<section class="roles-sec" id="roles">
  <p class="sec-eye">Who uses this portal</p>
  <h2 class="sec-h2">Built for your whole school</h2>
  <p class="sec-sub">Each role has a tailored experience designed around their specific responsibilities.</p>
  <div class="roles-grid">
    <?php foreach([['parent','🏠','#DBEAFE','#1D4ED8','Parents','Book slots, download calendar invites, manage appointments, and send formal apologies.','Parent Login'],['teacher','📚','#D1FAE5','#065F46','Teachers','Create meetings, view bookings, and communicate with parents using the AI assistant.','Teacher Login'],['principal','🏆','#EDE9FE','#5B21B6','Principal','Full school-wide overview, analytics, meeting management, and announcements.','Principal Login'],['admin','⚙️','#FDE68A','#92400E','Admin','System configuration, school branding, data administration, and oversight.','Admin Login']] as [$r,$ico,$bg,$col,$nm,$desc,$btn]):?>
    <a href="?page=login&role=<?=$r?>" class="rcard">
      <div class="rcard-ico" style="background:<?=$bg?>"><?=$ico?></div>
      <div class="rcard-n"><?=$nm?></div><p class="rcard-d"><?=$desc?></p>
      <span class="rcard-btn" style="border-color:<?=$col?>;color:<?=$col?>"><?=$btn?> →</span>
    </a>
    <?php endforeach;?>
  </div>
</section>

<section class="cta-band">
  <h2 class="cta-h2">Ready to transform how your<br/><em>school connects?</em></h2>
  <p class="cta-sub">Sign in now and experience the modern parent-teacher meeting platform for <?=e($settings['schoolName'])?>.</p>
  <div class="cta-btns">
    <a href="?page=login&role=parent" class="hbtn-p">Parent Sign In</a>
    <a href="?page=login&role=teacher" class="hbtn-g">Teacher Sign In</a>
    <a href="?page=login&role=principal" class="hbtn-g">Principal Sign In</a>
  </div>
</section>
<footer class="site">
  <div class="foot-copy">© <?=date('Y')?> <?=e($settings['schoolName'])?> · <?=e($settings['address'])?></div>
  <div class="foot-links">
    <a href="mailto:<?=e($settings['email'])?>"><?=e($settings['email'])?></a>
    <a href="#">Privacy</a><a href="#">Support</a>
  </div>
</footer>

<?php elseif($page==='login'): ?>
<!-- ══════════════════════ AUTH PAGE (Sign In / Sign Up) ══════════════════════ -->
<?php
$rBgs=['parent'=>'#DBEAFE','teacher'=>'#D1FAE5','principal'=>'#EDE9FE','admin'=>'#FDE68A'];
$rCols=['parent'=>'#1D4ED8','teacher'=>'#065F46','principal'=>'#5B21B6','admin'=>'#92400E'];
$allClassListJson = json_encode($allClassList);
?>
<style>
.auth{display:grid;grid-template-columns:520px 1fr;min-height:100vh}
.auth-l{background:linear-gradient(148deg,var(--n0) 0%,var(--n3) 60%,#1a3d70 100%);padding:60px 56px;position:relative;overflow:hidden;display:flex;flex-direction:column;justify-content:space-between}
.auth-lorb{position:absolute;top:-180px;right:-140px;width:520px;height:520px;border-radius:50%;background:radial-gradient(circle,rgba(200,150,62,.14),transparent 65%);pointer-events:none}
.al-brand{display:flex;align-items:center;gap:16px;position:relative;z-index:1}
.al-emb{width:52px;height:52px;border-radius:14px;background:linear-gradient(135deg,var(--g),var(--g3));display:flex;align-items:center;justify-content:center;font-size:26px;box-shadow:0 0 28px rgba(200,150,62,.4)}
.al-sn{font-family:'Playfair Display',serif;font-size:18px;color:#fff;font-weight:700}
.al-sm{font-size:10px;color:var(--g3);letter-spacing:2px;text-transform:uppercase;margin-top:2px}
.al-body{position:relative;z-index:1;flex:1;display:flex;flex-direction:column;justify-content:center;padding:40px 0}
.al-h1{font-family:'Playfair Display',serif;font-size:42px;font-weight:800;color:#fff;line-height:1.1;letter-spacing:-.4px;margin-bottom:18px}
.al-h1 em{color:var(--g3);font-style:italic}
.al-p{font-size:15px;color:rgba(255,255,255,.55);line-height:1.8;font-weight:300;margin-bottom:36px}
.al-checks{list-style:none;display:flex;flex-direction:column;gap:12px}
.al-checks li{display:flex;align-items:center;gap:12px;font-size:13px;color:rgba(255,255,255,.62);font-weight:300}
.al-ck{width:22px;height:22px;background:rgba(200,150,62,.18);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:11px;color:var(--g3);font-weight:700;flex-shrink:0}
.al-foot{font-size:11px;color:rgba(255,255,255,.28);position:relative;z-index:1}
.auth-r{background:var(--w);display:flex;flex-direction:column;justify-content:center;padding:52px 64px;overflow-y:auto}
.ar-back{font-size:12px;color:var(--s4);display:inline-flex;align-items:center;gap:6px;margin-bottom:36px;font-weight:500;transition:.2s}
.ar-back:hover{color:var(--n1)}
/* Auth tabs */
.auth-tabs{display:flex;gap:0;border-bottom:2px solid var(--s1);margin-bottom:28px}
.auth-tab{flex:1;text-align:center;padding:12px;font-size:14px;font-weight:600;color:var(--s4);cursor:pointer;border-bottom:2px solid transparent;margin-bottom:-2px;transition:.2s}
.auth-tab.on{color:var(--n1);border-bottom-color:var(--n1)}
/* Role grid */
.ar-rlbl{font-size:11px;font-weight:700;letter-spacing:1.5px;text-transform:uppercase;color:var(--s4);margin-bottom:10px}
.ar-rgrid{display:grid;grid-template-columns:1fr 1fr 1fr 1fr;gap:8px;margin-bottom:20px}
.ar-rbtn{display:flex;flex-direction:column;align-items:center;gap:6px;padding:12px 6px;border-radius:var(--r2);background:var(--s0);border:1.5px solid var(--s2);font-size:11px;font-weight:600;color:var(--s5);transition:.2s;cursor:pointer}
.ar-rbtn:hover{border-color:var(--n1);color:var(--n1)}
.ar-rbtn.on{background:var(--n1);color:#fff;border-color:var(--n1)}
.ar-rbtn.on .ar-rico{background:rgba(255,255,255,.15)!important}
.ar-rico{width:32px;height:32px;border-radius:8px;display:flex;align-items:center;justify-content:center;font-size:16px;transition:.2s}
/* Form elements */
.fg{margin-bottom:16px}
.fl{display:block;font-size:12px;font-weight:600;color:var(--s5);margin-bottom:6px;letter-spacing:.3px}
.fi{width:100%;padding:11px 14px;border:1.5px solid var(--s2);border-radius:var(--r2);font-size:13px;outline:none;background:var(--w);transition:.2s;color:var(--s6)}
.fi:focus{border-color:var(--n1);box-shadow:0 0 0 3px rgba(11,29,53,.06)}
.fi-wrap{position:relative}
.fi-wrap .fi{padding-left:40px}
.fi-ico{position:absolute;left:13px;top:50%;transform:translateY(-50%);font-size:14px;color:var(--s4);pointer-events:none}
select.fi{appearance:none;background-image:url("data:image/svg+xml,%3Csvg xmlns='http://www.w3.org/2000/svg' width='12' height='8' viewBox='0 0 12 8'%3E%3Cpath d='M1 1l5 5 5-5' stroke='%238B9FC0' stroke-width='1.5' fill='none'/%3E%3C/svg%3E");background-repeat:no-repeat;background-position:right 12px center;padding-right:34px}
.form2{display:grid;grid-template-columns:1fr 1fr;gap:12px}
.btn-login{width:100%;padding:14px;background:linear-gradient(135deg,var(--n1),var(--n3));border-radius:var(--r2);color:#fff;font-size:14px;font-weight:700;transition:.2s;margin-top:6px}
.btn-login:hover{transform:translateY(-1px);box-shadow:var(--sh3)}
.auth-switch{text-align:center;margin-top:18px;font-size:13px;color:var(--s4)}
.auth-switch a{color:var(--n1);font-weight:600}
/* Stream checkboxes */
.stream-grid{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-height:200px;overflow-y:auto;border:1.5px solid var(--s2);border-radius:var(--r2);padding:12px;background:var(--s0)}
.stream-chk{display:flex;align-items:center;gap:8px;font-size:12px;color:var(--s6);cursor:pointer;padding:4px 6px;border-radius:6px;transition:.15s}
.stream-chk:hover{background:var(--s1)}
.stream-chk input{accent-color:var(--n1);width:14px;height:14px;cursor:pointer}
/* Divider */
.or-div{display:flex;align-items:center;gap:14px;margin:18px 0;color:var(--s3);font-size:11px;font-weight:600;text-transform:uppercase;letter-spacing:1px}
.or-div::before,.or-div::after{content:'';flex:1;height:1px;background:var(--s2)}
</style>
<div class="auth">
  <div class="auth-l">
    <div class="auth-lorb"></div>
    <div class="al-brand">
      <div class="al-emb"><?=e($settings['logo'])?></div>
      <div><div class="al-sn"><?=e($settings['schoolName'])?></div><div class="al-sm">Meeting Portal</div></div>
    </div>
    <div class="al-body">
      <h1 class="al-h1">The meeting portal<br/>for <em>modern schools</em></h1>
      <p class="al-p">Connect parents, teachers, and leadership through one seamless, secure platform built for CBC Kenya.</p>
      <ul class="al-checks">
        <?php foreach(['Secure role-based accounts for all staff & parents','Personalised meetings filtered by class stream','AI-powered professional school communications','Grade 1–10 CBC Kenya stream support'] as $f):?>
        <li><span class="al-ck">✓</span><?=$f?></li>
        <?php endforeach;?>
      </ul>
    </div>
    <div class="al-foot"><?=e($settings['email'])?> · <?=e($settings['website'])?></div>
  </div>
  <div class="auth-r">
    <a href="?page=home" class="ar-back">← Back to home</a>

    <!-- TABS -->
    <div class="auth-tabs">
      <div class="auth-tab on" id="tab_in" onclick="switchTab('in')">Sign In</div>
      <div class="auth-tab" id="tab_up" onclick="switchTab('up')">Create Account</div>
    </div>

    <!-- ── SIGN IN ─────────────────────────────────── -->
    <div id="pane_in">
      <div class="ar-rlbl">Select your role</div>
      <div class="ar-rgrid">
        <?php foreach([['parent','🏠','Parent'],['teacher','📚','Teacher'],['principal','🏆','Principal'],['admin','⚙️','Admin']] as [$r,$ico,$lbl]):$on=$preRole===$r?'on':'';?>
        <button class="ar-rbtn <?=$on?>" onclick="setRole('<?=$r?>')" type="button" id="rb_<?=$r?>">
          <div class="ar-rico" id="ri_<?=$r?>" style="background:<?=$on?'rgba(255,255,255,.15)':$rBgs[$r]?>"><?=$ico?></div><?=$lbl?>
        </button>
        <?php endforeach;?>
      </div>
      <div class="fg"><label class="fl">Email Address</label>
        <div class="fi-wrap"><span class="fi-ico">✉</span><input class="fi" type="email" id="authEmail" placeholder="Enter your email"/></div></div>
      <div class="fg"><label class="fl">Password</label>
        <div class="fi-wrap"><span class="fi-ico">🔒</span><input class="fi" type="password" id="authPwd" placeholder="Your password" onkeydown="if(event.key==='Enter')doLogin()"/></div></div>
      <button class="btn-login" id="loginBtn" onclick="doLogin()">→ Sign In</button>
      <p class="auth-switch">Don't have an account? <a href="#" onclick="switchTab('up');return false">Create one here</a></p>
    </div>

    <!-- ── SIGN UP ─────────────────────────────────── -->
    <div id="pane_up" style="display:none">
      <div class="ar-rlbl">I am a…</div>
      <div class="ar-rgrid" style="margin-bottom:20px">
        <?php foreach([['parent','🏠','Parent'],['teacher','📚','Teacher'],['principal','🏆','Principal'],['admin','⚙️','Admin']] as [$r,$ico,$lbl]):$on=$preRole===$r?'on':'';?>
        <button class="ar-rbtn <?=$on?>" onclick="setRegRole('<?=$r?>')" type="button" id="rrb_<?=$r?>">
          <div class="ar-rico" id="rri_<?=$r?>" style="background:<?=$on?'rgba(255,255,255,.15)':$rBgs[$r]?>"><?=$ico?></div><?=$lbl?>
        </button>
        <?php endforeach;?>
      </div>
      <div class="form2">
        <div class="fg"><label class="fl">Full Name *</label><input class="fi" type="text" id="reg_name" placeholder="e.g. Jane Wanjiru"/></div>
        <div class="fg"><label class="fl">Phone Number</label><input class="fi" type="tel" id="reg_phone" placeholder="+254 7xx xxx xxx"/></div>
      </div>
      <div class="fg"><label class="fl">Email Address *</label><input class="fi" type="email" id="reg_email" placeholder="yourname@example.com"/></div>

      <!-- Parent-specific fields -->
      <div id="reg_parent_fields">
        <div class="form2">
          <div class="fg"><label class="fl">Child's Full Name *</label><input class="fi" type="text" id="reg_studentName" placeholder="e.g. Kevin Ochieng"/></div>
          <div class="fg"><label class="fl">Child's Class / Stream *</label>
            <select class="fi" id="reg_studentClass">
              <option value="">— Select class —</option>
              <?php foreach($allClassList as $cls):?><option value="<?=e($cls)?>"><?=e($cls)?></option><?php endforeach;?>
            </select>
          </div>
        </div>
        <p style="font-size:11px;color:var(--s4);margin:-8px 0 14px">Can't find your class? The admin can add custom streams like "Grade 2 B" in Settings.</p>
      </div>

      <!-- Teacher-specific fields -->
      <div id="reg_teacher_fields" style="display:none">
        <div class="fg"><label class="fl">Department / Subject</label><input class="fi" type="text" id="reg_dept" placeholder="e.g. Mathematics, Sciences"/></div>
        <div class="fg">
          <label class="fl">Class Streams You Teach *</label>
          <p style="font-size:11px;color:var(--s4);margin-bottom:8px">Select all grades/streams you are responsible for. This personalises your meeting dashboard.</p>
          <div class="stream-grid" id="teacher_stream_grid">
            <?php foreach($allClassList as $cls):?>
            <label class="stream-chk">
              <input type="checkbox" name="teacher_stream" value="<?=e($cls)?>"/>
              <?=e($cls)?>
            </label>
            <?php endforeach;?>
          </div>
        </div>
      </div>

      <!-- Principal/Admin field -->
      <div id="reg_staff_fields" style="display:none">
        <div class="fg"><label class="fl">Department / Title</label><input class="fi" type="text" id="reg_staff_dept" placeholder="e.g. Head of Department, Deputy Principal"/></div>
      </div>

      <div class="form2">
        <div class="fg"><label class="fl">Password *</label><input class="fi" type="password" id="reg_pwd" placeholder="Min. 6 characters"/></div>
        <div class="fg"><label class="fl">Confirm Password *</label><input class="fi" type="password" id="reg_pwd2" placeholder="Repeat password" onkeydown="if(event.key==='Enter')doRegister()"/></div>
      </div>
      <button class="btn-login" id="regBtn" onclick="doRegister()">✓ Create Account</button>
      <p class="auth-switch">Already have an account? <a href="#" onclick="switchTab('in');return false">Sign in here</a></p>
    </div>

    <div id="authMsg" style="display:none;margin-top:14px;padding:12px 16px;border-radius:var(--r2);font-size:13px;font-weight:500"></div>
  </div>
</div>
<script>
var selRole='<?=e($preRole)?>';
var regRole='<?=e($preRole)?>';
var rBgs={parent:'#DBEAFE',teacher:'#D1FAE5',principal:'#EDE9FE',admin:'#FDE68A'};
var allClasses=<?=$allClassListJson?>;

function switchTab(t){
  document.getElementById('pane_in').style.display=t==='in'?'block':'none';
  document.getElementById('pane_up').style.display=t==='up'?'block':'none';
  document.getElementById('tab_in').classList.toggle('on',t==='in');
  document.getElementById('tab_up').classList.toggle('on',t==='up');
  document.getElementById('authMsg').style.display='none';
}
function setRole(r){
  selRole=r;
  ['parent','teacher','principal','admin'].forEach(x=>{
    var b=document.getElementById('rb_'+x),i=document.getElementById('ri_'+x);
    b.classList.toggle('on',x===r);
    if(i) i.style.background=x===r?'rgba(255,255,255,.15)':rBgs[x];
  });
}
function setRegRole(r){
  regRole=r;
  ['parent','teacher','principal','admin'].forEach(x=>{
    var b=document.getElementById('rrb_'+x),i=document.getElementById('rri_'+x);
    b.classList.toggle('on',x===r);
    if(i) i.style.background=x===r?'rgba(255,255,255,.15)':rBgs[x];
  });
  document.getElementById('reg_parent_fields').style.display=r==='parent'?'block':'none';
  document.getElementById('reg_teacher_fields').style.display=r==='teacher'?'block':'none';
  document.getElementById('reg_staff_fields').style.display=(r==='principal'||r==='admin')?'block':'none';
}
setRole(selRole); setRegRole(regRole);

// Open the signup tab if ?tab=signup in URL
if(new URLSearchParams(location.search).get('tab')==='signup') switchTab('up');

function showAuthMsg(msg,ok){
  var el=document.getElementById('authMsg');
  el.style.display='block';
  el.style.background=ok?'var(--okbg)':'var(--erbg)';
  el.style.color=ok?'var(--ok)':'var(--er)';
  el.style.border='1.5px solid '+(ok?'rgba(10,124,90,.2)':'rgba(185,28,28,.2)');
  el.textContent=msg;
}
function doLogin(){
  var btn=document.getElementById('loginBtn');
  var email=document.getElementById('authEmail').value.trim();
  var pwd=document.getElementById('authPwd').value;
  if(!email||!pwd){showAuthMsg('Please enter your email and password.');return;}
  btn.disabled=true;btn.textContent='Signing in…';
  fetch('?action=login',{method:'POST',headers:{'Content-Type':'application/json'},
    body:JSON.stringify({email,password:pwd,role:selRole})
  }).then(r=>r.json()).then(d=>{
    if(d.ok) window.location.href='?page=dashboard&tab=meetings';
    else{showAuthMsg(d.error||'Login failed.');btn.disabled=false;btn.textContent='→ Sign In';}
  }).catch(()=>{showAuthMsg('Network error. Please try again.');btn.disabled=false;btn.textContent='→ Sign In';});
}
function doRegister(){
  var btn=document.getElementById('regBtn');
  var name=document.getElementById('reg_name').value.trim();
  var email=document.getElementById('reg_email').value.trim();
  var phone=document.getElementById('reg_phone').value.trim();
  var pwd=document.getElementById('reg_pwd').value;
  var pwd2=document.getElementById('reg_pwd2').value;

  var body={role:regRole,name,email,phone,password:pwd,password2:pwd2};

  if(regRole==='parent'){
    body.studentName=document.getElementById('reg_studentName').value.trim();
    body.studentClass=document.getElementById('reg_studentClass').value;
    if(!body.studentName||!body.studentClass){showAuthMsg('Please enter your child\'s name and class.');return;}
  } else if(regRole==='teacher'){
    body.dept=document.getElementById('reg_dept').value.trim();
    body.streams=[...document.querySelectorAll('#teacher_stream_grid input:checked')].map(x=>x.value);
    if(body.streams.length===0){showAuthMsg('Please select at least one class stream you teach.');return;}
  } else {
    body.dept=document.getElementById('reg_staff_dept').value.trim();
  }

  if(!name){showAuthMsg('Full name is required.');return;}
  if(!email){showAuthMsg('Email is required.');return;}
  if(pwd.length<6){showAuthMsg('Password must be at least 6 characters.');return;}
  if(pwd!==pwd2){showAuthMsg('Passwords do not match.');return;}

  btn.disabled=true;btn.textContent='Creating account…';
  fetch('?action=register',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
  .then(r=>r.json()).then(d=>{
    btn.disabled=false;btn.textContent='✓ Create Account';
    if(d.ok){
      showAuthMsg('✓ Account created! You can now sign in.',true);
      setTimeout(()=>switchTab('in'),1800);
    } else {
      showAuthMsg(d.error||'Registration failed.');
    }
  }).catch(()=>{showAuthMsg('Network error.');btn.disabled=false;btn.textContent='✓ Create Account';});
}
</script>

<?php elseif($page==='dashboard'&&$user): ?>
<!-- ══════════════════════ DASHBOARD ══════════════════════ -->
<div class="app">
<aside class="sb">
  <div class="sb-brand">
    <div class="sb-logo"><?=e($settings['logo'])?></div>
    <div><div class="sb-sn"><?=e(explode(' ',$settings['schoolName'])[0])?></div><div class="sb-sp">Meeting Portal</div></div>
  </div>
  <div class="sb-user" onclick="openProfile()" style="cursor:pointer" title="Edit Profile">
    <?php if(!empty($user['avatar'])):?>
      <div class="sb-av" style="overflow:hidden;padding:0;flex-shrink:0"><img src="<?=e($user['avatar'])?>" style="width:40px;height:40px;object-fit:cover;border-radius:11px" alt="avatar"/></div>
    <?php else:?>
      <div class="sb-av" style="background:<?=e($user['color'])?>"><?=e($initials)?></div>
    <?php endif;?>
    <div style="flex:1;min-width:0"><div class="sb-un" style="overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?=e($user['name'])?></div><div class="sb-ur"><?=e($user['badge']??$user['role'])?><?php if(!empty($user['class'])):?> · <?=e($user['class'])?><?php endif;?></div></div>
    <span style="color:rgba(255,255,255,.3);font-size:12px;flex-shrink:0">✏</span>
  </div>
  <nav class="sb-nav">
    <div class="sb-grp">Navigation</div>
    <a href="?page=dashboard&tab=meetings" class="sb-link <?=$tab==='meetings'?'on':''?>">
      <span class="sb-ico">📅</span>All Meetings
      <?php if(count($activeMeetings)>0):?><span class="sb-badge"><?=count($activeMeetings)?></span><?php endif;?>
    </a>
    <?php if($user['role']==='parent'):?>
    <a href="?page=dashboard&tab=past" class="sb-link <?=$tab==='past'?'on':''?>">
      <span class="sb-ico">📜</span>Past Meetings
      <?php $myPastCount=count(array_filter($viewInactive,fn($m)=>array_reduce($myBookings,fn($carry,$b)=>$carry||$b['meetingId']===$m['id'],false)));
      if($myPastCount>0):?><span class="sb-badge"><?=$myPastCount?></span><?php endif;?>
    </a>
    <?php endif;?>
    <a href="?page=dashboard&tab=bookings" class="sb-link <?=$tab==='bookings'?'on':''?>">
      <span class="sb-ico">✅</span>Bookings
      <?php if(count($myBookings)>0):?><span class="sb-badge"><?=count($myBookings)?></span><?php endif;?>
    </a>
    <a href="?page=dashboard&tab=messages" class="sb-link <?=$tab==='messages'?'on':''?>"><span class="sb-ico">💬</span>Communications</a>
    <?php
      $myUnread=count(array_filter($chats,fn($c)=>$c['toId']===$user['id']&&empty($c['readAt'])));
    ?>
    <a href="?page=dashboard&tab=chat" class="sb-link <?=$tab==='chat'?'on':''?>">
      <span class="sb-ico">🗨️</span>Direct Messages
      <?php if($myUnread>0):?><span class="sb-badge" style="background:var(--er)"><?=$myUnread?></span><?php endif;?>
    </a>
    <a href="?page=dashboard&tab=apologies" class="sb-link <?=$tab==='apologies'?'on':''?>">
      <span class="sb-ico">📋</span>Apologies Log
      <?php $pendingApologies=count(array_filter($apologies,fn($a)=>($a['status']??'pending')==='pending')); if($pendingApologies>0):?><span class="sb-badge"><?=$pendingApologies?></span><?php endif;?>
    </a>
    <?php if(in_array($user['role'],['teacher','principal','admin'])):?>
    <div class="sb-grp">Management</div>
    <a href="#" class="sb-link" onclick="openModal('create');return false"><span class="sb-ico">➕</span>Create Meeting</a>
    <?php if(in_array($user['role'],['principal','admin'])):?>
    <a href="?page=dashboard&tab=settings" class="sb-link <?=$tab==='settings'?'on':''?>"><span class="sb-ico">⚙️</span>Settings</a>
    <?php endif;?>
    <?php endif;?>
  </nav>
  <div class="sb-bot"><button class="sb-out" onclick="doLogout()"><span class="sb-ico">🚪</span>Sign Out</button></div>
</aside>

<div class="main">
<header class="tbar">
  <div>
    <div class="tb-title"><?php if($tab==='meetings') echo 'All School Meetings'; elseif($tab==='bookings') echo 'Meeting Bookings'; elseif($tab==='messages') echo 'Communications'; elseif($tab==='settings') echo 'System Settings'; elseif($tab==='past') echo 'Past Class Meetings'; elseif($tab==='apologies') echo 'Apologies Log'; elseif($tab==='chat') echo 'Direct Messages';?></div>
    <div class="tb-sub">Welcome, <?=e(explode(' ',$user['name'])[0])?> · <?=e(date('l, d F Y'))?></div>
  </div>
  <div class="tb-r">
    <button class="tb-btn" title="Notifications">🔔</button>
    <button class="uchip" onclick="openProfile()" title="Edit Profile">
      <?php if(!empty($user['avatar'])):?>
        <div class="uchip-av" style="overflow:hidden;padding:0"><img src="<?=e($user['avatar'])?>" style="width:100%;height:100%;object-fit:cover" alt="avatar"/></div>
      <?php else:?>
        <div class="uchip-av" style="background:<?=e($user['color'])?>"><?=e($initials)?></div>
      <?php endif;?>
      <span class="uchip-n"><?=e($user['badge']??$user['role'])?></span>
      <span style="font-size:11px;color:var(--s4);margin-left:2px">✏</span>
    </button>
  </div>
</header>

<div class="content">
<!-- Stats -->
<div class="stats">
  <div class="stat"><div class="stat-ico" style="background:rgba(11,29,53,.07)">📅</div><div><div class="stat-v"><?=$totalMtg?></div><div class="stat-l">Total Meetings</div></div></div>
  <div class="stat"><div class="stat-ico" style="background:var(--okbg)">🟢</div><div><div class="stat-v"><?=$activeCnt?></div><div class="stat-l">Active</div></div></div>
  <div class="stat"><div class="stat-ico" style="background:var(--blbg)">📋</div><div><div class="stat-v"><?=count($dispBk)?></div><div class="stat-l"><?=$user['role']==='parent'?'My Bookings':'Bookings'?></div></div></div>
  <div class="stat"><div class="stat-ico" style="background:var(--ambg)">💬</div><div><div class="stat-v"><?=count($messages)?></div><div class="stat-l">Messages</div></div></div>
</div>

<?php if($tab==='meetings'): ?>

<?php if($user['role']==='parent' && !empty($myBookings)): ?>
<!-- Parent: My bookings quick summary banner -->
<div style="background:linear-gradient(135deg,#f0fdf9,#e6f7f2);border:1.5px solid rgba(10,124,90,.2);border-radius:var(--r3);padding:16px 20px;margin-bottom:18px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
  <div style="display:flex;align-items:center;gap:12px">
    <div style="width:40px;height:40px;background:var(--okbg);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">✅</div>
    <div>
      <div style="font-weight:700;font-size:14px;color:var(--ok)">You have <?=count($myBookings)?> active booking<?=count($myBookings)!==1?'s':''?></div>
      <div style="font-size:12px;color:var(--s4);margin-top:2px">
        <?php foreach($myBookings as $bk): $bkMtg=null; foreach($meetings as $mm) if($mm['id']===$bk['meetingId']){$bkMtg=$mm;break;} ?>
          <?php if($bkMtg): ?><span style="background:#fff;border:1px solid rgba(10,124,90,.2);border-radius:99px;padding:2px 10px;margin-right:4px;font-size:11px;font-weight:600;color:var(--ok)"><?=e($bkMtg['title'])?> · <?=e($bk['slot']??'')?></span><?php endif; ?>
        <?php endforeach; ?>
      </div>
    </div>
  </div>
  <a href="?page=dashboard&tab=bookings" class="btn-o btn-s" style="border-color:var(--ok);color:var(--ok);white-space:nowrap">View All Bookings →</a>
</div>
<?php endif; ?>

<!-- Toolbar -->
<form method="GET" id="ff">
  <input type="hidden" name="page" value="dashboard"/><input type="hidden" name="tab" value="meetings"/>
  <div class="toolrow">
    <div class="sbox"><span class="sbox-ico">🔍</span><input class="sinp" type="text" name="q" value="<?=e($search)?>" placeholder="Search meetings…"/></div>
    <?php if($user['role']!=='teacher'&&!empty($allClasses)):?>
    <select class="fsel" name="class" onchange="document.getElementById('ff').submit()">
      <option value="all" <?=$clsF==='all'?'selected':''?>>All Classes</option>
      <?php foreach($allClasses as $c):?><option value="<?=e($c)?>" <?=$clsF===$c?'selected':''?>><?=e($c)?></option><?php endforeach;?>
    </select>
    <?php endif;?>
    <button type="submit" class="btn-n btn-s">Search</button>
    <?php if($search||$clsF!=='all'):?><a href="?page=dashboard&tab=meetings" class="btn-o btn-s">✕ Clear</a><?php endif;?>
    <?php if(in_array($user['role'],['teacher','principal','admin'])):?><button type="button" class="btn-g" onclick="openModal('create')">➕ New Meeting</button><?php endif;?>
  </div>
</form>

<!-- Active Meetings -->
<div class="sec-row">
  <div class="sec-left"><span class="sec-badge badge-live">🟢 Active</span><span class="sec-title">Upcoming Meetings</span></div>
  <span class="sec-cnt"><?=count($viewActive)?> meeting<?=count($viewActive)!==1?'s':''?></span>
</div>
<?php if(empty($viewActive)):?>
<div style="background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);margin-bottom:8px">
  <div class="empty"><div class="ei">📅</div><div class="et">No active meetings</div>
    <div class="es"><?=($search||$clsF!=='all')?'No meetings match your filters.':'No upcoming meetings scheduled yet.'?></div>
    <?php if(in_array($user['role'],['teacher','principal','admin'])):?><button type="button" class="btn-g" onclick="openModal('create')">➕ Schedule First Meeting</button><?php endif;?>
  </div>
</div>
<?php else:?>
<div class="mgrid" style="margin-bottom:8px">
<?php foreach($viewActive as $m):
  $mBks=array_values(array_filter($bookings,fn($b)=>$b['meetingId']===$m['id']));
  $myBk=null; foreach($myBookings as $b) if($b['meetingId']===$m['id']){$myBk=$b;break;}
  $dt=new DateTime($m['date']); $dStr=$dt->format('D, d M Y');
  $dl=(int)$now->diff($dt)->days; $dl=$dt>=$now?$dl:-$dl;
?>
<div class="mc">
  <div class="mc-stripe" style="background:linear-gradient(90deg,var(--g),var(--g3))"></div>
  <div class="mc-body">
    <div class="mc-ico"><?=e($m['icon']??'📅')?></div>
    <div class="mc-tags">
      <?php if($m['class']??''):?><span class="tag tg0"><?=e($m['class'])?></span><?php endif;?>
      <span class="tag tg1">🟢 Active</span>
      <?php
        $mt_label=['physical'=>'🏫 Physical','online'=>'💻 Online','hybrid'=>'🔀 Hybrid'][($m['meetingType']??'physical')]??'🏫 Physical';
        $mt_style=['physical'=>'background:var(--okbg);color:var(--ok)','online'=>'background:var(--blbg);color:var(--bl)','hybrid'=>'background:var(--vibg);color:var(--vi)'][($m['meetingType']??'physical')]??'';
      ?>
      <span class="tag" style="<?=$mt_style?>"><?=$mt_label?></span>
      <?php if(!empty($m['targetParentId'])):?>
        <?php $tp=null;foreach(ld('users') as $u2)if($u2['id']===$m['targetParentId']){$tp=$u2;break;}?>
        <span class="tag tg4">👤 <?=e($tp?$tp['name']:'Individual')?></span>
      <?php endif;?>
      <?php if($myBk):?><span class="tag tg3">✓ Booked</span><?php endif;?>
      <?php if($dl<=3&&$dl>=0):?><span class="tag tg4">⚡ <?=$dl?> day<?=$dl!==1?'s':''?></span><?php endif;?>
    </div>
    <div class="mc-title"><?=e($m['title'])?></div>
    <?php if($m['description']??''):?><div class="mc-desc"><?=e($m['description'])?></div><?php endif;?>
    <div class="mc-meta">
      <div class="mr"><span class="mr-ic">📅</span><?=e($dStr)?></div>
      <?php if($m['location']??''):?><div class="mr"><span class="mr-ic">📍</span><?=e($m['location'])?></div><?php endif;?>
      <?php if($m['meetingLink']??''):?><div class="mr"><span class="mr-ic">🎥</span>Online Meeting Available</div><?php endif;?>
      <div class="mr"><span class="mr-ic">🕐</span><?=count($m['timeSlots']??[])?> time slot<?=count($m['timeSlots']??[])!==1?'s':''?></div>
    </div>
  </div>
  <div class="mc-foot">
    <div class="mc-bc">👥 <?=count($mBks)?> booking<?=count($mBks)!==1?'s':''?></div>
    <div style="display:flex;gap:6px;align-items:center;flex-wrap:wrap">
      <button class="bico" title="View" onclick='viewMeeting(<?=jd($m)?>,<?=jd($mBks)?>)'>👁</button>
      <?php if($user['role']==='parent'):?>
        <?php if($myBk):?>
          <span style="background:var(--okbg);color:var(--ok);border:1.5px solid rgba(10,124,90,.25);border-radius:99px;padding:4px 13px;font-size:12px;font-weight:700">✓ Slot: <?=e($myBk['slot']??'Booked')?></span>
          <button class="btn-o btn-s" onclick='dlICS(<?=jd($m)?>,<?=jd($myBk)?>)'>📅 Calendar</button>
          <button class="btn-o btn-s" style="border-color:var(--er);color:var(--er)" onclick='cancelModal(<?=jd($myBk)?>,<?=jd($m)?>)'>✕ Cancel</button>
        <?php else:?><button class="btn-g" style="font-size:13px;padding:8px 20px" onclick='openBookModal(<?=jd($m)?>,<?=jd($mBks)?>)'>➕ Book My Slot</button>
        <?php endif;?>
      <?php endif;?>
      <?php if(in_array($user['role'],['teacher','admin','principal'])):?>
      <button class="bico" title="Edit" onclick='openEditModal(<?=jd($m)?>)'>✏</button>
      <button class="bico d" title="Delete" onclick='delMeeting("<?=e($m['id'])?>","<?=e(addslashes($m['title']))?>")')>🗑</button>
      <?php endif;?>
      <?php if(in_array($user['role'],['teacher','principal','admin'])):?>
      <button class="btn-n btn-s" onclick='openContactModal("","",<?=jd($m)?>)'>✉ Contact</button>
      <button class="btn-g btn-s" onclick='notifyAllParents("<?=e($m['id'])?>","<?=e(addslashes($m['title']))?>")'>📨 Notify All</button>
      <?php endif;?>
    </div>
  </div>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

<hr class="divider"/>

<!-- Past Meetings -->
<div class="sec-row">
  <div class="sec-left"><span class="sec-badge badge-past">⬜ Past</span><span class="sec-title">Past Meetings</span></div>
  <span class="sec-cnt"><?=count($viewInactive)?> meeting<?=count($viewInactive)!==1?'s':''?></span>
</div>
<?php if(empty($viewInactive)):?>
<div style="background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);padding:28px;text-align:center"><p style="color:var(--s4);font-size:13px;font-weight:300">No past meetings found.</p></div>
<?php else:?>
<div class="mgrid">
<?php foreach($viewInactive as $m):
  $mBks=array_values(array_filter($bookings,fn($b)=>$b['meetingId']===$m['id']));
  $dStr=(new DateTime($m['date']))->format('D, d M Y');
?>
<div class="mc" style="opacity:.78">
  <div class="mc-stripe" style="background:var(--s2)"></div>
  <div class="mc-body">
    <div class="mc-ico" style="opacity:.45"><?=e($m['icon']??'📅')?></div>
    <div class="mc-tags">
      <?php if($m['class']??''):?><span class="tag tg0"><?=e($m['class'])?></span><?php endif;?>
      <span class="tag" style="background:var(--s1);color:var(--s4)">⬜ Past</span>
      <?php
        $mt_label=['physical'=>'🏫 Physical','online'=>'💻 Online','hybrid'=>'🔀 Hybrid'][($m['meetingType']??'physical')]??'🏫 Physical';
      ?>
      <span class="tag" style="background:var(--s1);color:var(--s5)"><?=$mt_label?></span>
      <?php if($user['role']==='parent'):
        $wasBk=null; foreach($myBookings as $bk) if($bk['meetingId']===$m['id']){$wasBk=$bk;break;};
        if($wasBk):?><span class="tag tg3">✓ Attended</span><?php else:?><span class="tag" style="background:var(--ambg);color:var(--am)">— Not booked</span><?php endif;?>
      <?php endif;?>
    </div>
    <div class="mc-title" style="color:var(--s5)"><?=e($m['title'])?></div>
    <?php if($m['description']??''):?><div class="mc-desc"><?=e($m['description'])?></div><?php endif;?>
    <div class="mc-meta">
      <div class="mr"><span class="mr-ic">📅</span><?=e($dStr)?></div>
      <?php if($m['location']??''):?><div class="mr"><span class="mr-ic">📍</span><?=e($m['location'])?></div><?php endif;?>
      <div class="mr"><span class="mr-ic">👥</span><?=count($mBks)?> booking<?=count($mBks)!==1?'s':''?> were made</div>
    </div>
  </div>
  <div class="mc-foot">
    <div class="mc-bc">📊 <?=count($mBks)?> total</div>
    <div style="display:flex;gap:6px;align-items:center">
      <button class="bico" title="View" onclick='viewMeeting(<?=jd($m)?>,<?=jd($mBks)?>)'>👁</button>
      <?php if($user['role']==='parent'):
        $wasBk2=null; foreach($myBookings as $bk) if($bk['meetingId']===$m['id']){$wasBk2=$bk;break;};
        if($wasBk2):?><button class="btn-o btn-s" onclick='dlICS(<?=jd($m)?>,<?=jd($wasBk2)?>)'>📅 Record</button><?php endif;?>
      <?php endif;?>
      <?php if(in_array($user['role'],['teacher','admin','principal'])):?>
      <button class="bico d" title="Delete" onclick='delMeeting("<?=e($m['id'])?>","<?=e(addslashes($m['title']))?>")')>🗑</button>
      <?php endif;?>
    </div>
  </div>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

<?php elseif($tab==='past'&&$user['role']==='parent'): ?>
<!-- Parent Past Meetings Tab -->
<div class="sec-row">
  <div class="sec-left"><span class="sec-badge badge-past">📜 History</span><span class="sec-title">Past Meetings — <?=e($user['class'])?></span></div>
  <span class="sec-cnt"><?=count($viewInactive)?> meeting<?=count($viewInactive)!==1?'s':''?></span>
</div>
<?php if(empty($viewInactive)):?>
<div style="background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3)">
  <div class="empty"><div class="ei">📜</div><div class="et">No past meetings yet</div><div class="es">Past meetings for your class will appear here once they have taken place.</div></div>
</div>
<?php else:?>
<?php
  $attendedCount=count(array_filter($viewInactive,fn($m)=>array_reduce($myBookings,fn($c,$b)=>$c||$b['meetingId']===$m['id'],false)));
  $missedCount=count($viewInactive)-$attendedCount;
?>
<div style="display:grid;grid-template-columns:repeat(3,1fr);gap:14px;margin-bottom:22px">
  <div class="stat"><div class="stat-ico" style="background:var(--s1)">📜</div><div><div class="stat-v"><?=count($viewInactive)?></div><div class="stat-l">Total Past</div></div></div>
  <div class="stat"><div class="stat-ico" style="background:var(--okbg)">✅</div><div><div class="stat-v"><?=$attendedCount?></div><div class="stat-l">Attended</div></div></div>
  <div class="stat"><div class="stat-ico" style="background:var(--ambg)">—</div><div><div class="stat-v"><?=$missedCount?></div><div class="stat-l">Not Booked</div></div></div>
</div>
<div class="mgrid">
<?php foreach($viewInactive as $m):
  $mBks=array_values(array_filter($bookings,fn($b)=>$b['meetingId']===$m['id']));
  $dStr=(new DateTime($m['date']))->format('D, d M Y');
  $wasBk=null; foreach($myBookings as $bk) if($bk['meetingId']===$m['id']){$wasBk=$bk;break;};
  $mt_label=['physical'=>'🏫 Physical','online'=>'💻 Online','hybrid'=>'🔀 Hybrid'][($m['meetingType']??'physical')]??'🏫 Physical';
?>
<div class="mc" style="opacity:.85">
  <div class="mc-stripe" style="background:<?=$wasBk?'linear-gradient(90deg,var(--ok),#0ea572)':'var(--s2)'?>"></div>
  <div class="mc-body">
    <div class="mc-ico" style="opacity:.45"><?=e($m['icon']??'📅')?></div>
    <div class="mc-tags">
      <?php if($m['class']??''):?><span class="tag tg0"><?=e($m['class'])?></span><?php endif;?>
      <span class="tag" style="background:var(--s1);color:var(--s4)">⬜ Past</span>
      <span class="tag" style="background:var(--s1);color:var(--s5)"><?=$mt_label?></span>
      <?php if($wasBk):?><span class="tag tg1">✓ Attended</span><?php else:?><span class="tag" style="background:var(--ambg);color:var(--am)">— Not booked</span><?php endif;?>
    </div>
    <div class="mc-title" style="color:var(--s5)"><?=e($m['title'])?></div>
    <?php if($m['description']??''):?><div class="mc-desc"><?=e($m['description'])?></div><?php endif;?>
    <div class="mc-meta">
      <div class="mr"><span class="mr-ic">📅</span><?=e($dStr)?></div>
      <?php if($m['location']??''):?><div class="mr"><span class="mr-ic">📍</span><?=e($m['location'])?></div><?php endif;?>
      <?php if($wasBk):?><div class="mr"><span class="mr-ic">🕐</span>Your slot: <strong><?=e($wasBk['slot'])?></strong></div><?php endif;?>
      <div class="mr"><span class="mr-ic">👥</span><?=count($mBks)?> parent<?=count($mBks)!==1?'s':''?> attended</div>
    </div>
  </div>
  <div class="mc-foot">
    <div class="mc-bc"><?=$wasBk?'✓ You attended':'— Not booked'?></div>
    <div style="display:flex;gap:6px;align-items:center">
      <button class="bico" title="View Details" onclick='viewMeeting(<?=jd($m)?>,<?=jd($mBks)?>)'>👁</button>
      <?php if($wasBk):?><button class="btn-o btn-s" onclick='dlICS(<?=jd($m)?>,<?=jd($wasBk)?>)'>📅 Record</button><?php endif;?>
    </div>
  </div>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

<?php elseif($tab==='bookings'): ?>
<!-- Bookings -->
<div class="card">
  <div class="ch"><div><div class="cht"><?=$user['role']==='parent'?'My Booked Meetings':'All Bookings'?></div><div class="chs"><?=count($dispBk)?> booking<?=count($dispBk)!==1?'s':''?></div></div></div>
  <div class="cb">
    <?php if(empty($dispBk)):?>
    <div class="empty"><div class="ei">✅</div><div class="et">No bookings yet</div><div class="es"><?=$user['role']==='parent'?'Browse upcoming meetings to book your slot.':'No bookings in the system yet.'?></div><?php if($user['role']==='parent'):?><a href="?page=dashboard&tab=meetings" class="btn-g">📅 Browse Meetings</a><?php endif;?></div>
    <?php else:?>
    <?php foreach($dispBk as $b):$mt=null;foreach($meetings as $mm)if($mm['id']===$b['meetingId']){$mt=$mm;break;}?>
    <div class="bkrow">
      <div class="bkleft">
        <div class="bkico"><?=e($mt?($mt['icon']??'📅'):'📅')?></div>
        <div>
          <div class="bkt"><?=e($mt?$mt['title']:'Unknown Meeting')?></div>
          <div class="bkm">
            📅 <strong><?=e($mt?date('d M Y',strtotime($mt['date'])):'—')?></strong>
            &nbsp;·&nbsp; 🕐 Slot: <strong><?=e($b['slot']??'—')?></strong>
            <?=$b['studentName']??''?' &nbsp;·&nbsp; 👤 Student: '.e($b['studentName']):'';?>
            <?=$mt&&($mt['location']??'')?' &nbsp;·&nbsp; 📍 '.e($mt['location']):'';?>
          </div>
          <div style="margin-top:4px;font-size:11px;color:var(--s4)">Booked on <?=e(date('d M Y',strtotime($b['bookedAt']??'now')))?></div>
        </div>
      </div>
      <div class="bkact">
        <span class="tag tg1">✓ Confirmed</span>
        <?php if($user['role']==='parent'):?>
        <button class="btn-o btn-s" title="Download Calendar Invite" onclick='dlICS(<?=jd($mt??[])?>,<?=jd($b)?>)'>📅 Calendar</button>
        <button class="btn-o btn-s" style="border-color:var(--er);color:var(--er)" title="Cancel Booking &amp; Send Apology" onclick='cancelModal(<?=jd($b)?>,<?=jd($mt??[])?>)'>✕ Cancel &amp; Apologise</button>
        <?php endif;?>
        <?php if(in_array($user['role'],['teacher','principal','admin'])):?>
        <button class="btn-n btn-s" onclick='openContactModal("<?=e($b['userEmail']??'')?>","<?=e($b['userPhone']??'')?>",<?=jd($mt??[])?>,<?=jd($b)?>)'>💬 Contact</button>
        <?php endif;?>
      </div>
    </div>
    <?php endforeach;?>
    <?php endif;?>
  </div>
</div>

<?php elseif($tab==='messages'): ?>
<!-- Messages / Communications -->
<div class="card">
  <div class="ch">
    <div><div class="cht">Communications</div><div class="chs"><?=count($dispMsg)?> message<?=count($dispMsg)!==1?'s':''?></div></div>
    <div style="display:flex;gap:8px;flex-wrap:wrap">
      <button class="btn-o btn-s" onclick="openWhatsApp()" style="border-color:#25D366;color:#25D366;gap:6px">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
        WhatsApp
      </button>
      <button class="btn-g" onclick="openModal('compose')">✉ New Message</button>
    </div>
  </div>
  <div class="cb">
    <?php if(empty($dispMsg)):?>
    <div class="empty"><div class="ei">💬</div><div class="et">No messages yet</div><div class="es">No communications sent or received.</div></div>
    <?php else:?>
    <?php foreach($dispMsg as $msg):
      $av=strtoupper(substr($msg['fromName']??'?',0,1)).(strpos($msg['fromName']??'',' ')!==false?strtoupper(substr(explode(' ',$msg['fromName'])[1]??'',0,1)):'');
      $sd=date('d M Y, H:i',strtotime($msg['sentAt']));
    ?>
    <div class="mrow">
      <div class="mav"><?=e($av)?></div>
      <div style="flex:1;min-width:0">
        <div style="display:flex;align-items:center;justify-content:space-between;gap:8px;flex-wrap:wrap">
          <span class="mfrom"><?=e($msg['fromName']??'')?> <span style="color:var(--s4);font-weight:300;font-size:12px">→ <?=e($msg['to']??'')?></span></span>
          <span class="mtime"><?=e($sd)?></span>
        </div>
        <div class="msubj"><?=e($msg['subject']??'')?></div>
        <div class="mprev"><?=e($msg['message']??'')?></div>
                        <?php if(isset($msg['emailSent'])): ?>
                        <span style="font-size:10px;font-weight:600;letter-spacing:.5px;padding:2px 8px;border-radius:99px;<?=$msg['emailSent']?'background:var(--okbg);color:var(--ok)':'background:var(--ambg);color:var(--am)'?>"
                          <?php if(!$msg['emailSent']&&!empty($msg['emailError'])):?>title="<?=e($msg['emailError'])?>"<?php endif;?>>
                          <?=$msg['emailSent']?'✓ Delivered':'⚠ Email failed'?>
                        </span>
                        <?php endif; ?>
      </div>
    </div>
    <?php endforeach;?>
    <?php endif;?>
  </div>
</div>

<?php elseif($tab==='chat'): ?>
<!-- ═══════════════════ DIRECT MESSAGES ═══════════════════ -->
<?php
  $allUsers    = ld('users');
  $chatWithId  = trim($_GET['chatWith'] ?? '');
  $chatWith    = null;
  $threadMsgs  = [];

  // Build contacts (people this user has chatted with)
  $seen = [];
  $contacts = [];
  foreach(array_reverse($chats) as $c){
    $pid = ($c['fromId']===$user['id']) ? $c['toId'] : $c['fromId'];
    if(isset($seen[$pid])) continue;
    $seen[$pid] = true;
    $peer = null;
    foreach($allUsers as $u2) if($u2['id']===$pid){ $peer=$u2; break; }
    if(!$peer) continue;
    $unread = count(array_filter($chats, fn($x)=>$x['fromId']===$pid&&$x['toId']===$user['id']&&empty($x['readAt'])));
    $contacts[] = ['user'=>$peer,'last'=>$c,'unread'=>$unread];
  }

  // Active thread
  if($chatWithId){
    foreach($allUsers as $u2) if($u2['id']===$chatWithId){ $chatWith=$u2; break; }
    $threadMsgs = array_values(array_filter($chats, fn($c)=>
      ($c['fromId']===$user['id']&&$c['toId']===$chatWithId)||
      ($c['fromId']===$chatWithId&&$c['toId']===$user['id'])
    ));
    usort($threadMsgs, fn($a,$b)=>strtotime($a['sentAt'])-strtotime($b['sentAt']));
    // Mark as read on page load
    $rdChanged = false;
    foreach($chats as &$rc){
      if($rc['fromId']===$chatWithId && $rc['toId']===$user['id'] && empty($rc['readAt'])){
        $rc['readAt'] = ts(); $rdChanged = true;
      }
    }
    unset($rc);
    if($rdChanged) sd('chats',$chats);
  }

  // Build user picker list (everyone except self)
  $pickerUsers = array_values(array_filter($allUsers, fn($u2)=>$u2['id']!==$user['id']));
?>
<style>
.chat-wrap{display:grid;grid-template-columns:280px 1fr;border:1.5px solid var(--s2);border-radius:var(--r3);overflow:hidden;background:var(--w);height:calc(100vh - 140px);min-height:500px}
.chat-sb{display:flex;flex-direction:column;border-right:1.5px solid var(--s1);background:var(--s0);overflow:hidden}
.chat-sb-hd{padding:14px 16px;border-bottom:1.5px solid var(--s1);display:flex;align-items:center;justify-content:space-between;flex-shrink:0}
.chat-sb-title{font-weight:700;font-size:13px;color:var(--n1)}
.chat-list{flex:1;overflow-y:auto}
.chat-row{display:flex;align-items:center;gap:10px;padding:11px 14px;border-bottom:1px solid var(--s1);text-decoration:none;transition:.15s;cursor:pointer}
.chat-row:hover{background:rgba(11,29,53,.04)}
.chat-row.on{background:rgba(200,150,62,.1);border-left:3px solid var(--g)}
.chat-av{width:36px;height:36px;border-radius:9px;display:flex;align-items:center;justify-content:center;font-size:11px;font-weight:700;color:#fff;flex-shrink:0}
.chat-name{font-size:13px;font-weight:600;color:var(--n1);white-space:nowrap;overflow:hidden;text-overflow:ellipsis}
.chat-prev{font-size:11px;color:var(--s4);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-top:1px}
.chat-unread-dot{background:var(--er);color:#fff;font-size:10px;font-weight:700;padding:1px 6px;border-radius:99px;margin-left:auto;flex-shrink:0}
.chat-main{display:flex;flex-direction:column;overflow:hidden;height:100%}
.chat-hd{padding:13px 18px;border-bottom:1.5px solid var(--s1);display:flex;align-items:center;gap:12px;background:var(--w);flex-shrink:0}
.chat-msgs{flex:1;overflow-y:auto;padding:18px;display:flex;flex-direction:column;gap:8px;background:var(--s0)}
.chat-bubble{max-width:72%;padding:9px 14px;border-radius:14px;font-size:13px;line-height:1.6;word-break:break-word}
.chat-bubble.me{background:var(--n1);color:#fff;border-bottom-right-radius:3px;align-self:flex-end}
.chat-bubble.them{background:var(--w);color:var(--n1);border:1.5px solid var(--s2);border-bottom-left-radius:3px;align-self:flex-start}
.chat-ts{font-size:10px;opacity:.5;margin-top:3px;display:block}
.chat-ft{padding:12px 16px;border-top:1.5px solid var(--s1);display:flex;gap:8px;align-items:flex-end;background:var(--w);flex-shrink:0}
.chat-inp{flex:1;padding:9px 14px;border:1.5px solid var(--s2);border-radius:18px;font-size:13px;resize:none;outline:none;transition:.2s;font-family:inherit;min-height:38px;max-height:96px;line-height:1.5}
.chat-inp:focus{border-color:var(--n1)}
.chat-btn-send{width:38px;height:38px;border-radius:50%;background:var(--n1);color:#fff;display:flex;align-items:center;justify-content:center;flex-shrink:0;font-size:15px;transition:.2s;border:none;cursor:pointer}
.chat-btn-send:hover{background:var(--g)}
.chat-blank{display:flex;flex-direction:column;align-items:center;justify-content:center;flex:1;gap:12px;padding:40px;text-align:center;color:var(--s4)}
/* User picker modal list */
.upick-row{display:flex;align-items:center;gap:10px;padding:10px 14px;border:1.5px solid var(--s2);border-radius:var(--r2);margin-bottom:8px;cursor:pointer;transition:.15s}
.upick-row:hover{border-color:var(--n1);background:rgba(11,29,53,.03)}
</style>

<div class="chat-wrap">
  <!-- ── Contacts sidebar ── -->
  <div class="chat-sb">
    <div class="chat-sb-hd">
      <div class="chat-sb-title">💬 Messages</div>
      <button class="btn-g btn-s" onclick="chatPickUser()" style="padding:5px 12px;font-size:11px">✏ New</button>
    </div>
    <div class="chat-list">
      <?php if(empty($contacts)): ?>
      <div style="padding:28px 16px;text-align:center;color:var(--s4);font-size:12px;line-height:1.7">
        No conversations yet.<br/>
        <button class="btn-n btn-s" onclick="chatPickUser()" style="margin-top:10px">Start chatting</button>
      </div>
      <?php else: foreach($contacts as $ct):
        $cav = strtoupper(substr($ct['user']['name'],0,1));
        if(strpos($ct['user']['name'],' ')!==false) $cav.=strtoupper(substr(explode(' ',$ct['user']['name'])[1],0,1));
        $isOn = ($chatWithId===$ct['user']['id']);
        $lastTxt = substr($ct['last']['message']??'',0,36);
        if(strlen($ct['last']['message']??'')>36) $lastTxt.='…';
        $lastT = $ct['last'] ? date('H:i',strtotime($ct['last']['sentAt'])) : '';
      ?>
      <a href="?page=dashboard&tab=chat&chatWith=<?=e($ct['user']['id'])?>" class="chat-row <?=$isOn?'on':''?>">
        <div class="chat-av" style="background:<?=e($ct['user']['color']??'#475569')?>"><?=e($cav)?></div>
        <div style="flex:1;min-width:0">
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div class="chat-name"><?=e($ct['user']['name'])?></div>
            <div style="font-size:10px;color:var(--s4);flex-shrink:0;margin-left:6px"><?=e($lastT)?></div>
          </div>
          <div style="display:flex;justify-content:space-between;align-items:center">
            <div class="chat-prev"><?=e($lastTxt)?></div>
            <?php if($ct['unread']>0):?><span class="chat-unread-dot"><?=$ct['unread']?></span><?php endif;?>
          </div>
        </div>
      </a>
      <?php endforeach; endif; ?>
    </div>
  </div>

  <!-- ── Main area ── -->
  <div class="chat-main">
    <?php if($chatWith): ?>

    <div class="chat-hd">
      <?php
        $hdAv = strtoupper(substr($chatWith['name'],0,1));
        if(strpos($chatWith['name'],' ')!==false) $hdAv.=strtoupper(substr(explode(' ',$chatWith['name'])[1],0,1));
      ?>
      <div class="chat-av" style="background:<?=e($chatWith['color']??roleColor($chatWith['role']))?>;width:40px;height:40px"><?=e($hdAv)?></div>
      <div>
        <div style="font-weight:700;font-size:14px;color:var(--n1)"><?=e($chatWith['name'])?></div>
        <div style="font-size:11px;color:var(--s4);text-transform:capitalize"><?=e($chatWith['role'])?><?=!empty($chatWith['dept'])?(' · '.e($chatWith['dept'])):''?></div>
      </div>
    </div>

    <div class="chat-msgs" id="chatMsgs">
      <?php if(empty($threadMsgs)): ?>
      <div class="chat-blank" style="flex:1">
        <div style="font-size:40px">👋</div>
        <div style="font-weight:600;color:var(--n1)">Say hello to <?=e(explode(' ',$chatWith['name'])[0])?></div>
        <div style="font-size:12px">Your messages are private and instant.</div>
      </div>
      <?php else: foreach($threadMsgs as $cm):
        $isMe = ($cm['fromId']===$user['id']);
      ?>
      <div style="display:flex;flex-direction:column;align-items:<?=$isMe?'flex-end':'flex-start'?>">
        <div class="chat-bubble <?=$isMe?'me':'them'?>">
          <?=nl2br(e($cm['message']))?>
          <span class="chat-ts"><?=date('d M H:i',strtotime($cm['sentAt']))?><?=$isMe?($cm['readAt']?' · ✓✓':' · ✓'):''?></span>
        </div>
      </div>
      <?php endforeach; endif; ?>
    </div>

    <div class="chat-ft">
      <textarea class="chat-inp" id="chatInp" rows="1" placeholder="Type a message… (Enter to send, Shift+Enter for newline)"></textarea>
      <button class="chat-btn-send" onclick="chatSend()" title="Send message">➤</button>
    </div>

    <?php else: ?>
    <div class="chat-blank">
      <div style="font-size:52px">🗨️</div>
      <div style="font-weight:700;font-size:16px;color:var(--n1)">Direct Messages</div>
      <div style="font-size:13px;max-width:260px">Private, instant messages with any teacher, parent, or admin in the portal.</div>
      <button class="btn-g" onclick="chatPickUser()">💬 Start a conversation</button>
    </div>
    <?php endif; ?>
  </div>
</div>

<script>
// ── User picker ──────────────────────────────────────────────
var CHAT_USERS = <?=json_encode(array_map(fn($u2)=>[
  'id'    => $u2['id'],
  'name'  => $u2['name'],
  'role'  => $u2['role'],
  'color' => $u2['color'] ?? '#475569',
], $pickerUsers))?>;

function chatPickUser(){
  if(!CHAT_USERS.length){ toast('No other users found','warn'); return; }
  var rows = CHAT_USERS.map(function(u){
    var av = u.name.split(' ').map(function(w){return w[0]||'';}).join('').substring(0,2).toUpperCase();
    return '<div class="upick-row" onclick="chatGoTo(\''+h(u.id)+'\')">'
      +'<div class="chat-av" style="background:'+h(u.color)+';width:36px;height:36px">'+h(av)+'</div>'
      +'<div><div style="font-size:13px;font-weight:600;color:var(--n1)">'+h(u.name)+'</div>'
      +'<div style="font-size:11px;color:var(--s4);text-transform:capitalize">'+h(u.role)+'</div></div>'
      +'</div>';
  }).join('');
  sm('New Conversation','Who do you want to message?',
    '<div style="max-height:380px;overflow-y:auto;padding:4px 0">'+rows+'</div>',
    '<button class="btn-o" onclick="closeModal()">Cancel</button>');
}

function chatGoTo(uid){
  closeModal();
  window.location.href = '?page=dashboard&tab=chat&chatWith='+encodeURIComponent(uid);
}

<?php if($chatWith): ?>
// ── Send message ─────────────────────────────────────────────
var CHAT_WITH_ID = '<?=e($chatWithId)?>';

document.getElementById('chatInp').addEventListener('keydown', function(e){
  if(e.key==='Enter' && !e.shiftKey){ e.preventDefault(); chatSend(); }
});
document.getElementById('chatInp').addEventListener('input', function(){
  this.style.height='auto';
  this.style.height = Math.min(this.scrollHeight, 96)+'px';
});

// Scroll to bottom
(function(){ var m=document.getElementById('chatMsgs'); if(m) m.scrollTop=m.scrollHeight; })();

function chatSend(){
  var inp = document.getElementById('chatInp');
  var msg = inp.value.trim();
  if(!msg) return;
  inp.value = ''; inp.style.height='auto';

  // Optimistic bubble
  var box = document.getElementById('chatMsgs');
  var blank = box.querySelector('.chat-blank');
  if(blank) blank.remove();
  var el = document.createElement('div');
  el.style.cssText = 'display:flex;flex-direction:column;align-items:flex-end';
  el.innerHTML = '<div class="chat-bubble me">'+msg.replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/\n/g,'<br>')
    +'<span class="chat-ts">Just now · ✓</span></div>';
  box.appendChild(el);
  box.scrollTop = box.scrollHeight;

  // POST to server
  fetch('?action=api_chat_send', {
    method:'POST',
    headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},
    body: JSON.stringify({toId: CHAT_WITH_ID, message: msg})
  })
  .then(function(r){ return r.json(); })
  .then(function(d){ if(!d.ok) toast(d.error||'Failed to send','err'); })
  .catch(function(){ toast('Network error — message not sent','err'); });
}

// ── Poll for new messages every 6s ───────────────────────────
var _chatPoll = setInterval(function(){
  fetch('?action=api_chat_load&withId='+CHAT_WITH_ID, {
    headers:{'X-Requested-With':'XMLHttpRequest'}
  })
  .then(function(r){ return r.json(); })
  .then(function(d){
    if(!d.ok || !d.chats) return;
    var box = document.getElementById('chatMsgs');
    var cur = box.querySelectorAll('.chat-bubble').length;
    if(d.chats.length > cur) window.location.reload();
  })
  .catch(function(){});
}, 6000);
<?php endif; ?>
</script>

<?php elseif($tab==='apologies'): ?>
<!-- Apologies Log Tab -->
<?php
  // Categorize apologies
  $aprCats = [
    'Personal emergency'   => ['icon'=>'🚨','color'=>'var(--er)','bg'=>'var(--erbg)'],
    'Illness / health issue'=> ['icon'=>'🏥','color'=>'#7C3AED','bg'=>'var(--vibg)'],
    'Work commitment'      => ['icon'=>'💼','color'=>'var(--bl)','bg'=>'var(--blbg)'],
    'Travel or away from home'=>['icon'=>'✈️','color'=>'#0891b2','bg'=>'#e0f2fe'],
    'Family circumstances' => ['icon'=>'👨‍👩‍👧','color'=>'#059669','bg'=>'#d1fae5'],
    'Scheduling conflict'  => ['icon'=>'📅','color'=>'var(--am)','bg'=>'var(--ambg)'],
    'Other'                => ['icon'=>'📌','color'=>'var(--s4)','bg'=>'var(--s1)'],
  ];
  // Count per category
  $catCounts = [];
  foreach($apologies as $a){
    $r=$a['reason']??'Other';
    $key='Other';
    foreach(array_keys($aprCats) as $cat){ if(stripos($r,$cat)!==false||$r===$cat){$key=$cat;break;} }
    $catCounts[$key]=($catCounts[$key]??0)+1;
  }
?>
<!-- Stats row -->
<div style="display:grid;grid-template-columns:repeat(auto-fill,minmax(170px,1fr));gap:14px;margin-bottom:28px">
  <?php foreach($aprCats as $cat=>$meta): $cnt=$catCounts[$cat]??0; if($cnt===0&&count($apologies)>0) continue; ?>
  <div style="background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);padding:16px 18px;display:flex;align-items:center;gap:12px;cursor:pointer;transition:.2s" onclick="filterApologies('<?=addslashes($cat)?>')" title="Filter by <?=e($cat)?>">
    <div style="width:38px;height:38px;border-radius:10px;background:<?=$meta['bg']?>;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0"><?=$meta['icon']?></div>
    <div>
      <div style="font-size:22px;font-weight:700;color:<?=$meta['color']?>;font-family:'Playfair Display',serif;line-height:1"><?=$cnt?></div>
      <div style="font-size:10px;color:var(--s4);font-weight:500;text-transform:uppercase;letter-spacing:.6px;margin-top:2px;line-height:1.3"><?=e($cat)?></div>
    </div>
  </div>
  <?php endforeach;?>
</div>

<!-- Filter bar -->
<div style="display:flex;align-items:center;gap:10px;margin-bottom:20px;flex-wrap:wrap">
  <div style="font-size:13px;font-weight:600;color:var(--s5)">Filter:</div>
  <button class="btn-o btn-s apl-filter on" data-cat="all" onclick="filterApologies('all')">All (<?=count($apologies)?>)</button>
  <?php foreach($aprCats as $cat=>$meta): $cnt=$catCounts[$cat]??0; if(!$cnt) continue;?>
  <button class="btn-o btn-s apl-filter" data-cat="<?=e($cat)?>" onclick="filterApologies('<?=addslashes($cat)?>')" style="border-color:<?=$meta['color']?>;color:<?=$meta['color']?>"><?=$meta['icon']?> <?=e($cat)?> (<?=$cnt?>)</button>
  <?php endforeach;?>
</div>

<?php if(empty($apologies)):?>
<div style="background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3)">
  <div class="empty"><div class="ei">📋</div><div class="et">No apologies submitted</div><div class="es">Apologies from parents cancelling bookings will appear here.</div></div>
</div>
<?php else:?>
<div id="aplList">
<?php foreach(array_reverse($apologies) as $a):
  $mt=null; foreach($meetings as $mm) if($mm['id']===$a['meetingId']){$mt=$mm;break;}
  $r=$a['reason']??'Other';
  $catKey='Other';
  foreach(array_keys($aprCats) as $cat){ if(stripos($r,$cat)!==false||$r===$cat){$catKey=$cat;break;} }
  $meta=$aprCats[$catKey];
  $status=$a['status']??'pending';
?>
<div class="apl-row" data-cat="<?=e($catKey)?>" style="background:var(--w);border:1.5px solid var(--s2);border-radius:var(--r3);padding:18px 22px;margin-bottom:12px;display:flex;align-items:flex-start;gap:16px;transition:.2s">
  <div style="width:42px;height:42px;border-radius:11px;background:<?=$meta['bg']?>;display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0"><?=$meta['icon']?></div>
  <div style="flex:1;min-width:0">
    <div style="display:flex;align-items:center;gap:8px;flex-wrap:wrap;margin-bottom:4px">
      <span style="font-weight:700;font-size:14px;color:var(--n1)"><?=e($a['userName']??'Unknown')?></span>
      <span style="font-size:11px;font-weight:600;padding:2px 9px;border-radius:99px;background:<?=$meta['bg']?>;color:<?=$meta['color']?>"><?=$meta['icon']?> <?=e($catKey)?></span>
      <span style="font-size:11px;font-weight:600;padding:2px 9px;border-radius:99px;background:<?=$status==='reviewed'?'var(--okbg)':'var(--ambg)'?>;color:<?=$status==='reviewed'?'var(--ok)':'var(--am)'?>"><?=$status==='reviewed'?'✓ Reviewed':'⏳ Pending'?></span>
      <span style="font-size:11px;color:var(--s4);margin-left:auto"><?=e(date('d M Y, H:i',strtotime($a['createdAt'])))?></span>
    </div>
    <div style="font-size:13px;color:var(--s5);margin-bottom:4px">Cancelled booking for: <em style="color:var(--n1)"><?=e($mt?$mt['title']:'a meeting')?></em></div>
    <div style="font-size:12px;color:var(--s4)">Reason: <?=e($a['reason']??'Not specified')?></div>
  </div>
  <?php if(in_array($user['role'],['teacher','principal','admin'])&&($a['status']??'pending')==='pending'):?>
  <button class="btn-o btn-s" onclick="markReviewed('<?=e($a['id']??'')?>')" style="flex-shrink:0;border-color:var(--ok);color:var(--ok)">✓ Mark Reviewed</button>
  <?php endif;?>
</div>
<?php endforeach;?>
</div>
<?php endif;?>

<script>
function filterApologies(cat){
  document.querySelectorAll('.apl-filter').forEach(b=>{b.classList.toggle('on',b.dataset.cat===cat)});
  document.querySelectorAll('.apl-row').forEach(r=>{
    r.style.display=(cat==='all'||r.dataset.cat===cat)?'flex':'none';
  });
}
function markReviewed(id){
  if(!id){toast('Invalid apology ID','err');return;}
  post('api_mark_apology_reviewed',{id:id},function(d){
    toast('Apology marked as reviewed ✓');
    reload();
  });
}
</script>

<?php elseif($tab==='settings'&&in_array($user['role'],['admin','principal'])): ?>
<!-- Settings -->
<div class="card">
  <div class="ch"><div><div class="cht">System Settings</div><div class="chs">Configure school branding and contact details</div></div><button class="btn-g" onclick="saveSettings()">💾 Save Changes</button></div>
  <div class="cb">
    <div style="background:var(--blbg);border:1.5px solid rgba(26,86,219,.2);border-radius:var(--r2);padding:14px 18px;margin-bottom:22px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
    <div><div style="font-size:13px;font-weight:600;color:var(--bl)">📧 Email Configuration</div><div style="font-size:12px;color:var(--s4);margin-top:2px">SMTP: <?=e(env('SMTP_USER','noreply@sovereignai.co.ke'))?> · Host: <?=e(env('SMTP_HOST','mail.sovereignai.co.ke'))?>:<?=e(env('SMTP_PORT','587'))?></div></div>
    <div style="display:flex;gap:8px">
    <button class="btn-n btn-s" onclick="testEmail(this)">Send Test Email</button>
    <button class="btn-o btn-s" onclick="smtpDebug(this)" style="border-color:var(--am);color:var(--am)">🔍 SMTP Debug</button>
    </div>
    </div>
    <div id="smtp_trace" style="display:none;background:#0B1D35;color:#a0ffb0;font-family:monospace;font-size:11px;padding:14px;border-radius:var(--r2);margin-bottom:16px;white-space:pre-wrap;line-height:1.7"></div>
    <div style="background:var(--vibg);border:1.5px solid rgba(109,40,217,.2);border-radius:var(--r2);padding:14px 18px;margin-bottom:16px;display:flex;align-items:center;justify-content:space-between;gap:12px;flex-wrap:wrap">
    <div><div style="font-size:13px;font-weight:600;color:var(--vi)">⚡ AI Assistant · Groq</div><div style="font-size:12px;color:var(--s4);margin-top:2px">Model: llama-3.3-70b-versatile · Free tier · ~500 tokens/sec</div></div>
    <button class="btn-o btn-s" style="border-color:var(--vi);color:var(--vi)" onclick="testAI(this)">Test AI</button>
    </div>
    <div class="set-t">School Information</div>
    <div class="set-grid">
      <?php foreach([['schoolName','School Name'],['schoolMotto','Motto / Tagline'],['logo','Logo Emoji'],['address','Physical Address'],['phone','Phone Number'],['email','Email Address'],['website','Website URL']] as [$k,$l]):?>
      <div class="fg"><label class="fl"><?=e($l)?></label><input class="fi" id="s_<?=$k?>" value="<?=e($settings[$k]??'')?>"/></div>
      <?php endforeach;?>
    </div>
    <div class="fg" style="margin-top:22px">
      <label class="fl">Custom Class Streams</label>
      <p style="font-size:11px;color:var(--s4);margin-bottom:8px">One per line. E.g. <em>Grade 2 B</em>, <em>Grade 4 North</em>, <em>Grade 6 F</em>. These combine with the default Grade 1–10 list shown to parents and teachers during registration.</p>
      <textarea class="fi fta" id="s_customStreams" rows="6" placeholder="Grade 1 A&#10;Grade 1 B&#10;Grade 2 North&#10;Grade 2 South"><?=e(implode("
",$settings['customStreams']??[]))?></textarea>
    </div>
    <div style="margin-top:10px;padding:14px 18px;background:var(--s0);border:1.5px solid var(--s2);border-radius:var(--r2)">
      <div style="font-size:12px;font-weight:600;color:var(--n1);margin-bottom:8px">📋 All Active Streams (<?=count($allClassList)?>)</div>
      <div style="display:flex;flex-wrap:wrap;gap:6px">
        <?php foreach($allClassList as $cls):?>
        <span style="padding:3px 10px;background:var(--blbg);color:var(--bl);border-radius:99px;font-size:11px;font-weight:600"><?=e($cls)?></span>
        <?php endforeach;?>
      </div>
    </div>
    <div style="margin-top:28px">
      <div class="set-t">Apologies Log</div>
      <?php if(empty($apologies)):?><p style="color:var(--s4);font-size:13px">No apologies submitted yet.</p>
      <?php else:?>
      <?php foreach(array_reverse($apologies) as $a):$mt=null;foreach($meetings as $mm)if($mm['id']===$a['meetingId']){$mt=$mm;break;}?>
      <div style="padding:13px 0;border-bottom:1.5px solid var(--s1);font-size:13px"><strong><?=e($a['userName'])?></strong> cancelled booking for <em><?=e($mt?$mt['title']:'a meeting')?></em><br/><span style="color:var(--s4)">Reason: <?=e($a['reason'])?> · <?=e(date('d M Y',strtotime($a['createdAt'])))?></span></div>
      <?php endforeach;?>
      <?php endif;?>
    </div>
  </div>
</div>
<?php endif;?>

</div></div></div>

<!-- MODALS -->
<div id="mOv" class="mov" style="display:none" onclick="if(event.target===this)closeModal()">
  <div class="mod" id="mWrap">
    <div class="mh"><div><div class="mht" id="mT">-</div><div class="mhs" id="mS"></div></div><button class="mx" onclick="closeModal()">✕</button></div>
    <div class="mb" id="mB"></div>
    <div class="mf" id="mF"></div>
  </div>
</div>
<div id="notifEl" class="notif" style="display:none"><span class="nf-ico" id="nIco">✅</span><span class="nf-msg" id="nMsg"></span></div>

<script>
var D;try{D={user:<?=jd($user)?>,meetings:<?=jd($meetings)?>,bookings:<?=jd($bookings)?>,settings:<?=jd($settings)?>,allClasses:<?=json_encode($allClassList)??'[]'?>,chats:<?=jd($chats)?>};}catch(e){console.error('Portal data init error:',e);D={user:<?=jd(['id'=>$user['id']??'','name'=>$user['name']??'','role'=>$user['role']??'','email'=>$user['email']??'','color'=>$user['color']??'#333','class'=>$user['class']??'','streams'=>$user['streams']??[]])?>,meetings:[],bookings:[],settings:{schoolName:'School Portal'},allClasses:[],chats:[]};}
var nT;
function toast(msg,t){var n=document.getElementById('notifEl'),tp={err:{c:'err',i:'⚠️'},warn:{c:'warn',i:'⚠️'},success:{c:'',i:'✅'}}[t]||{c:'',i:'✅'};n.className='notif '+tp.c;document.getElementById('nIco').textContent=tp.i;document.getElementById('nMsg').textContent=msg;n.style.display='flex';clearTimeout(nT);nT=setTimeout(()=>n.style.display='none',4200);}
function doLogout(){fetch('?action=logout',{method:'POST'}).then(()=>window.location.href='?page=home');}
function openModal(tp,data){var ov=document.getElementById('mOv');if(!ov){console.error('Modal overlay not found');return;}ov.style.display='flex';document.getElementById('mWrap').className='mod';switch(tp){case'create':bCreate();break;case'edit':bEdit(data);break;case'book':bBook(data);break;case'cancel':bCancel(data);break;case'view':bView(data);break;case'compose':bCompose();break;case'contact':bContact(data);break;}}
function closeModal(){document.getElementById('mOv').style.display='none';}
function sm(t,s,b,f,w){document.getElementById('mT').textContent=t;document.getElementById('mS').textContent=s||'';document.getElementById('mB').innerHTML=b;document.getElementById('mF').innerHTML=f;if(w)document.getElementById('mWrap').classList.add('wide');}
function h(s){if(s==null)return'';return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;').replace(/'/g,'&#39;');}
function v(id){var el=document.getElementById(id);return el?el.value.trim():'';}
function reload(){setTimeout(()=>location.reload(),860);}
function post(a,d,ok){fetch('?action='+a,{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:JSON.stringify(d)}).then(r=>r.json()).then(d=>{if(d.ok){ok&&ok(d);}else toast(d.error||'Something went wrong','err');}).catch(()=>toast('Network error','err'));}

function bCreate(){
  var td=new Date().toISOString().split('T')[0];
  var isStaff=['teacher','principal','admin'].includes(D.user.role);
  var roleClass=D.user.class||'';

  sm('Create New Meeting','Schedule a parent-teacher meeting',
  `<div class="form2">
    <div class="fg"><label class="fl">Meeting Title *</label><input class="fi" id="ct" placeholder="e.g. Term 2 Parent-Teacher Day"/></div>
    <div class="fg"><label class="fl">Class / Stream *</label><input class="fi" id="cc" value="${h(roleClass)}" list="class_list_dl"/>
      <datalist id="class_list_dl">${D.allClasses.map(c=>`<option value="${h(c)}">`).join('')}</datalist></div>
    <div class="fg"><label class="fl">Date *</label><input class="fi" type="date" id="cd" min="${td}"/></div>
    <div class="fg"><label class="fl">Icon</label><input class="fi" id="ci" value="📅" style="font-size:18px"/></div>
  </div>

  <div class="fg"><label class="fl">Meeting Type</label>
    <div style="display:flex;gap:8px">
      <button type="button" id="mt_physical" class="btn-o" onclick="setMtType('physical')" style="flex:1;justify-content:center;border-color:var(--ok);color:var(--ok)">🏫 Physical</button>
      <button type="button" id="mt_online"   class="btn-o" onclick="setMtType('online')"   style="flex:1;justify-content:center">💻 Online</button>
      <button type="button" id="mt_hybrid"   class="btn-o" onclick="setMtType('hybrid')"   style="flex:1;justify-content:center">🔀 Hybrid</button>
    </div>
    <input type="hidden" id="ct_meetingType" value="physical"/>
  </div>

  <div class="form2">
    <div class="fg"><label class="fl">Physical Location</label><input class="fi" id="cl" placeholder="e.g. Room 12 / Main Hall"/></div>
    <div class="fg" id="linkrow"><label class="fl">Online Meeting Link</label><input class="fi" id="ck" placeholder="https://meet.google.com/…"/></div>
  </div>

  <div class="fg"><label class="fl">Description</label><textarea class="fta" id="cde" placeholder="Briefly describe the purpose…"></textarea></div>
  <div class="fg"><label class="fl">Time Slots (comma-separated)</label><input class="fi" id="cs" value="09:00 AM, 09:30 AM, 10:00 AM, 10:30 AM, 11:00 AM, 11:30 AM, 02:00 PM, 02:30 PM, 03:00 PM"/></div>

  <div class="fg" style="border-top:1.5px solid var(--s1);padding-top:18px;margin-top:6px">
    <label class="fl" style="display:flex;align-items:center;gap:8px;cursor:pointer">
      <input type="checkbox" id="ct_individual" onchange="toggleIndividual(this.checked)" style="accent-color:var(--n1);width:15px;height:15px"/>
      Schedule for a specific parent only (Individual Meeting)
    </label>
  </div>
  <div id="individual_panel" style="display:none">
    <div class="fg">
      <label class="fl">Select Parent *</label>
      <div style="display:flex;gap:8px">
        <select class="fi" id="ct_targetParent" style="flex:1"><option value="">— Loading parents… —</option></select>
        <button type="button" class="btn-o btn-s" onclick="loadParentsDropdown()">↻ Refresh</button>
      </div>
      <p style="font-size:11px;color:var(--s4);margin-top:5px">Only this parent will see the meeting in their portal.</p>
    </div>
  </div>`,
  `<button class="btn-o" onclick="closeModal()">Cancel</button><button class="btn-g" onclick="submitCreate()">✓ Create Meeting</button>`,true);
}
function setMtType(t){
  ['physical','online','hybrid'].forEach(x=>{
    var btn=document.getElementById('mt_'+x);
    if(!btn) return;
    btn.style.borderColor=''; btn.style.color='';
    var cols={physical:'var(--ok)',online:'var(--bl)',hybrid:'var(--vi)'};
    if(x===t){btn.style.borderColor=cols[t];btn.style.color=cols[t];}
  });
  var el=document.getElementById('ct_meetingType');
  if(el) el.value=t;
  // Show/hide link row
  var lr=document.getElementById('linkrow');
  if(lr) lr.style.display=(t==='physical')?'none':'block';
}
function toggleIndividual(on){
  var p=document.getElementById('individual_panel');
  if(p) p.style.display=on?'block':'none';
  if(on) loadParentsDropdown();
}
function loadParentsDropdown(){
  var sel=document.getElementById('ct_targetParent');
  if(!sel) return;
  sel.innerHTML='<option value="">— Loading… —</option>';
  fetch('?action=api_get_parents').then(r=>r.json()).then(d=>{
    if(d.ok&&d.parents){
      sel.innerHTML='<option value="">— Select parent —</option>'+
        d.parents.map(p=>`<option value="${h(p.id)}">${h(p.name)} (${h(p.class||'No class')}) — ${h(p.studentName||'')}</option>`).join('');
    } else {
      sel.innerHTML='<option value="">— No parents found —</option>';
    }
  }).catch(()=>{sel.innerHTML='<option value="">— Error loading —</option>';});
}
function submitCreate(){
  var t=v('ct'),d=v('cd');
  if(!t||!d){toast('Title and date required','err');return;}
  var isInd=document.getElementById('ct_individual')?.checked;
  var targetParentId=isInd?(document.getElementById('ct_targetParent')?.value||''):'';
  if(isInd&&!targetParentId){toast('Please select a parent for the individual meeting','err');return;}
  var sl=v('cs').split(',').map(s=>s.trim()).filter(Boolean);
  var mt=document.getElementById('ct_meetingType')?.value||'physical';
  post('api_create',{title:t,date:d,class:v('cc'),description:v('cde'),location:v('cl'),meetingLink:v('ck'),icon:v('ci')||'📅',timeSlots:sl,meetingType:mt,targetParentId},()=>{closeModal();toast('Meeting created! 🎉');reload();});
}

/* Edit */
function openEditModal(m){openModal('edit',m);}
function bEdit(m){
  var mt=m.meetingType||'physical';
  var mtCols={physical:'var(--ok)',online:'var(--bl)',hybrid:'var(--vi)'};
  var mtBtns=['physical','online','hybrid'].map(x=>`<button type="button" id="emt_${x}" class="btn-o" onclick="setEditMtType('${x}')" style="flex:1;justify-content:center;${x===mt?'border-color:'+mtCols[x]+';color:'+mtCols[x]+';':''}">${{physical:'🏫 Physical',online:'💻 Online',hybrid:'🔀 Hybrid'}[x]}</button>`).join('');
  sm('Edit Meeting','Update meeting details',
  `<div class="form2">
    <div class="fg"><label class="fl">Title *</label><input class="fi" id="et" value="${h(m.title||'')}"/></div>
    <div class="fg"><label class="fl">Class</label><input class="fi" id="ec" value="${h(m.class||'')}" list="edit_class_dl"/>
      <datalist id="edit_class_dl">${D.allClasses.map(c=>`<option value="${h(c)}">`).join('')}</datalist></div>
    <div class="fg"><label class="fl">Date *</label><input class="fi" type="date" id="ed" value="${h((m.date||'').split('T')[0])}"/></div>
    <div class="fg"><label class="fl">Icon</label><input class="fi" id="ei" value="${h(m.icon||'📅')}" style="font-size:18px"/></div>
  </div>
  <div class="fg"><label class="fl">Meeting Type</label>
    <div style="display:flex;gap:8px">${mtBtns}</div>
    <input type="hidden" id="et_meetingType" value="${h(mt)}"/>
  </div>
  <div class="form2">
    <div class="fg"><label class="fl">Physical Location</label><input class="fi" id="el" value="${h(m.location||'')}"/></div>
    <div class="fg" id="edit_linkrow" style="${mt==='physical'?'display:none':''}"><label class="fl">Online Meeting Link</label><input class="fi" id="ek" value="${h(m.meetingLink||'')}"/></div>
  </div>
  <div class="fg"><label class="fl">Description</label><textarea class="fta" id="ede">${h(m.description||'')}</textarea></div>
  <div class="fg"><label class="fl">Time Slots (comma-separated)</label><input class="fi" id="es" value="${h((m.timeSlots||[]).join(', '))}"/></div>`,
  `<button class="btn-o" onclick="closeModal()">Cancel</button><button class="btn-g" onclick="submitEdit('${h(m.id)}')">💾 Save Changes</button>`,true);
}
function setEditMtType(t){
  var cols={physical:'var(--ok)',online:'var(--bl)',hybrid:'var(--vi)'};
  ['physical','online','hybrid'].forEach(x=>{
    var btn=document.getElementById('emt_'+x);
    if(!btn) return;
    btn.style.borderColor=''; btn.style.color='';
    if(x===t){btn.style.borderColor=cols[t];btn.style.color=cols[t];}
  });
  var el=document.getElementById('et_meetingType'); if(el) el.value=t;
  var lr=document.getElementById('edit_linkrow'); if(lr) lr.style.display=(t==='physical')?'none':'block';
}
function submitEdit(id){var sl=v('es').split(',').map(s=>s.trim()).filter(Boolean);var mt=document.getElementById('et_meetingType')?.value||'physical';post('api_edit',{id,title:v('et'),date:v('ed'),class:v('ec'),description:v('ede'),location:v('el'),meetingLink:v('ek'),icon:v('ei')||'📅',timeSlots:sl,meetingType:mt},()=>{closeModal();toast('Meeting updated!');reload();});}

/* Book */
function openBookModal(m,bks){
  // Prevent double-booking in UI — check if user already booked this meeting
  var myUid = D.user.id;
  var alreadyBooked = D.bookings.find(function(b){ return b.meetingId === m.id && b.userId === myUid; });
  if(alreadyBooked){
    toast('You have already booked slot: ' + alreadyBooked.slot + ' for this meeting.','warn');
    return;
  }
  openModal('book',{m,bks});
}
function bBook({m,bks}){var tk=(bks||[]).map(b=>b.slot),ds=new Date(m.date).toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'}),sh=(m.timeSlots||[]).map(s=>{var t=tk.includes(s);return`<button class="slotbtn"${t?' disabled':''}onclick="bookSlot('${h(m.id)}','${h(s)}')">${h(s)}${t?'<div class="slot-tk">TAKEN</div>':''}</button>`;}).join('');sm('Book a Time Slot',m.title,`<div style="background:var(--g4);border:1px solid rgba(200,150,62,.28);border-radius:var(--r2);padding:14px 16px;margin-bottom:18px;font-size:13px"><strong style="color:var(--n1);display:block;margin-bottom:3px">📅 ${h(m.title)}</strong><span style="color:var(--s4)">${h(ds)}</span></div><p style="font-size:13px;color:var(--s4);margin-bottom:14px">Select an available 30-minute time slot:</p><div class="slotgrid">${sh||'<p style="color:var(--s4);font-size:13px">No slots available.</p>'}</div>`,`<button class="btn-o" onclick="closeModal()">Close</button>`);}
function bookSlot(mid,slot){
  // Check if user already has a booking for this meeting
  var existing = D.bookings.find(function(b){ return b.meetingId === mid && b.userId === D.user.id; });
  if(existing){toast('You have already booked a slot for this meeting.','warn');closeModal();return;}
  // Disable all slot buttons to prevent double-click
  document.querySelectorAll('.slotbtn').forEach(function(btn){ btn.disabled = true; });
  post('api_book',{meetingId:mid,slot},function(){closeModal();toast('Slot booked! A confirmation email has been sent. 🎉');reload();});
}

/* Cancel */
function cancelModal(b,m){openModal('cancel',{b,m});}
function bCancel({b,m}){var reasons=['Personal emergency','Illness / health issue','Work commitment','Travel or away from home','Family circumstances','Scheduling conflict','Other'];var opts=reasons.map(r=>`<option value="${h(r)}">${h(r)}</option>`).join('');sm('Send Apology','Cancel your booking and notify the school',`<div style="background:var(--erbg);border:1px solid rgba(185,28,28,.14);border-radius:var(--r2);padding:14px 16px;margin-bottom:18px"><div style="font-weight:600;color:var(--er);font-size:13px;margin-bottom:4px">⚠ Cancelling Booking</div><div style="font-size:13px;color:var(--s5)">${h(m.title||'')} — Slot: ${h(b.slot||'')}</div></div><div class="fg"><label class="fl">Reason for Cancellation</label><select class="fsel" id="can_reason" onchange="document.getElementById('can_ow').style.display=this.value==='Other'?'block':'none'"><option value="">— Select a reason —</option>${opts}</select></div><div id="can_ow" style="display:none" class="fg"><label class="fl">Please specify</label><textarea class="fta" id="can_other" placeholder="Describe your reason…"></textarea></div>`,`<button class="btn-o" onclick="closeModal()">Go Back</button><button class="btn-n" onclick="submitCancel('${h(b.id)}')">📤 Submit Apology</button>`);}
function submitCancel(bid){
  var reason=v('can_reason');
  if(!reason){toast('Please select a reason','err');return;}
  if(reason==='Other'){reason=v('can_other')||'Other'; if(reason.length<3){toast('Please describe your reason','err');return;}}
  var btn=document.querySelector('#mF .btn-n');
  if(btn){btn.disabled=true;btn.textContent='Submitting…';}
  post('api_cancel',{bookingId:bid,reason},function(d){
    closeModal();
    toast('Apology submitted. The school has been notified by email. 📧');
    reload();
  });
}

/* View */
function viewMeeting(m,mBks){openModal('view',{m,mBks});}
function bView({m,mBks}){
  var ds=new Date(m.date).toLocaleDateString('en-GB',{weekday:'long',day:'numeric',month:'long',year:'numeric'}),
      isAct=new Date(m.date)>=new Date(),
      mt=m.meetingType||'physical',
      mtMap={physical:{icon:'🏫',label:'Physical Meeting',col:'var(--ok)',bg:'var(--okbg)'},online:{icon:'💻',label:'Online Meeting',col:'var(--bl)',bg:'var(--blbg)'},hybrid:{icon:'🔀',label:'Hybrid (Physical + Online)',col:'var(--vi)',bg:'var(--vibg)'}},
      mtInfo=mtMap[mt]||mtMap.physical,
      bh=(mBks||[]).length===0?'<p style="color:var(--s4);font-size:13px;font-weight:300">No bookings yet.</p>':(mBks||[]).map(b=>`<div style="display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1.5px solid var(--s1);font-size:13px;gap:8px;flex-wrap:wrap"><div><strong>${h(b.userName)}</strong>${b.studentName?` <span style="color:var(--s4);font-weight:300">(${h(b.studentName)})</span>`:''}<br/><span style="color:var(--s4);font-size:11px">${h(b.userEmail)}</span></div><span class="tag tg1">${h(b.slot)}</span></div>`).join('');
  var mtBadge=`<span class="tag" style="background:${mtInfo.bg};color:${mtInfo.col}">${mtInfo.icon} ${mtInfo.label}</span>`;
  var indBadge=m.targetParentId?`<span class="tag tg4">👤 Individual Meeting</span>`:'';
  sm('Meeting Details',m.title,
    `<div style="display:flex;gap:6px;flex-wrap:wrap;margin-bottom:14px">${m.class?`<span class="tag tg0">${h(m.class)}</span>`:''}<span class="tag ${isAct?'tg1':''}" ${!isAct?'style="background:var(--s1);color:var(--s4)"':''}>${isAct?'🟢 Active':'⬜ Past'}</span>${mtBadge}${indBadge}</div>
    <h3 style="font-family:'Playfair Display',serif;font-size:22px;font-weight:700;color:var(--n1);margin-bottom:8px">${h(m.title)}</h3>
    ${m.description?`<p style="font-size:14px;color:var(--s4);line-height:1.7;margin-bottom:18px;font-weight:300">${h(m.description)}</p>`:''}
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:20px">
      <div style="background:var(--s0);border:1.5px solid var(--s2);border-radius:var(--r2);padding:13px"><div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--s4);font-weight:600;margin-bottom:4px">Date</div><div style="font-size:13px;font-weight:500">${h(ds)}</div></div>
      <div style="background:${mtInfo.bg};border:1.5px solid ${mtInfo.col}44;border-radius:var(--r2);padding:13px"><div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:${mtInfo.col};font-weight:600;margin-bottom:4px">Format</div><div style="font-size:13px;font-weight:600;color:${mtInfo.col}">${mtInfo.icon} ${mtInfo.label}</div></div>
      ${m.location?`<div style="background:var(--s0);border:1.5px solid var(--s2);border-radius:var(--r2);padding:13px"><div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--s4);font-weight:600;margin-bottom:4px">Location</div><div style="font-size:13px;font-weight:500">${h(m.location)}</div></div>`:''}
      ${m.meetingLink?`<div style="background:var(--blbg);border:1.5px solid rgba(26,86,219,.2);border-radius:var(--r2);padding:13px"><div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--bl);font-weight:600;margin-bottom:4px">Online Link</div><a href="${h(m.meetingLink)}" target="_blank" style="font-size:13px;font-weight:500;color:var(--bl)">Join Meeting →</a></div>`:''}
      <div style="background:var(--s0);border:1.5px solid var(--s2);border-radius:var(--r2);padding:13px"><div style="font-size:10px;letter-spacing:1px;text-transform:uppercase;color:var(--s4);font-weight:600;margin-bottom:4px">Time Slots</div><div style="font-size:13px;font-weight:500">${(m.timeSlots||[]).length} available</div></div>
    </div>
    <div style="font-size:13px;font-weight:600;color:var(--n1);margin-bottom:12px">Bookings (${(mBks||[]).length})</div>${bh}`,
    `<button class="btn-o" onclick="closeModal()">Close</button>`,true);
}

/* Contact / Compose */
function openContactModal(toEmail,toPhone,m,b){openModal('contact',{toEmail,toPhone,m:m||{},b:b||{}});}
function bContact({toEmail,toPhone,m,b}){
  var ctx=`School:${D.settings.schoolName}. Staff:${D.user.name}. Parent:${b.userName||''}. Student:${b.studentName||''}. Meeting:${m.title||''}.`;
  var toNameVal=b.userName||'';
  var waBtn=toPhone?`<button class="btn-o btn-s" onclick="openWhatsAppWith('${h(toPhone)}','${h(toNameVal)}')" style="border-color:#25D366;color:#25D366"><svg width='13' height='13' viewBox='0 0 24 24' fill='#25D366' style='vertical-align:middle;margin-right:4px'><path d='M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z'/></svg>WhatsApp</button>`:'';
  sm('Contact Parent / Guardian',toEmail||'New message',
    aip(ctx)+
    `<div class="fg"><label class="fl">To (Email) *</label><input class="fi" id="msg_to" value="${h(toEmail)}" placeholder="parent@email.com"/></div>`+
    `<div class="fg"><label class="fl">Recipient Name</label><input class="fi" id="msg_toname" value="${h(toNameVal)}" placeholder="Parent name"/></div>`+
    `<div class="fg"><label class="fl">Subject *</label><input class="fi" id="msg_subj" placeholder="Regarding your upcoming meeting…"/></div>`+
    `<div class="fg"><label class="fl">Message *</label><textarea class="fta" id="msg_body" rows="5" style="min-height:110px"></textarea></div>`+
    `<div id="email_status" style="display:none;font-size:12px;margin-top:8px"></div>`,
    `<button class="btn-o" onclick="closeModal()">Cancel</button>${waBtn}<button class="btn-n" id="sendBtn" onclick="sendMsg('${h(toPhone||'')}','${h(m.id||'')}')">📧 Send Email</button>`,
    false);
}
function openWhatsAppWith(phone,name){
  var body=v('msg_body');
  var prefill=body?encodeURIComponent(body):'';
  var clean=phone.replace(/\D/g,'');
  if(!clean){toast('No phone number on file for this parent','warn');return;}
  window.open('https://wa.me/'+clean+(prefill?'?text='+prefill:''),'_blank');
}
function bCompose(){
  var isParent=D.user.role==='parent';
  var schoolEmail = D.settings.email || 'admin@school.ac.ke';
  var toField=isParent
    ? `<div class="fg"><label class="fl">Send To</label><input class="fi" id="msg_to" value="${h(schoolEmail)}" readonly style="background:var(--s0);cursor:default"/><p style="font-size:11px;color:var(--s4);margin-top:4px">Messages are sent to school administration (${h(schoolEmail)})</p></div>`
    : `<div class="fg"><label class="fl">Recipient Email *</label><input class="fi" id="msg_to" placeholder="email@example.com"/></div>`;
  var toNameField=isParent?'':`<div class="fg"><label class="fl">Recipient Name</label><input class="fi" id="msg_toname" placeholder="Recipient name"/></div>`;
  var ctx=`School:${D.settings.schoolName}. User:${D.user.name} (${D.user.role}).`;
  var subjectPlaceholder = isParent ? "e.g. Question about my child's meeting" : 'Subject\u2026';
  var bodyPlaceholder = isParent ? 'Type your message to the school here…' : 'Type your message here…';
  sm('Compose Message','Send an email via the portal',
    (isParent ? `<div style="background:var(--blbg);border:1.5px solid rgba(26,86,219,.15);border-radius:var(--r2);padding:12px 16px;margin-bottom:16px;font-size:13px;color:var(--bl)">📧 Your message will be sent directly to school administration via email. They will reply to your email address: <strong>${h(D.user.email)}</strong></div>` : '') +
    aip(ctx)+toField+toNameField+
    `<div class="fg"><label class="fl">Subject *</label><input class="fi" id="msg_subj" placeholder="${h(subjectPlaceholder)}"/></div>`+
    `<div class="fg"><label class="fl">Message *</label><textarea class="fta" id="msg_body" rows="5" style="min-height:120px" placeholder="${h(bodyPlaceholder)}"></textarea></div>`+
    `<div id="email_status" style="display:none;font-size:12px;margin-top:8px;padding:8px 12px;border-radius:var(--r2)"></div>`,
    `<button class="btn-o" onclick="closeModal()">Cancel</button><button class="btn-n" id="sendBtn" onclick="sendMsg('','')">📧 Send Email</button>`);
}
function sendMsg(phone,meetingId){
  var to=v('msg_to'),toName=v('msg_toname')||'',subj=v('msg_subj'),msg=v('msg_body');
  if(!to||!subj||!msg){toast('Please fill all required fields','err');return;}
  if(!to.includes('@')){toast('Please enter a valid email address','err');return;}
  var btn=document.getElementById('sendBtn');
  if(btn){btn.disabled=true;btn.textContent='Sending…';}
  var statusEl=document.getElementById('email_status');
  if(statusEl){statusEl.style.display='block';statusEl.style.color='var(--s4)';statusEl.style.background='var(--s0)';statusEl.style.padding='10px 12px';statusEl.style.borderRadius='var(--r2)';statusEl.textContent='Sending email, please wait…';}
  post('api_msg',{to,toName,toPhone:phone,subject:subj,message:msg,meetingId:meetingId||''},function(d){
    if(d.emailSent){
      closeModal();
      toast('✉️ Email delivered to '+to);
    } else {
      // Show error in-modal so user sees the full reason
      if(btn){btn.disabled=false;btn.textContent='📧 Retry Send';}
      if(statusEl){
        statusEl.style.background='var(--erbg)';
        statusEl.style.color='var(--er)';
        statusEl.style.border='1px solid rgba(185,28,28,.2)';
        statusEl.style.padding='12px 14px';
        statusEl.style.borderRadius='var(--r2)';
        statusEl.style.fontSize='12px';
        statusEl.style.lineHeight='1.6';
        var errMsg=d.emailError||'Unknown SMTP error';
        statusEl.innerHTML='<strong>⚠ Email failed — message was saved but not delivered</strong><br/><span style="opacity:.8">'+h(errMsg)+'</span>'
          +'<br/><span style="opacity:.65;font-size:11px">Tip: Use the SMTP Debug button in Settings to diagnose. You can also send via WhatsApp instead.</span>';
      }
      toast('Message saved but email failed — see details in form','warn');
      reload();
    }
  });
}
/* Notify all parents about a meeting */
function notifyAllParents(mid,title){
  // Count bookings for this meeting
  var bks=(D.bookings||[]).filter(b=>b.meetingId===mid);
  var countInfo=bks.length>0
    ? `<div style="font-size:12px;margin-top:8px;color:var(--ok);font-weight:600">👥 ${bks.length} parent${bks.length!==1?'s':''} will be notified</div>`
    : `<div style="font-size:12px;margin-top:8px;color:var(--am);font-weight:600">⚠ No bookings yet — no one to notify</div>`;
  sm('Notify All Booked Parents','Send email notification to everyone booked',
    `<div style="background:var(--blbg);border:1px solid rgba(26,86,219,.2);border-radius:var(--r2);padding:14px 16px;margin-bottom:16px;font-size:13px;color:var(--bl)">📧 An email will be sent to all parents booked for <strong>${h(title)}</strong>${countInfo}</div>`+
    `<div class="fg"><label class="fl">Custom Message (optional)</label><textarea class="fta" id="notify_msg" rows="4" placeholder="Add a custom note to the notification email…"></textarea></div>`,
    `<button class="btn-o" onclick="closeModal()">Cancel</button><button class="btn-g" id="notifyBtn" onclick="submitNotify('${h(mid)}')" ${bks.length===0?'disabled style="opacity:.5"':''}>📨 Send Notifications</button>`);
}
function submitNotify(mid){
  var btn=document.getElementById('notifyBtn');
  if(btn){btn.disabled=true;btn.textContent='Sending…';}
  post('api_notify_meeting',{meetingId:mid,message:v('notify_msg')},function(d){
    closeModal();
    if(d.sent===0) toast(d.message||'No bookings found to notify','warn');
    else toast('📨 Sent '+d.sent+' notification email'+(d.sent!==1?'s':'')+(d.failed?' ('+d.failed+' failed)':'')+' ✓');
    reload();
  });
}
/* WhatsApp communication */
function openWhatsApp(){
  sm('WhatsApp Communication','Send a message via WhatsApp',
    `<div style="background:#f0fdf4;border:1.5px solid #86efac;border-radius:var(--r2);padding:14px 16px;margin-bottom:18px;display:flex;align-items:center;gap:12px">
      <svg width="28" height="28" viewBox="0 0 24 24" fill="#25D366"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
      <div><div style="font-weight:700;font-size:14px;color:#15803d">Send via WhatsApp</div><div style="font-size:12px;color:#166534;margin-top:2px">Opens WhatsApp with your message pre-filled</div></div>
    </div>
    <div class="fg"><label class="fl">Recipient Phone Number *</label><input class="fi" id="wa_phone" placeholder="e.g. 254712345678 (include country code, no +)"/></div>
    <div class="fg"><label class="fl">Message *</label><textarea class="fta" id="wa_msg" rows="5" placeholder="Type your message here…"></textarea></div>
    <div style="background:var(--s0);border-radius:var(--r2);padding:10px 14px;font-size:11px;color:var(--s4);margin-top:4px">💡 Tip: Use the AI assistant below to draft a professional message first, then send via WhatsApp.</div>
    `+aip('WhatsApp school communication'),
    `<button class="btn-o" onclick="closeModal()">Cancel</button><button class="btn-g" onclick="submitWhatsApp()" style="background:linear-gradient(135deg,#25D366,#128C7E);color:#fff">
      <svg width="14" height="14" viewBox="0 0 24 24" fill="white"><path d="M17.472 14.382c-.297-.149-1.758-.867-2.03-.967-.273-.099-.471-.148-.67.15-.197.297-.767.966-.94 1.164-.173.199-.347.223-.644.075-.297-.15-1.255-.463-2.39-1.475-.883-.788-1.48-1.761-1.653-2.059-.173-.297-.018-.458.13-.606.134-.133.298-.347.446-.52.149-.174.198-.298.298-.497.099-.198.05-.371-.025-.52-.075-.149-.669-1.612-.916-2.207-.242-.579-.487-.5-.669-.51-.173-.008-.371-.01-.57-.01-.198 0-.52.074-.792.372-.272.297-1.04 1.016-1.04 2.479 0 1.462 1.065 2.875 1.213 3.074.149.198 2.096 3.2 5.077 4.487.709.306 1.262.489 1.694.625.712.227 1.36.195 1.871.118.571-.085 1.758-.719 2.006-1.413.248-.694.248-1.289.173-1.413-.074-.124-.272-.198-.57-.347m-5.421 7.403h-.004a9.87 9.87 0 01-5.031-1.378l-.361-.214-3.741.982.998-3.648-.235-.374a9.86 9.86 0 01-1.51-5.26c.001-5.45 4.436-9.884 9.888-9.884 2.64 0 5.122 1.03 6.988 2.898a9.825 9.825 0 012.893 6.994c-.003 5.45-4.437 9.884-9.885 9.884m8.413-18.297A11.815 11.815 0 0012.05 0C5.495 0 .16 5.335.157 11.892c0 2.096.547 4.142 1.588 5.945L.057 24l6.305-1.654a11.882 11.882 0 005.683 1.448h.005c6.554 0 11.89-5.335 11.893-11.893a11.821 11.821 0 00-3.48-8.413z"/></svg>
      Open WhatsApp
    </button>`
  );
}
function submitWhatsApp(){
  var phone=v('wa_phone').replace(/\D/g,'');
  var msg=v('wa_msg');
  if(!phone){toast('Please enter a phone number','err');return;}
  if(!msg){toast('Please enter a message','err');return;}
  var url='https://wa.me/'+phone+'?text='+encodeURIComponent(msg);
  window.open(url,'_blank');
  closeModal();
  toast('WhatsApp opened ✓');
}
/* Test email */
function testEmail(btn){
  btn=btn||(typeof event!=='undefined'&&event.target)||null;if(!btn)return;btn.disabled=true;btn.textContent='Sending…';
  post('api_test_email',{},function(d){
    btn.disabled=false;btn.textContent='Send Test Email';
    toast(d.message,d.ok?'success':'err');
  });
}
function smtpDebug(btn){
  if(btn){btn.disabled=true;btn.textContent='Testing…';}
  var traceEl=document.getElementById('smtp_trace');
  fetch('?action=api_smtp_debug',{method:'POST',headers:{'Content-Type':'application/json','X-Requested-With':'XMLHttpRequest'},body:'{}' })
    .then(r=>r.json()).then(d=>{
      if(btn){btn.disabled=false;btn.textContent='🔍 SMTP Debug';}
      if(traceEl){
        traceEl.style.display='block';
        traceEl.textContent=d.trace.join('\n');
        if(d.ok) traceEl.style.color='#a0ffb0';
        else traceEl.style.color='#ffb0a0';
      }
      if(d.ok) toast('SMTP connection successful ✓');
      else toast('SMTP failed — see trace above','err');
    }).catch(e=>{
      if(btn){btn.disabled=false;btn.textContent='🔍 SMTP Debug';}
      toast('Debug request failed: '+e.message,'err');
    });
}
function aip(ctx){return`<div class="aip"><div class="aiph"><span style="font-size:14px">⚡</span><span class="aipl">AI Writing Assistant · Powered by Groq</span></div><div class="aiprow"><input class="aiinp" id="ai_p" placeholder="Describe what to write… (e.g. 'notify parent about meeting')" onkeydown="if(event.key==='Enter')aiGen(${JSON.stringify(ctx)})"/><button class="aibtn" onclick="aiGen(${JSON.stringify(ctx)})">Generate ⚡</button></div><div id="ai_err" class="aierr" style="display:none"></div></div>`;}
function aiGen(ctx){
  var p=document.getElementById('ai_p');
  if(!p||!p.value.trim()){toast('Please enter a prompt for the AI','warn');return;}
  var btn=p.parentElement.querySelector('.aibtn')||p.nextElementSibling;
  if(btn){btn.disabled=true;btn.textContent='Writing…';}
  var errEl=document.getElementById('ai_err');
  if(errEl) errEl.style.display='none';
  var prompt=p.value.trim();
  var userMsg=ctx
    ? `Context: ${ctx}\n\nTask: ${prompt}\n\nWrite a professional, warm school communication. Output only the message body — no subject line, no preamble.`
    : `Task: ${prompt}\n\nWrite a professional, warm school communication. Output only the message body — no subject line, no preamble.`;
  fetch('api-proxy.php',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({messages:[{role:'user',content:userMsg}],max_tokens:1024})
  })
  .then(r=>{if(!r.ok) return r.json().then(e=>{throw new Error(e.error||'HTTP '+r.status);});return r.json();})
  .then(d=>{
    var text='';
    if(d.choices&&d.choices[0]&&d.choices[0].message) text=d.choices[0].message.content||'';
    else if(d.error) throw new Error(typeof d.error==='string'?d.error:d.error.message||'API error');
    if(!text) throw new Error('No content returned from AI');
    // Try to fill the right textarea — msg_body (compose), wa_msg (WhatsApp), or notify_msg
    var targets=['msg_body','wa_msg','notify_msg'];
    var filled=false;
    for(var t of targets){var ta=document.getElementById(t);if(ta){ta.value=text;filled=true;break;}}
    if(!filled){
      // Fallback: show in a readable div
      if(errEl){errEl.style.display='block';errEl.style.color='var(--ok)';errEl.textContent='Generated: '+text.substring(0,200)+'…';}
    }
    p.value='';
    if(btn){btn.disabled=false;btn.textContent='Generate ⚡';}
    toast('AI text generated ✓');
  })
  .catch(err=>{
    if(errEl){errEl.style.display='block';errEl.style.color='var(--er)';errEl.textContent='⚠ AI error: '+err.message;}
    if(btn){btn.disabled=false;btn.textContent='Generate ⚡';}
  });
}

/* ICS */
function parseSlotDateTime(meetingDate, slot) {
  var base = meetingDate ? meetingDate.split('T')[0] : new Date().toISOString().split('T')[0];
  if (!slot) return new Date(base + 'T08:00:00');
  var m2 = slot.match(/(\d{1,2}):(\d{2})\s*(AM|PM)/i);
  if (m2) {
    var h = parseInt(m2[1], 10), min = parseInt(m2[2], 10), ampm = m2[3].toUpperCase();
    if (ampm === 'PM' && h !== 12) h += 12;
    if (ampm === 'AM' && h === 12) h = 0;
    var pad = function(n){ return String(n).padStart(2, '0'); };
    return new Date(base + 'T' + pad(h) + ':' + pad(min) + ':00');
  }
  var d = new Date(base + ' ' + slot);
  return isNaN(d.getTime()) ? new Date(base + 'T08:00:00') : d;
}
function dlICS(m,b){
  if(!m||!m.title){toast('Meeting data missing','err');return;}
  var sd = b && b.slot ? parseSlotDateTime(m.date, b.slot) : new Date((m.date||'').split('T')[0]+'T08:00:00');
  if(isNaN(sd.getTime())){toast('Invalid meeting date','err');return;}
  var ed=new Date(sd.getTime()+30*60000);
  var fmt=function(d){return d.toISOString().replace(/[-:]/g,'').split('.')[0]+'Z';};
  var safeStr=function(s){return (s||'').replace(/[\\,;]/g,'\\$&').replace(/\n/g,'\\n');};
  var ics='BEGIN:VCALENDAR\r\nVERSION:2.0\r\nPRODID:-//School//Meeting Portal//EN\r\nCALSCALE:GREGORIAN\r\nBEGIN:VEVENT\r\nUID:'+Date.now()+'@schoolportal\r\nDTSTAMP:'+fmt(new Date())+'\r\nDTSTART:'+fmt(sd)+'\r\nDTEND:'+fmt(ed)+'\r\nSUMMARY:'+safeStr(m.title)+'\r\nDESCRIPTION:'+safeStr((m.description||'')+(b&&b.slot?' | Slot: '+b.slot:''))+'\r\nLOCATION:'+safeStr(m.location||'School Campus')+'\r\nSTATUS:CONFIRMED\r\nEND:VEVENT\r\nEND:VCALENDAR';
  var a=document.createElement('a');
  a.href=URL.createObjectURL(new Blob([ics],{type:'text/calendar;charset=utf-8'}));
  a.download=(m.title||'meeting').replace(/\s+/g,'_')+'.ics';
  a.click();
  toast('Calendar downloaded! 📅');
}


/* Delete */
function delMeeting(id,title){if(!confirm('Delete "'+title+'"?\nThis cannot be undone.'))return;post('api_delete',{id},()=>{toast('Meeting deleted.');reload();});}

/* ── PROFILE ──────────────────────────────────────────────── */
function openProfile(){
  if(!D||!D.user){toast('Session error. Please refresh.','err');return;}
  var u=D.user;
  var streamsHtml='';
  if(u.role==='teacher'){
    streamsHtml=`<div class="fg"><label class="fl">Class Streams You Teach</label>
      <p style="font-size:11px;color:var(--s4);margin-bottom:8px">Tick all streams you handle. Your dashboard shows meetings for these classes.</p>
      <div class="stream-grid" id="prof_stream_grid" style="max-height:180px">
        ${D.allClasses.map(c=>`<label class="stream-chk"><input type="checkbox" name="prof_stream" value="${h(c)}" ${(u.streams||[]).includes(c)?'checked':''}/>${h(c)}</label>`).join('')}
      </div></div>`;
  } else if(u.role==='parent'){
    streamsHtml=`<div class="form2">
      <div class="fg"><label class="fl">Child's Full Name</label><input class="fi" id="prof_studentName" value="${h(u.studentName||'')}"/></div>
      <div class="fg"><label class="fl">Child's Class / Stream</label>
        <select class="fi" id="prof_studentClass">
          <option value="">— Select —</option>
          ${D.allClasses.map(c=>`<option value="${h(c)}" ${u.studentClass===c||u.class===c?'selected':''}>${h(c)}</option>`).join('')}
        </select>
      </div></div>`;
  }

  var depField=(u.role==='teacher'||u.role==='principal'||u.role==='admin')
    ?`<div class="fg"><label class="fl">Department / Subject</label><input class="fi" id="prof_dept" value="${h(u.dept||'')}"/></div>`:'';

  var avatarSrc=u.avatar||'';
  var iniText=u.name.split(' ').slice(0,2).map(w=>w[0]?.toUpperCase()||'').join('');
  var avatarHtml=avatarSrc
    ?`<img id="prof_av_img" src="${avatarSrc}" style="width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--s2)"/>`
    :`<div id="prof_av_img" style="width:90px;height:90px;border-radius:50%;background:${u.color};display:flex;align-items:center;justify-content:center;font-size:28px;font-weight:700;color:#fff;letter-spacing:-1px;border:3px solid var(--s2)">${iniText}</div>`;

  var body=`
    <input type="file" id="prof_av_file" accept="image/*" style="display:none" onchange="previewAvatar(this)"/>
    <div style="display:flex;align-items:center;gap:20px;padding:20px 0 24px;border-bottom:1.5px solid var(--s1);margin-bottom:22px">
      <div style="position:relative;cursor:pointer" onclick="document.getElementById('prof_av_file').click()" title="Change photo">
        ${avatarHtml}
        <div style="position:absolute;bottom:0;right:0;width:26px;height:26px;background:var(--n1);border-radius:50%;display:flex;align-items:center;justify-content:center;font-size:12px;color:#fff;border:2px solid #fff">📷</div>
      </div>
      <div>
        <div style="font-weight:700;font-size:16px;color:var(--n1)">${h(u.name)}</div>
        <div style="font-size:12px;color:var(--s4);margin-top:3px">${h(u.role.charAt(0).toUpperCase()+u.role.slice(1))} · ${h(u.email)}</div>
        ${u.class?`<div style="font-size:11px;color:var(--bl);margin-top:4px;font-weight:600">${h(u.class)}</div>`:''}
        <div style="font-size:11px;color:var(--s4);margin-top:6px">Click photo to change</div>
      </div>
    </div>
    <div class="form2">
      <div class="fg"><label class="fl">Full Name</label><input class="fi" id="prof_name" value="${h(u.name)}"/></div>
      <div class="fg"><label class="fl">Phone</label><input class="fi" id="prof_phone" value="${h(u.phone||'')}"/></div>
    </div>
    <div class="fg"><label class="fl">Bio / About</label><textarea class="fi fta" id="prof_bio" rows="2" placeholder="A short note about yourself…">${h(u.bio||'')}</textarea></div>
    ${depField}
    ${streamsHtml}
    <div style="border-top:1.5px solid var(--s1);margin-top:20px;padding-top:20px">
      <div style="font-size:13px;font-weight:700;color:var(--n1);margin-bottom:14px">🔐 Change Password</div>
      <div class="fg"><label class="fl">Current Password</label><input class="fi" type="password" id="prof_curpwd" placeholder="Enter current password"/></div>
      <div class="form2">
        <div class="fg"><label class="fl">New Password</label><input class="fi" type="password" id="prof_newpwd" placeholder="Min. 6 characters"/></div>
        <div class="fg"><label class="fl">Confirm New Password</label><input class="fi" type="password" id="prof_newpwd2" placeholder="Repeat new password"/></div>
      </div>
    </div>
    <div id="prof_msg" style="display:none;margin-top:10px;padding:10px 14px;border-radius:var(--r2);font-size:13px;font-weight:500"></div>
  `;

  sm('My Profile','Edit your details, streams and password',body,
    `<button class="btn-o" onclick="closeModal()">Cancel</button><button class="btn-g" id="profSaveBtn" onclick="saveProfile()">💾 Save Changes</button>`,true);
}
function previewAvatar(input){
  if(!input.files||!input.files[0]) return;
  var file=input.files[0];
  if(file.size>700000){toast('Image too large. Use under 500KB.','err');return;}
  var reader=new FileReader();
  reader.onload=function(e){
    var src=e.target.result;
    var img=document.getElementById('prof_av_img');
    if(img.tagName==='IMG') img.src=src;
    else{ var ni=document.createElement('img');ni.id='prof_av_img';ni.src=src;ni.style.cssText='width:90px;height:90px;border-radius:50%;object-fit:cover;border:3px solid var(--s2)';img.parentNode.replaceChild(ni,img); }
    img._newAvatar=src;
  };
  reader.readAsDataURL(file);
}
function saveProfile(){
  var btn=document.getElementById('profSaveBtn');
  btn.disabled=true;btn.textContent='Saving…';
  var u=D.user;
  var body={
    name:document.getElementById('prof_name')?.value||'',
    phone:document.getElementById('prof_phone')?.value||'',
    bio:document.getElementById('prof_bio')?.value||'',
  };
  // Avatar
  var img=document.getElementById('prof_av_img');
  if(img&&img._newAvatar) body.avatar=img._newAvatar;
  // Role extras
  if(u.role==='parent'){
    body.studentName=document.getElementById('prof_studentName')?.value||'';
    body.studentClass=document.getElementById('prof_studentClass')?.value||'';
  } else if(u.role==='teacher'){
    body.dept=document.getElementById('prof_dept')?.value||'';
    body.streams=[...document.querySelectorAll('#prof_stream_grid input:checked')].map(x=>x.value);
  } else {
    var dEl=document.getElementById('prof_dept');
    if(dEl) body.dept=dEl.value;
  }
  // Password
  var curp=document.getElementById('prof_curpwd')?.value||'';
  var newp=document.getElementById('prof_newpwd')?.value||'';
  var newp2=document.getElementById('prof_newpwd2')?.value||'';
  if(newp){body.currentPassword=curp;body.newPassword=newp;body.confirmPassword=newp2;}

  var msgEl=document.getElementById('prof_msg');
  function showProfMsg(msg,ok){if(msgEl){msgEl.style.display='block';msgEl.style.background=ok?'var(--okbg)':'var(--erbg)';msgEl.style.color=ok?'var(--ok)':'var(--er)';msgEl.style.border='1.5px solid '+(ok?'rgba(10,124,90,.2)':'rgba(185,28,28,.2)');msgEl.textContent=msg;}}

  fetch('?action=api_profile',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(body)})
  .then(r=>r.json())
  .then(d=>{
    btn.disabled=false;btn.textContent='💾 Save Changes';
    if(d.ok){
      D.user=d.user;
      showProfMsg('✓ Profile saved successfully!',true);
      setTimeout(()=>{closeModal();location.reload();},1400);
    } else {
      showProfMsg(d.error||'Save failed.',false);
    }
  })
  .catch(()=>{btn.disabled=false;btn.textContent='💾 Save Changes';showProfMsg('Network error.',false);});
}

/* Settings */
function saveSettings(){
  var data={};
  ['schoolName','schoolMotto','logo','address','phone','email','website'].forEach(k=>{
    var el=document.getElementById('s_'+k);if(el)data[k]=el.value;
  });
  // Custom streams
  var rawStreams=document.getElementById('s_customStreams');
  if(rawStreams){
    data.customStreams=rawStreams.value.split('\n').map(s=>s.trim()).filter(Boolean);
  }
  post('api_settings',data,function(d){
    if(d.ok){toast('Settings saved! ✓');setTimeout(()=>location.reload(),1200);}
    else toast(d.error||'Save failed','err');
  });
}
function testAI(btn){
  btn=btn||(typeof event!=='undefined'&&event.target)||null;if(!btn)return;btn.disabled=true;btn.textContent='Testing…';
  fetch('api-proxy.php',{
    method:'POST',
    headers:{'Content-Type':'application/json'},
    body:JSON.stringify({messages:[{role:'user',content:'Reply with exactly: "Groq AI is working correctly on the School Meeting Portal."'}],max_tokens:30})
  })
  .then(r=>r.json())
  .then(d=>{
    btn.disabled=false;btn.textContent='Test AI';
    var txt=d.choices?.[0]?.message?.content||d.error||'No response';
    toast('⚡ Groq: '+txt.substring(0,80));
  })
  .catch(e=>{btn.disabled=false;btn.textContent='Test AI';toast('AI test failed: '+e.message,'err');});
}
</script>

<?php endif; ?>
</body>
</html>
