# Springfield Academy — School Meeting Portal v2.0
## cPanel / Shared Hosting · Pure PHP · Zero Dependencies

---

## 📁 Project Structure

```
school-portal/
│
├── .htaccess              ← Root: security, routing, compression, caching
├── .env                   ← Sensitive credentials (API keys, passwords)
├── index.php              ← Main application (all pages)
├── api-proxy.php          ← Anthropic AI proxy (server-side key injection)
├── robots.txt             ← Block bots from admin/data paths
│
├── config/
│   ├── app.php            ← All application constants & settings
│   └── env.php            ← .env file loader
│
├── includes/
│   ├── bootstrap.php      ← Loads everything, starts session
│   ├── Database.php       ← JSON flat-file database class
│   ├── helpers.php        ← Utility functions (e, jd, jo, uid, etc.)
│   └── Audit.php          ← Audit trail logger
│
├── data/                  ← JSON "database" files (auto-created)
│   ├── .htaccess          ← Blocks all public access
│   ├── meetings.json
│   ├── bookings.json
│   ├── apologies.json
│   ├── messages.json
│   ├── settings.json
│   ├── users.json
│   ├── audit_log.json
│   └── sessions.json
│
├── logs/                  ← Application & PHP error logs
│   └── .htaccess          ← Blocks all public access
│
├── cache/                 ← Rate-limit state, data backups
│
└── install/               ← ⚠ DELETE AFTER FIRST RUN
    └── index.php          ← Web-based setup wizard
```

---

## 🚀 Quick Setup (cPanel)

### Option A — Automated (Recommended)
1. Upload all files to `public_html` (or a subfolder)
2. Visit `https://yourdomain.com/install/` in your browser
3. Follow the 3-step wizard
4. **Delete the `/install/` folder!**

### Option B — Manual
1. Upload all files to `public_html`
2. Copy `.env` and fill in your values:
   ```ini
   ANTHROPIC_API_KEY=sk-ant-your-key-here
   APP_SECRET=some-long-random-string
   ```
3. Set folder permissions:
   ```
   data/   → 755
   logs/   → 755
   cache/  → 755
   ```
4. Visit your domain

---

## 🔐 Security Features

| Feature | Details |
|---|---|
| `.htaccess` protection | Blocks direct access to `/data/`, `/logs/`, `/cache/`, `/config/` |
| Security headers | CSP, X-Frame-Options, X-Content-Type-Options, etc. |
| Session hardening | HttpOnly, SameSite=Strict, ID regeneration |
| Rate limiting | Per-IP limit on API calls; stricter limit on AI endpoint |
| Audit logging | All key user actions recorded to `data/audit_log.json` |
| File locking | Atomic writes prevent data corruption under load |
| No direct DB credentials | Credentials in `.env`, loaded at runtime |
| CSRF tokens | Available via `csrfToken()` helper for form protection |

---

## ⚙️ Configuration Reference (`config/app.php`)

| Constant | Default | Description |
|---|---|---|
| `APP_ENV` | `production` | `development` shows errors; `production` suppresses them |
| `DEMO_MODE` | `true` | Any password accepted |
| `FEATURE_AI_ASSISTANT` | `true` | Enable/disable AI writing helper |
| `FEATURE_AUDIT_LOG` | `true` | Enable/disable audit trail |
| `FEATURE_MAINTENANCE_MODE` | `false` | Lock portal to admins only |
| `RATE_LIMIT_REQUESTS` | `100/hr` | Per-IP rate limit for all requests |
| `RATE_LIMIT_AI` | `20/hr` | Stricter limit for AI proxy |
| `SESSION_LIFETIME` | `28800` (8h) | Session expiry in seconds |
| `APP_TIMEZONE` | `Africa/Nairobi` | PHP timezone |

---

## 👥 Demo Users

| Role | Email | Password |
|---|---|---|
| Parent | james.omondi@parent.com | *(any — demo mode)* |
| Teacher | a.wanjiru@springfield.ac.ke | *(any)* |
| Principal | principal@springfield.ac.ke | *(any)* |
| Admin | admin@springfield.ac.ke | *(any)* |

---

## 📋 PHP Requirements
- PHP 8.0+
- Extensions: `curl`, `json`, `session`, `openssl`
- Writable: `data/`, `logs/`, `cache/`

All of these are standard on any cPanel shared hosting plan.

---

## 🔄 Upgrading from v1.0
The v2.0 data format is identical. Your existing `data/*.json` files work as-is.
Just upload the new files around them.
