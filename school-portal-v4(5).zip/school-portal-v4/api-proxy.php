<?php
// ================================================================
// api-proxy.php — Groq AI Proxy
// ================================================================
// Forwards AI requests to Groq's OpenAI-compatible API.
// Key: server-side only, never reaches the browser.
//
// Groq endpoint: POST https://api.groq.com/openai/v1/chat/completions
// Auth:          Authorization: Bearer <GROQ_API_KEY>
// Response:      { choices: [{ message: { content: "..." } }] }
//
// Front-end reads: data.choices[0].message.content
// ================================================================

if (!defined('ROOT_DIR')) {
    define('ROOT_DIR', __DIR__);
    require_once ROOT_DIR . '/config/app.php';
    require_once ROOT_DIR . '/config/env.php';
    require_once ROOT_DIR . '/includes/helpers.php';
}

// CORS
$origin = $_SERVER['HTTP_ORIGIN'] ?? '';
if (CORS_ALLOW_ALL || in_array($origin, unserialize(CORS_ALLOWED_ORIGINS), true)) {
    header('Access-Control-Allow-Origin: ' . (CORS_ALLOW_ALL ? '*' : $origin));
}
header('Access-Control-Allow-Methods: POST, OPTIONS');
header('Access-Control-Allow-Headers: Content-Type, X-Requested-With');
header('Content-Type: application/json; charset=UTF-8');

if ($_SERVER['REQUEST_METHOD'] === 'OPTIONS') { http_response_code(200); exit; }
if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405); echo json_encode(['error'=>'Method not allowed']); exit;
}
if (!FEATURE_AI_ASSISTANT) {
    http_response_code(503); echo json_encode(['error'=>'AI assistant disabled.']); exit;
}

// API Key
$apiKey = defined('GROQ_API_KEY') ? GROQ_API_KEY : env('GROQ_API_KEY', '');
if (empty($apiKey)) {
    http_response_code(503);
    echo json_encode(['error'=>'Groq API key not configured. Set GROQ_API_KEY in .env']);
    exit;
}

// Rate limit
$rlKey = 'groq_' . ($_SERVER['REMOTE_ADDR'] ?? 'unknown');
if (!checkRateLimit($rlKey, RATE_LIMIT_AI, RATE_LIMIT_WINDOW)) {
    http_response_code(429);
    echo json_encode(['error'=>'Too many AI requests. Please wait and try again.']);
    exit;
}

// Parse body
$input = json_decode(file_get_contents('php://input'), true);
if (!$input || !isset($input['messages']) || !is_array($input['messages'])) {
    http_response_code(400);
    echo json_encode(['error'=>'Invalid request. Send {messages:[...]}']);
    exit;
}

$messages = $input['messages'];

// Add system message if absent
$hasSystem = count(array_filter($messages, fn($m) => ($m['role'] ?? '') === 'system')) > 0;
if (!$hasSystem) {
    array_unshift($messages, [
        'role'    => 'system',
        'content' => 'You are a professional school communication assistant for a Kenyan secondary school. ' .
                     'Write warm, formal, and concise communications suitable for parents, teachers, and school leadership. ' .
                     'Use proper English. Keep responses focused and under 300 words unless asked for more.',
    ]);
}

$payload = [
    'model'       => GROQ_MODEL,
    'messages'    => $messages,
    'max_tokens'  => min((int)($input['max_tokens'] ?? GROQ_MAX_TOKENS), GROQ_MAX_TOKENS),
    'temperature' => (float)($input['temperature'] ?? GROQ_TEMPERATURE),
    'stream'      => false,
];

// Call Groq
$ch = curl_init(GROQ_API_URL);
curl_setopt_array($ch, [
    CURLOPT_RETURNTRANSFER => true,
    CURLOPT_POST           => true,
    CURLOPT_HTTPHEADER     => [
        'Content-Type: application/json',
        'Authorization: Bearer ' . $apiKey,
    ],
    CURLOPT_POSTFIELDS     => json_encode($payload),
    CURLOPT_TIMEOUT        => GROQ_TIMEOUT,
    CURLOPT_CONNECTTIMEOUT => 10,
    CURLOPT_SSL_VERIFYPEER => true,
    CURLOPT_FOLLOWLOCATION => false,
]);

$response = curl_exec($ch);
$httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
$curlErr  = curl_error($ch);
curl_close($ch);

appLog('info', 'Groq AI request', [
    'ip'   => $_SERVER['REMOTE_ADDR'] ?? '',
    'code' => $httpCode,
    'model'=> GROQ_MODEL,
]);

if ($curlErr) {
    http_response_code(502);
    echo json_encode(['error' => 'Groq connection error: ' . $curlErr]);
    exit;
}

http_response_code($httpCode);
echo $response;
