<?php
// ================================================================
// SCHOOL MEETING PORTAL — create.sovereignai.co.ke
// config/app.php — Application Configuration
// ================================================================

define('APP_ENV',     'production');
define('APP_VERSION', '2.0.0');
define('APP_NAME',    'School Meeting Portal');
define('APP_URL',     'https://create.sovereignai.co.ke');

// Paths
define('ROOT_DIR',  __DIR__ . '/..');
define('DATA_DIR',  ROOT_DIR . '/data/');
define('LOGS_DIR',  ROOT_DIR . '/logs/');
define('CACHE_DIR', ROOT_DIR . '/cache/');
define('INC_DIR',   ROOT_DIR . '/includes/');

// JSON flat-file database paths
define('DB_MEETINGS',  DATA_DIR . 'meetings.json');
define('DB_BOOKINGS',  DATA_DIR . 'bookings.json');
define('DB_APOLOGIES', DATA_DIR . 'apologies.json');
define('DB_MESSAGES',  DATA_DIR . 'messages.json');
define('DB_SETTINGS',  DATA_DIR . 'settings.json');
define('DB_USERS',     DATA_DIR . 'users.json');
define('DB_AUDIT',     DATA_DIR . 'audit_log.json');
define('DB_SESSIONS',  DATA_DIR . 'sessions.json');
define('DB_CHATS',     DATA_DIR . 'chats.json');

// MySQL — credentials loaded from .env at runtime
// Database : btrfpimq_reg
// User     : btrfpimq_reg
// Host     : localhost
define('DB_MYSQL_DEFAULT_HOST', 'localhost');
define('DB_MYSQL_DEFAULT_PORT', 3306);
define('DB_MYSQL_DEFAULT_NAME', 'btrfpimq_reg');
define('DB_MYSQL_DEFAULT_USER', 'btrfpimq_reg');

// SMTP — password loaded from .env, never hardcoded here
// From    : noreply@sovereignai.co.ke
// Host    : mail.sovereignai.co.ke:587 (STARTTLS)
define('MAIL_FROM',      'noreply@sovereignai.co.ke');
define('MAIL_FROM_NAME', 'School Meeting Portal');
define('MAIL_REPLY_TO',  'noreply@sovereignai.co.ke');
define('MAIL_SMTP_HOST', 'mail.sovereignai.co.ke');
define('MAIL_SMTP_PORT', 587);
define('MAIL_ENCRYPTION','tls');

// Session
define('SESSION_NAME',    'sovereignai_school_sess');
define('SESSION_LIFETIME', 60 * 60 * 8);
define('SESSION_PATH',    '/');
define('SESSION_SECURE',  false);
define('SESSION_HTTPONLY', true);

// Security
define('CSRF_TOKEN_NAME', 'csrf_token');
define('CSRF_TOKEN_TTL',  3600);

// Rate limiting
define('RATE_LIMIT_ENABLED',  true);
define('RATE_LIMIT_REQUESTS', 120);
define('RATE_LIMIT_WINDOW',   3600);
define('RATE_LIMIT_AI',       30);

// ----------------------------------------------------------------
// Groq AI  (OpenAI-compatible API — free, fast)
// https://console.groq.com/  |  openai-compat endpoint
// ----------------------------------------------------------------
define('GROQ_API_URL',      'https://api.groq.com/openai/v1/chat/completions');
define('GROQ_MODEL',        'llama-3.3-70b-versatile');   // best free model on Groq
define('GROQ_MAX_TOKENS',   1024);
define('GROQ_TIMEOUT',      30);
define('GROQ_TEMPERATURE',  0.7);

// Feature flags
define('FEATURE_AI_ASSISTANT',     true);
define('FEATURE_CALENDAR_EXPORT',  true);
define('FEATURE_APOLOGY_WORKFLOW', true);
define('FEATURE_AUDIT_LOG',        true);
define('FEATURE_MAINTENANCE_MODE', false);
define('FEATURE_EMAIL',            true);

// Which events send automatic emails
define('EMAIL_ON_BOOKING',      true);
define('EMAIL_ON_CANCELLATION', true);
define('EMAIL_ON_DIRECT_MSG',   true);
define('EMAIL_ON_PARENT_MSG',   true);

// Demo mode — any password accepted
define('DEMO_MODE', true);

// Pagination
define('PAGE_SIZE_MEETINGS', 20);
define('PAGE_SIZE_BOOKINGS', 30);
define('PAGE_SIZE_MESSAGES', 25);

// Upload limits
define('ALLOWED_UPLOAD_TYPES', serialize(['image/jpeg','image/png','image/gif','application/pdf']));
define('MAX_UPLOAD_SIZE', 5 * 1024 * 1024);

define('MAINTENANCE_MESSAGE', 'The portal is undergoing scheduled maintenance.');

// Timezone
define('APP_TIMEZONE', 'Africa/Nairobi');
date_default_timezone_set(APP_TIMEZONE);

// CORS
define('CORS_ALLOWED_ORIGINS', serialize([
    'https://create.sovereignai.co.ke',
    'https://sovereignai.co.ke',
]));
define('CORS_ALLOW_ALL', false);

// Error handling
if (APP_ENV === 'development') {
    error_reporting(E_ALL);
    ini_set('display_errors', '1');
} else {
    error_reporting(0);
    ini_set('display_errors', '0');
    ini_set('log_errors', '1');
    ini_set('error_log', LOGS_DIR . 'php_errors.log');
}

// School defaults
define('DEFAULT_SCHOOL_SETTINGS', serialize([
    'schoolName'       => 'SPRINGFIELD ACADEMY',
    'schoolMotto'      => 'Excellence Through Education',
    'logo'             => '🎓',
    'address'          => 'Nairobi, Kenya',
    'phone'            => '+254 712 345 678',
    'email'            => 'noreply@sovereignai.co.ke',
    'website'          => 'create.sovereignai.co.ke',
    'classes'          => ['Form 1 East','Form 1 West','Form 2 East','Form 2 West',
                           'Form 3 East','Form 3 West','Form 4 East','Form 4 West'],
    'departments'      => ['Mathematics','Sciences','Languages','Humanities',
                           'Technical','Arts','Physical Education'],
    'defaultTimeSlots' => ['08:00 AM','08:30 AM','09:00 AM','09:30 AM',
                           '10:00 AM','10:30 AM','11:00 AM','11:30 AM',
                           '02:00 PM','02:30 PM','03:00 PM','03:30 PM'],
]));
