<?php
// ================================================================
// config/env.php — .env File Loader
// ================================================================
// Reads .env and exposes values via getenv() / $_ENV.
// Also declares runtime constants for SMTP, DB, and App secrets.
// ================================================================

function loadEnv(string $path): void
{
    if (!file_exists($path)) return;

    foreach (file($path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES) as $line) {
        $line = trim($line);
        if (empty($line) || str_starts_with($line, '#')) continue;
        if (!str_contains($line, '=')) continue;

        [$key, $value] = explode('=', $line, 2);
        $key   = trim($key);
        $value = trim($value);

        // Strip surrounding quotes
        if (strlen($value) >= 2 &&
            (($value[0] === '"' && $value[-1] === '"') ||
             ($value[0] === "'" && $value[-1] === "'"))) {
            $value = substr($value, 1, -1);
        }

        if (!array_key_exists($key, $_ENV) && getenv($key) === false) {
            putenv("$key=$value");
            $_ENV[$key]    = $value;
            $_SERVER[$key] = $value;
        }
    }
}

loadEnv(ROOT_DIR . '/.env');

function env(string $key, mixed $default = null): mixed
{
    $value = $_ENV[$key] ?? getenv($key);
    if ($value === false) return $default;
    return match (strtolower((string)$value)) {
        'true', '1', 'yes', 'on'  => true,
        'false','0', 'no', 'off'  => false,
        default => $value,
    };
}

// ----------------------------------------------------------------
// Groq AI key
// ----------------------------------------------------------------
if (!defined('GROQ_API_KEY')) {
    define('GROQ_API_KEY', env('GROQ_API_KEY', ''));
}

// ----------------------------------------------------------------
// MySQL — btrfpimq_reg / btrfpimq_reg / @Jk2288553322885533
// ----------------------------------------------------------------
if (!defined('DB_MYSQL_HOST')) {
    define('DB_MYSQL_HOST', env('DB_HOST', DB_MYSQL_DEFAULT_HOST));
    define('DB_MYSQL_PORT', (int) env('DB_PORT', DB_MYSQL_DEFAULT_PORT));
    define('DB_MYSQL_NAME', env('DB_NAME', DB_MYSQL_DEFAULT_NAME));
    define('DB_MYSQL_USER', env('DB_USER', DB_MYSQL_DEFAULT_USER));
    define('DB_MYSQL_PASS', env('DB_PASS', ''));
}

// ----------------------------------------------------------------
// SMTP — noreply@sovereignai.co.ke / @Jk2288553322885533
// ----------------------------------------------------------------
if (!defined('SMTP_HOST')) {
    define('SMTP_HOST',       env('SMTP_HOST', MAIL_SMTP_HOST));
    define('SMTP_PORT',       (int) env('SMTP_PORT', MAIL_SMTP_PORT));
    define('SMTP_USER',       env('SMTP_USER', MAIL_FROM));
    define('SMTP_PASS',       env('SMTP_PASS', ''));
    define('SMTP_ENCRYPTION', env('SMTP_ENCRYPTION', MAIL_ENCRYPTION));
    define('SMTP_FROM_NAME',  env('SMTP_FROM_NAME', MAIL_FROM_NAME));
}

// ----------------------------------------------------------------
// App secret
// ----------------------------------------------------------------
if (!defined('APP_SECRET')) {
    define('APP_SECRET', env('APP_SECRET', 'sovereignai-school-portal-fallback-key'));
}
